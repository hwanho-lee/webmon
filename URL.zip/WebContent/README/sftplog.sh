#!/bin/bash
REMOTE_IP='10.225.133.144'
REMOTE_USER='ahn'
REMOTE_PASS='admin1234'
LOGFILE='a.log'
PORT='17022'

if [ -e $LOGFILE ] 
then
	sftp -oPort=$PORT $REMOTE_USER@$REMOTE_IP << EOF
	put $LOGFILE
	quit
EOF
#rm a.log

fi
