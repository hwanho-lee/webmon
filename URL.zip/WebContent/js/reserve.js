function del(){
	 var urls=document.getElementsByName("selected");
	 var j=0;
	 var checkedUrl="";
	 
	 for(var i=0; i<urls.length;i++){
		 if(urls[i].checked==true) j++;
	 }
	 
	 if (j===0) {
		alert("삭제할 예약을 선택해주세요");
	} else {
		var answer=confirm("선택하신 예약을 취소하시겠습니까?");
		
		if(answer==true){
			for(var i=0; i<urls.length;i++){
				 if(urls[i].checked==true){
				 	checkedUrl+=urls[i].value+"@";
				 }
			 }
			
			location.href="delete_reserve.jsp?urls="+checkedUrl;
		}
	}
}
function change(mode){
	
	var buttons=document.getElementById("buttons");
	var updateBtn=document.getElementById("updateBtn");
	
	
	if(mode===1){
		var urls=document.getElementsByName("selected");
		 var j=0;
		 
		 for(var i=0; i<urls.length;i++){
			 if(urls[i].checked==true){
				j++;
				document.getElementById("mysdate_"+(i+1)).style.display="none";
				document.getElementById("myedate_"+(i+1)).style.display="none";
				     
				document.getElementById("sdate_"+(i+1)).style.display="block";
				document.getElementById("edate_"+(i+1)).style.display="block";
			 }
		 }
		 if(j===0){
			alert("예약할 URL을 선택해주세요");
		 }else{
			buttons.style.display="none";
			updateBtn.style.display="block";
		}
	}else if(mode===2){
		location.reload();
	}
	
	
}
function update(){
	var urls=document.getElementsByName("selected");
	 var j=0;
	 
	 var startdates="";
	 var enddates="";
	 var checkedUrl="";
	 
	 
	 for(var i=0; i<urls.length;i++){
		 if(urls[i].checked==true){
			j++;
			
			if(document.getElementById("startdate_"+(i+1)).value===""||
			document.getElementById("starttime_"+(i+1)).value===""||
			document.getElementById("enddate_"+(i+1)).value===""||
			document.getElementById("endtime_"+(i+1)).value===""){
				alert("정확한 날짜를 입력해주세요");
				return;
			}
		 	
		 	var startdate=document.getElementById("startdate_"+(i+1)).value+" "+document.getElementById("starttime_"+(i+1)).value;
		 	var enddate=document.getElementById("enddate_"+(i+1)).value+" "+document.getElementById("endtime_"+(i+1)).value;
		 	
		 	var start=new Date(startdate);
			var end=new Date(enddate);
			
			if(start<new Date()){
					alert("현재날짜보다 이전은 선택하실 수 없습니다");
					return;
			}else if(end<start){
					alert("종료날짜가 시작날짜보다 빠를 수 없습니다");
					return;
			}else{
				checkedUrl+=urls[i].value+"@";
				startdates+=startdate+"@";
			 	enddates+=enddate+"@";
			}
		 }
	 }
	 
	if(j===0){
		alert("예약할 URL을 선택해주세요");
	}else{
		location.href="setnonactives.jsp?urls="+checkedUrl+"&startdates="+startdates+"&enddates="+enddates;
	}
}