function modalView(url){
	$("body").append($("<div class='transparents-layer'></div>"));
	$("body").append($("<div class='modalpop'></div>"));
	$(".modalpop").load(url, function(){
		var popWidth = $(".popupwrap").width()/2;	
		var popHeight = $(".popupwrap").height()/2;
		$(".modalpop").css("margin-left",-popWidth+"px").css("margin-top",-popHeight+"px");
		$(".btnclose").click(function(){
			$(".modalpop").remove();
			$(".transparents-layer").remove();
		});
	});
}

$("ul.pagenavi li.depth_01, ul.pagenavi li.depth_02").hover(function(){
	$(this).find("ul").show();
}, function(){
	$(this).find("ul").hide();
});
$(".filebox .btn_file_del").click(function(){
	$(this).parent().parent().remove();
});
var thisIdx = 0;
$("table.boardwrite tr.attachment_file .filebox .btn_file_add").click(function(){
	thisIdx++;
	$(this).parent().parent().parent().find(".filebox:eq("+thisIdx+")").show();
});
$("ul.topmenu li.mn").hover(function(){
	$("body").addClass("on");
	$(this).addClass("on");
}, function(){
	$("body").removeClass("on");
	$(this).removeClass("on");
});
$(".joinwrap dl dd .agreechk").click(function(){
	if($(this).hasClass("on")){$(this).removeClass("on");}else{	$(this).addClass("on");}
});
$(".cscenter_faq dl dt a").click(function(){
	if($(this).parent().parent().hasClass("on")){
		$(this).parent().parent().removeClass("on");
	}else{
		$(".cscenter_faq dl").removeClass("on");
		$(this).parent().parent().addClass("on");
	}
	return false;
});
$(".guideline .hiddencontents:eq(0)").addClass("on");
$(".guideline ul.commontab li").click(function(){
	var idxTab = $(this).index();
	if($(this).hasClass("on")){
		$(this).removeClass("on");
	}else{
		$(".guideline ul.commontab li").removeClass("on");
		$(".guideline .hiddencontents").removeClass("on");
		$(this).addClass("on");
		$(".guideline .hiddencontents:eq("+idxTab+")").addClass("on");
	}
	return false;
});
$(".memberout .hiddencontents:eq(0)").addClass("on");
$(".memberout ul.commontab li").click(function(){
	var idxTab = $(this).index();
	if($(this).hasClass("on")){
		$(this).removeClass("on");
	}else{
		$(".memberout ul.commontab li").removeClass("on");
		$(".memberout .hiddencontents").removeClass("on");
		$(this).addClass("on");
		$(".memberout .hiddencontents:eq("+idxTab+")").addClass("on");
	}
	return false;
});
$(".member_modify .hiddencontents:eq(0)").addClass("on");
$(".member_modify ul.commontab li").click(function(){
	var idxTab = $(this).index();
	if($(this).hasClass("on")){
		$(this).removeClass("on");
	}else{
		$(".member_modify ul.commontab li").removeClass("on");
		$(".member_modify .hiddencontents").removeClass("on");
		$(this).addClass("on");
		$(".member_modify .hiddencontents:eq("+idxTab+")").addClass("on");
	}
	return false;
});
$(".cscenter_faq .hiddencontents:eq(0)").addClass("on");
$(".cscenter_faq ul.commontab li").click(function(){
	var idxTab = $(this).index();
	if($(this).hasClass("on")){
		$(this).removeClass("on");
	}else{
		$(".cscenter_faq ul.commontab li").removeClass("on");
		$(".cscenter_faq .hiddencontents").removeClass("on");
		$(this).addClass("on");
		$(".cscenter_faq .hiddencontents:eq("+idxTab+")").addClass("on");
	}
	return false;
});

/*var alrimWidth = $("ul.alrimtxt li:eq(0)").width() + $("ul.alrimtxt li:eq(1)").width()+100;
$("ul.alrimtxt").css("width",alrimWidth+"px");*/

 
if ($(".txt_date").length > 1){
	$(".txt_date" ).datepicker({showOn: "button",buttonImage: "../images/icon/icon_calendar.png",buttonImageOnly: true});
}
