function userinsert(){
	document.getElementById("insertdiv").style.display="block";
	document.getElementById("contbotton").style.display="none";
}
//
function userinsert2(){
	var idinsert = document.getElementById("idinsert").value;
	var passinsert = document.getElementById("passinsert").value;
	
	var levelselect = document.getElementById("levelselect");
	var levelinsert = levelselect.options[levelselect.selectedIndex].value;
	var overlap=document.getElementById("insertvalue").value;
	
		if(idinsert == '' || passinsert == '' || levelselect == '')
		{
		 	alert("모두 입력해주세요");
		}else if(document.getElementById("updatecvalue2").value === "change" || overlap == "insert"){
			alert("중복체크를 해주세요");
		}else if(overlap == "y"){
			alert("이미 존재하는 아이디 입니다");
		}else{
	location.href="userinsert.jsp?idinsert="+idinsert+"&passinsert="+passinsert+"&levelinsert="+levelinsert;
	
		}
}
function userupdate(){
	
	var cb = document.getElementsByName("selected");
	var counter=0;
	for(var i=0; i<cb.length; i++){
		if(cb[i].checked==true){
			counter++;
			 document.getElementById("inputuid_"+i).style.display="block";
			 document.getElementById("inputupass_"+i).style.display="block";
			 document.getElementById("inputulevel_"+i).style.display="block";
			 document.getElementById("uid_"+i).style.display="none";
			 document.getElementById("upass_"+i).style.display="none";
			 document.getElementById("ulevel_"+i).style.display="none";
			 var ulevelvalue = document.getElementById("uleveluser_"+i).value;
			 var ulevel = document.getElementById("ulevel2_"+i);
			 ulevel.options[ulevelvalue-1].selected = true;
			
		}
	}
	if(counter==0)
	{
	 	alert("수정할 시스템을 선택하세요");
	}else{
		document.getElementById("updatebutton").style.display="block";
		document.getElementById("contbotton").style.display="none";
	}
	
}

function userdelete(){
	var cb = document.getElementsByName("selected");
	var counter=0;
	 var checklist = new Array();
	 
	for(var i=0; i<cb.length; i++){
		if(cb[i].checked==true){
			checklist.push(document.getElementById("uid_"+i).innerHTML);
			counter++;
		}
	}
	if(counter==0)
	{
	 	alert("삭제할 시스템을 선택하세요");
	}else{
		 var answer=confirm("선택하신 사용자를 삭제하시겠습니까?");
			if(answer==true){
				 location.href="userdelete.jsp?checklist="+checklist;
			}
	  }
}

function cancel(){
var cb = document.getElementsByName("selected");
	
	for(var i=0; i<cb.length; i++){
		if(cb[i].checked==true){
	document.getElementById("inputuid_"+i).style.display="none";
	document.getElementById("inputupass_"+i).style.display="none";
	document.getElementById("inputulevel_"+i).style.display="none";
	document.getElementById("uid_"+i).style.display="block";
	document.getElementById("upass_"+i).style.display="block";
	document.getElementById("ulevel_"+i).style.display="block";
		}	
	}
	document.getElementById("insertdiv").style.display="none";
	document.getElementById("updatebutton").style.display="none";
	document.getElementById("contbotton").style.display="block";
	document.getElementById("idinsert").value=null;
	document.getElementById("passinsert").value=null;
}
function insertoverlap()
{
	 var counter=0;
	 var cb = document.getElementsByName("selected");
		
		 var newuid= document.getElementById("idinsert").value;
	
	 if(newuid!=''){
		
		 for(var i=0; i<cb.length;i++){
			 document.getElementById("updatecvalue2").value = "";
			 olduid = document.getElementById("uid2_"+i).value;
				 if(newuid === olduid)
				 {
					 	counter=2;
					 	alert("이미 존재하는 아이디입니다");
					 	document.getElementById("insertvalue").value = 'y';
				 }
		 }	
				 if(counter==0)
				 {
					 alert("추가 가능한 아이디입니다");
					 document.getElementById("insertvalue").value = 'n';
				 }
	 }else{
		 alert("모두 입력해주세요");
	 }
}

function updateoverlap(index){
	 
	var counter =0;
	 var j = index;
	 var cb = document.getElementsByName("selected");
		
	 var newuid= document.getElementById("uid2_"+index).value;
	 
	 if(newuid!=''){
		 
		 for(var i=0; i<cb.length;i++){
			 document.getElementById("updatecvalue_"+i).value = "";
			 olduid = document.getElementById("uid_"+i).innerHTML;
			 if(i==j){}
				 else if(newuid === olduid)
				 {
					 	counter=2;
					 	alert("이미 존재하는 아이디입니다");
					 	document.getElementById("updatevalue_"+index).value = 'y';
				 }
		 }	
		 
				 if(counter==0)
				 {
					 document.getElementById("updatevalue_"+index).value = 'n';
					 alert("추가 가능한 아이디입니다");
				 }
	 }else{
		 alert("모두 입력해주세요");
	 }
}
function updatesuccess(){
	
	 var checklist = new Array();
	 var counter1=0;
	 var counter2=0;
	 var counter3=0;
	 var changeuser=0;
	 
	 var cb = document.getElementsByName("selected");
	
	 for(var i=0; i<cb.length;i++){
		 if(cb[i].checked==true){
			    counter1++;
			    
			    if(document.getElementById("updatecvalue_"+i).value ==="change")
			    	changeuser=1;
		 
			var newuid=  document.getElementById("uid2_"+i).value;
			var olduid= document.getElementById("uid_"+i).innerHTML;
			var upass= document.getElementById("upass2_"+i).value;
			var ulevel = document.getElementById("ulevel2_"+i);
			var overlap=document.getElementById("updatevalue_"+i).value;
			var levelupdate = ulevel.options[ulevel.selectedIndex].value;

			if(overlap=="n"){
					 counter2++;
				 }else if(overlap=="y"){
					 counter3++;
				 }
				 
			 	if(newuid=='' || upass=='' || ulevel==''){
			 	  	counter=1;
			 	  	alert("모두 입력하세요");
			 	  	break;
			 	}else{
			 		checklist.push(newuid+"<"+olduid+"<"+upass+"<"+levelupdate+" ");
			 	}
	 	}
	 }
	 if(counter1 > counter2+counter3  && changeuser==1)
		 alert("중복체크를 해주세요");
	 else if(counter3!=0)
		 alert("이미 존재하는 아이디입니다");
	 else
		 location.href="userupdate.jsp?checklist="+checklist;
	 
}

function changeuid(who){
	if(who ==='update'){
	 var cb = document.getElementsByName("selected");
	 for(var i=0; i<cb.length;i++){
		 if(cb[i].checked==true){
	    		document.getElementById("updatecvalue_"+i).value = "change";
	    }
	 }
	}else if(who === 'insert')
		document.getElementById("updatecvalue2").value = "change";
}
function goadmin(){
	 location.href="admin.jsp";
}