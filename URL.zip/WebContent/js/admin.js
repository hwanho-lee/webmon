function updateActive(no, active) {
	var url = document.getElementById('url_' + no).innerHTML;
	active = active == 0 ? 'Y' : 'N';
	var reserve = document.getElementById('reserve_' + no).innerHTML.split(" ");

	var start = new Date(reserve[0] + " " + reserve[1]);
	var end = new Date(reserve[3] + " " + reserve[4]);

	if (start < new Date() && end > new Date()) {
		var answer = confirm("비활성화 예약중인 시스템 입니다. 활성화 시키시겠습니까?");
		if (answer) {
			location.href = "updateactive.jsp?url=" + url + "&active=" + active
					+ "&withdel=yes";
		}
	} else {
		console.log("active2 값: " + active);
		var message = active == "Y" ? "비활성화" : "활성화";
		var answer = confirm(message + " 시키겠습니까?");

		if (answer) {
			location.href = "updateactive.jsp?url=" + url + "&active=" + active;
		}
	}
}
//
function setNonActive() {
	var startdate = document.getElementById("startdate").value;
	var starttime = document.getElementById("starttime").value;
	var enddate = document.getElementById("enddate").value;
	var endtime = document.getElementById("endtime").value;

	var start = new Date(startdate + " " + starttime);
	var end = new Date(enddate + " " + endtime);

	var urls = document.getElementsByName("selected");
	var j = 0;
	var checkdUrl = "";

	for (var i = 0; i < urls.length; i++) {
		if (urls[i].checked == true) {
			j++;
			checkdUrl += urls[i].value + "@";
		}
	}
	if (j === 0) {
		alert("예약한 URL을 선택해주세요");
	} else if (starttime === "" || startdate === "" || endtime === ""
			|| enddate === "") {
		alert("정확한 시간을 입력해주세요");
	} else if (start < new Date()) {
		alert("현재날짜보다 이전은 선택하실 수 없습니다");
	} else if (end < start) {
		alert("종료날짜가 시작날짜보다 빠를 수 없습니다");
	} else {
		location.href = "setnonactive.jsp?urls=" + checkdUrl + "&startdate="
				+ startdate + " " + starttime + "&enddate=" + enddate + " "
				+ endtime;
	}

}

function selectGroup(groupid) {
	var urls = document.getElementsByName("selected");
	for (var i = 0; i < urls.length; i++) {
		if (urls[i].id.substring(12, 13) == groupid) {
			urls[i].checked = document
					.getElementById("groupselected" + groupid).checked == true ? true
					: false;
		}
	}
}
function updatebutton() {
	var selected = document.getElementsByName("selected");
	document.getElementById("updatebutton").style.display = "none";
	// document.getElementById("buttons").style.display="block";
	document.getElementById("inserttable").style.display = "none";
	document.getElementById("groupname2").value = null;
	document.getElementById("sysname").value = null;
	document.getElementById("groupname").value = null;
	document.getElementById("groupdiv").style.display = "block";
	document.getElementById("sysdiv").style.display = "block";
	document.getElementById("groupdiv2").style.display = "none";
	document.getElementById("sysdiv2").style.display = "none";
	document.getElementById("hostname").value = null;
	document.getElementById("url").value = null;

	for (var i = 0; i < selected.length; i++) {
		if (selected[i].checked == true) {
			document.getElementById("updatesys1_" + (i + 1)).style.display = "block";
			document.getElementById("updatehost1_" + (i + 1)).style.display = "block";
			document.getElementById("updateurl1_" + (i + 1)).style.display = "block";
			document.getElementById("updatesys2_" + (i + 1)).style.display = "none";
			document.getElementById("updatehost2_" + (i + 1)).style.display = "none";
			document.getElementById("updateurl2_" + (i + 1)).style.display = "none";
		}
	}
}

function setReserve(yn) {
	if (yn == "yes") {
		updatebutton();
		document.getElementById("inserttable").style.display = "none";
		document.getElementById("updatebutton").style.display = "none";

		var items = document.getElementsByName("selected");
		var j = 0;

		for (var i = 0; i < items.length; i++) {
			if (items[i].checked == true) {
				j++;
				if ((document.getElementById("reserve_" + (i + 1)).innerHTML
						.trim()) != "-") {
					answer = confirm("해당 시스템의 예약이 이미 존재합니다. 예약하시겠습니까?");
					if (answer == true) {
						break;
					} else {
						return;
					}
				}
			}
		}

		if (j == 0)
			alert("예약할 URL을 선택해주세요");
		else {
			document.getElementById("activereserve").style.display = "block";
			// document.getElementById("buttons").style.display="none";
		}
	} else {
		document.getElementById("startdate").value = null;
		document.getElementById("starttime").value = null;
		document.getElementById("enddate").value = null;
		document.getElementById("endtime").value = null;
		document.getElementById("activereserve").style.display = "none";
		// document.getElementById("buttons").style.display="block";

	}
}

function insertsystem(){
	 var groupname = document.getElementById("groupname");
	 var sysname = document.getElementById("sysname");
	 var hostname = document.getElementById("hostname").value;
	 var url = document.getElementById("url").value;
	 var groupvalue = groupname.options[groupname.selectedIndex].value;
	 var sysvalue = sysname.options[sysname.selectedIndex].value;
	  
	 var overlap=document.getElementById("insertvalue").value;
	 
	 if(groupvalue==="add")
	 {
		 groupvalue=document.getElementById("groupname2").value;
	 }
	 if(sysvalue==="add")
	 {
		 sysvalue=document.getElementById("sysname2").value;
	 }
	 
	 if(hostname=='' || url=='' || groupvalue=='' || sysvalue== '')
	 {
		 alert("모두 입력해주세요");
	 }else if(document.getElementById("updatecvalue2").value === "change" || overlap === "insert"){
		 alert("중복체크를 해주세요");
		 
	 }else if(overlap == "y"){
		 alert("이미 존재하는 호스트 이름입니다");
	 }else{
			 location.href="urlinsert.jsp?groupname="+groupvalue+"&sysname="+sysvalue+"&hostname="+hostname+"&url="+url;
	 }
}
function insertoverlap() {
	var counter = 0;
	var selected = document.getElementsByName("selected");

	var newhost = document.getElementById("hostname").value;
	// var overlap=document.getElementById("insertvalue").value;

	if (newhost != '') {

		for (var i = 0; i < selected.length; i++) {
			document.getElementById("updatecvalue2").value = "";
			oldhost = document.getElementById("host2_" + (i + 1)).value;

			if (oldhost === newhost) {
				counter = 2;
				alert("이미 존재하는 호스트 이름입니다");
				document.getElementById("insertvalue").value = 'y';
			}
		}
		if (counter == 0) {
			document.getElementById("insertvalue").value = 'n';
			alert("추가 가능한 호스트 이름입니다");
		}

	} else {
		alert('모두 입력해주세요');
	}
}

function updateoverlap(index) {

	var counter = 0;
	var j = index - 1;
	var selected = document.getElementsByName("selected");
	// var overlap='';
	var newhost = document.getElementById("updatehost_" + index).value;
	

	if (newhost != '') {

		for (var i = 0; i < selected.length; i++) {

			oldhost = document.getElementById("host2_" + (i + 1)).value;
			// overlap=document.getElementById("updatevalue_"+j).value;
			document.getElementById("updatecvalue_"+(i+1)).value = "";

			if (i == j) {
			}
			else if (oldhost === newhost) {
				counter = 2;
				alert("이미 존재하는 호스트 이름입니다");
				document.getElementById("updatevalue_" + index).value = 'y';
			}
		}

		if (counter == 0) {
			document.getElementById("updatevalue_" + index).value = 'n';
			alert("추가 가능한 호스트 이름입니다");
		}
	} else {
		alert('모두 입력해주세요');
	}
}
function urlinsert() {
	
	var urls = document.getElementsByName("selected");

	for (var i = 0; i < urls.length; i++) {
		urls[i].checked = false;
	}
	
	updatebutton();
	document.getElementById("activereserve").style.display = "none";
	document.getElementById("updatebutton").style.display = "none";
	document.getElementById("inserttable").style.display = "block";
	// document.getElementById("buttons").style.display="none";
}

function addtext(who) {
	if(who === 'group'){
		var groupname = document.getElementById("groupname");
		var groupvalue = groupname.options[groupname.selectedIndex].value;
		if (groupvalue === 'add') {
			document.getElementById("groupdiv2").style.display = "block";
			document.getElementById("groupdiv").style.display = "none";

		}
	}else if(who === 'sys'){
		var sysname = document.getElementById("sysname");
		var sysvalue = sysname.options[sysname.selectedIndex].value;
		if (sysvalue === "add") {
			document.getElementById("sysdiv2").style.display = "block";
			document.getElementById("sysdiv").style.display = "none";
		}
	}
}
function urldelete() {
	var counter = 0;
	var selected = document.getElementsByName("selected");
	var checklist = new Array();

	for (var i = 0; i < selected.length; i++) {
		if (selected[i].checked == true) {
			counter++;
			checklist.push(selected[i].value);
		}
	}
	if (counter == 0) {
		alert("삭제할 시스템을 선택하세요");
	} else {
		var answer = confirm("선택하신 URL을 삭제하시겠습니까?");
		if (answer == true) {
			location.href = "urldelete.jsp?checklist=" + checklist;
		}
	}
}
function urlupdate() {
	document.getElementById("inserttable").style.display = "none";
	document.getElementById("activereserve").style.display = "none";
	
	var selected = document.getElementsByName("selected");
	var counter = 0;

	for (var i = 0; i < selected.length; i++) {
		if (selected[i].checked == true) {
			counter++;
			document.getElementById("updatesys1_" + (i + 1)).style.display = "none";
			document.getElementById("updatehost1_" + (i + 1)).style.display = "none";
			document.getElementById("updateurl1_" + (i + 1)).style.display = "none";
			document.getElementById("updatesys2_" + (i + 1)).style.display = "block";
			document.getElementById("updatehost2_" + (i + 1)).style.display = "block";
			document.getElementById("updateurl2_" + (i + 1)).style.display = "block";
		}
	}
	if (counter == 0) {
		alert("수정할 시스템을 선택하세요");

	} else {
		document.getElementById("updatebutton").style.display = "block";
		// document.getElementById("buttons").style.display="none";
	}
}
function updatesuccess(){
	
	 var checklist = new Array();
	 var counter1=0;
	 var counter2=0;
	 var counter3=0;
	 var changehost=0;
	 
	 
	 var selected = document.getElementsByName("selected");
	
	 for(var i=0; i<selected.length;i++){
		 if(selected[i].checked==true){
			    counter1++;
			    if(document.getElementById("updatecvalue_"+(i+1)).value ==="change"){
			    	changehost=1;
			    }
		 	
			var sysname=  document.getElementById("updatesys_"+(i+1)).value;
			var oldhost = document.getElementById("host2_"+(i+1)).value;
			var newhost= document.getElementById("updatehost_"+(i+1)).value;
			var url = document.getElementById("updateurl_"+(i+1)).value;
			var overlap=document.getElementById("updatevalue_"+(i+1)).value;
				 if(overlap=="n"){
					 counter2++;
				 }else if(overlap=="y"){
					 counter3++;
				 }
				 
			 	if(sysname=='' || hostname=='' || newhost==''){
			 	  	counter=1;
			 	  	alert("모두 입력하세요");
			 	  	break;
			 	}
			 	else{
			 		checklist.push(sysname+"<"+newhost+"<"+oldhost+"<"+url+" ");
			 	}
	 	}
	} 

	 if(counter1 > counter2+counter3 && changehost==1)
		 alert("중복체크를 해주세요");
	 else if(counter3!=0)
		 alert("이미 존재하는 호스트 이름입니다");
	 else
		 location.href="urlupdate.jsp?checklist="+checklist;
		
}
function checklevel(level) {
	if (level != "1") {
	}
}
function goindex(){
	location.href = "../index.jsp";
}
function userInfo() {
	location.href = "userinfo.jsp";
}

function logout(){
	answer = confirm("로그아웃 하시겠습니까?");
	if(answer){
		location.href="/URL/admin/logout.jsp";
	}
}

function goadmin(level){
	//alert(level);
	if(level=='1'){
		location.href="./admin/admin.jsp";
	}else{
		location.href="./login.jsp";
	}
		
		
}
function refresh() {
	location.reload();
}

function changehost(who){
	if(who ==='update'){
	 var selected = document.getElementsByName("selected");
		 for(var i=0; i<selected.length;i++){
		    if(selected[i].checked==true){
		    		document.getElementById("updatecvalue_"+(i+1)).value = "change";
		    }
		 }
	}else if(who === 'insert')
			document.getElementById("updatecvalue2").value = "change";
}

jQuery(document).ready(function() {  
    var duration = 500;  
      
    jQuery('#setReserve').click(function(event) {  
        event.preventDefault();  
        jQuery('html, body').animate({scrollTop: document.body.scrollHeight}, duration);  
        return false;  
    })
    
    jQuery('#addUrl').click(function(event) {  
        event.preventDefault();  
        jQuery('html, body').animate({scrollTop: document.body.scrollHeight}, duration);  
        return false;  
    })
});  

