package log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;

import dao.urlvo;


public class LogFile {
	
	
	public LogFile(ArrayList<urlvo> errlist)
	{
		FileWriter fw = null;
		BufferedWriter bw = null;
		//String FileDir = "D:\\a.log";

		String FileDir = getProperties("FileDir");
		System.out.println(FileDir);
		
		try{		
			fw = new FileWriter(FileDir);
			bw = new BufferedWriter(fw);
		
			for(urlvo vo : errlist)
			{
				//bw.write(vo.getSysname()+","+vo.getUrl());
				bw.newLine();
			}
			bw.close();
			System.out.println("�α����ϻ�");
			
		}catch(IOException ie)
		{
			ie.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public String getProperties(String keyname)
	{
		String value = null;
		try{		
			ResourceBundle bundle = ResourceBundle.getBundle("log");
			value = bundle.getString(keyname);			
		}catch (Exception e) {
		e.printStackTrace();
		}
	return value;
	}
}