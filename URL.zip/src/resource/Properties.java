package resource;

import java.util.ResourceBundle;

public class Properties {
	
	public static ResourceBundle getProperties(String propertiesName)
	{
		ResourceBundle bundle = null;
		
		try{		
			bundle = ResourceBundle.getBundle(propertiesName);			
		}catch (Exception e) {
			e.printStackTrace();
		}
	return bundle;
	}
}
