package db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.mysql.jdbc.*;

public class DBConnector {
	
	static String jndi_name = "java:comp/env/jdbc/urlcheckDB";
	
	public DBConnector(){

	}
	
	public static Connection getConnection(){
		DataSource ds;
		Connection con = null;
		try{
			ds = (DataSource)new InitialContext().lookup(jndi_name);
//			System.out.println("DB Connecting");
			con = ds.getConnection();
			
		}catch(NamingException ne){
			System.out.println("Get datasource NamingException : "+ne);
		}catch(SQLException se){
			System.out.println("Get Connection Exception : "+se);
		}catch(Exception e){
			System.out.println("Get datasource Exception : "+e);
		}
//		System.out.println("DB Connected");
		
		return con;
	}

	public static void releaseConnection(Statement stmt, ResultSet rs){
		try{
			if(rs != null){
				try{rs.close();rs = null;}catch(SQLException e){e.printStackTrace();}
			}
			if(stmt != null){
				try{stmt.close();stmt = null;}catch(SQLException e){e.printStackTrace();}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}	
	
	public void releaseConnection(Connection con){
		try{
			if(con != null){
				try{con.close();con = null;}catch(SQLException e){e.printStackTrace();}				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}	
/*	
	public static void releaseConnection(Connection con, Statement stmt, ResultSet rs){
		try{
			if(rs != null){
				try{rs.close();rs = null;}catch(SQLException e){e.printStackTrace();}
			}
			if(stmt != null){
				try{stmt.close();stmt = null;}catch(SQLException e){e.printStackTrace();}
			}
			if(con != null){
				try{con.close();con = null;}catch(SQLException e){e.printStackTrace();}				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/	

}
