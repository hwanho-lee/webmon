package scheduler;

import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.Calendar;
import java.util.Date;

import org.apache.catalina.tribes.util.Arrays;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import url.UrlStatusCheck;
import dao.UrlDataDao;
import dao.urlvo;
import db.DBConnector;
import url.URLCheck;

public class Job_MyAlarmData
  implements Job
{
  public void execute(JobExecutionContext arg0)
    throws JobExecutionException
  {
    getMyAlarmData();
  }

  public void getMyAlarmData() {	  
	  
	  URLCheck urlCheck = new URLCheck();
	  ArrayList<urlvo> errlist = urlCheck.urlcheck();
  }
		
}

