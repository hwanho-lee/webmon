package scevent;
import java.io.IOException;
import java.util.ResourceBundle;

public class SCevent
{
	
public static void main(String args[])   
	{
	startProcess rt1 = new startProcess();

	}

}

/*
class StreamGobbler extends Thread {
	
	InputStream is;
	String type;
	
public StreamGobbler(InputStream is, String type){
	this.is = is;
	this.type = type;
}
public void run(){
	
	InputStreamReader isr = new InputStreamReader(is);
	BufferedReader br = new BufferedReader(isr);
	String line = null;
	
	try{
	System.out.println("run");
	
	
//	Thread.sleep(5000);
	
		while((line = br.readLine()) != null){
			System.out.println(type+" > "+line);
			
		//	p.destroy();
			
		}
		
		
	}catch(IOException ioe){
		ioe.printStackTrace();
	}catch(Exception e){
		e.printStackTrace();
	}finally{
	
		try {
				if (is != null){
					is.close();
				}
				else if (isr != null){
					isr.close();
				}
				else if (br != null){
					br.close();		
				}
			}catch(IOException io){
				io.printStackTrace();
			 }
		}
	}
}
*/
class startProcess{
	
public startProcess(){

//String[] cmdArray = {"scevnet.exe","-h","10.225.133.144.","-s","1","-d",""}		
	try {
		
		String time = getProperties("time");
		String hostname = getProperties("hostname");
		String sysname = getProperties("sysname");
		String error = getProperties("hostname");
		String discription=time + sysname + hostname + error ;
		String[] cmdArray ={hostname,time};
		
		Process	p = Runtime.getRuntime().exec(cmdArray);
				
			//StreamGobbler err = new StreamGobbler(p.getErrorStream(),"ERROR");
			//StreamGobbler out = new StreamGobbler(p.getInputStream(), "INPUT");
			//err.start();
			//out.start();
					
			p.getErrorStream().close();
			p.getInputStream().close();
			p.getOutputStream().close();
				
		}catch(IOException ioe){
			System.out.println("IOExcepion");
		} catch (Exception e) {
			System.out.println("Excepion");
		}		
	}



public String getProperties(String keyname)
{
	String value = null;
		try{		
			ResourceBundle bundle = ResourceBundle.getBundle("scevent");
			value = bundle.getString(keyname);			
		}catch (Exception e) {
		System.out.println("Excepion");
		}
	return value;
	}
}



