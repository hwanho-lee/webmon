/* author changhoon.yeo */
package url;

import java.net.*;  
import java.io.*;  

public class UrlStatusCheck{  
	public String url = null;  
	public long timeOut = 0;  

public UrlStatusCheck( String url, int timeOut ){  
	this.url = url;  
	this.timeOut = (long) timeOut;  
}  

public int getResponseCode()  
{  
	UrlCheckProcess aUrlCheckProcess = new UrlCheckProcess( url );  
	aUrlCheckProcess.start();

	try{  
		aUrlCheckProcess.join( timeOut ) ;  
	}  
	catch( Exception e )  
	{
		e.printStackTrace();
	}  
	if( aUrlCheckProcess.isConnected() == false ){  
		synchronized( aUrlCheckProcess ){  
			System.out.println("Timed out!!");   
			aUrlCheckProcess.reapResources();  
		}  
	}  
		int responseCode = aUrlCheckProcess.responseCode();
		return responseCode;  
}  

public String getProbeStatus()  
{
	String status = null;
	UrlCheckProcess aUrlCheckProcess = new UrlCheckProcess( url );  
	aUrlCheckProcess.start();

	try{  
		aUrlCheckProcess.join( timeOut ) ;  
	}  
	catch( Exception e )  
	{
		e.printStackTrace();
	}  
	if( aUrlCheckProcess.isConnected() == false ){  
		synchronized( aUrlCheckProcess ){  
			System.out.println("Timed out!!");   
			aUrlCheckProcess.reapResources();  
		}  
	}  
		int responseCode = aUrlCheckProcess.responseCode();
		return status;  
	}  
}
