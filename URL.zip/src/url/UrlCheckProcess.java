/* author changhoon.yeo */

package url;

import java.net.*;  
import java.io.*;  

import javax.net.ssl.HttpsURLConnection;

public class UrlCheckProcess extends Thread  
{  
	HttpURLConnection aHttpURLConnection = null;
	HttpsURLConnection aHttpsURLConnection = null;

	String url = null;  

	boolean isConnected = false;  

	int responseCode = 0;  

	public UrlCheckProcess( String url )  
	{  
		this.url = url;  
	}  

	public void run()  
	{  
		System.out.println("");
		System.out.println("==================== URL Check START ====================");  

		try  
		{  
			System.out.println("URL : " + url );  

			URL aURL = new URL( url );
			if (url.substring(0, 5).equals("https")) {
				aHttpsURLConnection = (HttpsURLConnection) aURL.openConnection();
				responseCode = aHttpsURLConnection.getResponseCode();
			}else{
				aHttpURLConnection = (HttpURLConnection) aURL.openConnection();
				//aHttpURLConnection.setConnectTimeout(3000);
				responseCode = aHttpURLConnection.getResponseCode();  
			}
		}  
		catch( Exception e )  
		{
			responseCode=-1;
		}  

		System.out.println("======================== Finished =======================");  

		isConnected = true;
	}  

	public boolean isConnected()  
	{  
		return isConnected ;  
	}  

	public int responseCode()  
	{  
		return responseCode;  
	}  

	public void reapResources()  
	{  
		System.out.println("Reap the resources.") ;
		if (url.substring(0, 5).equals("https")) {
			if (aHttpsURLConnection!=null) {
				aHttpsURLConnection.disconnect();
			}
		}else{
			if (aHttpURLConnection!=null) {
				aHttpURLConnection.disconnect();
			}
		}
	}  
}  

