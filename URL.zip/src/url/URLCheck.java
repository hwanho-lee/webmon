package url;

import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import url.UrlStatusCheck;
import resource.Properties;
import dao.UrlDataDao;
import dao.urlvo;
import db.DBConnector;

public class URLCheck {

	DBConnector ds = new DBConnector();
	Connection con = ds.getConnection();
	  
	ArrayList<urlvo> urllist;
	ArrayList<urlvo> errlist;
	ArrayList<urlvo> resultlist;
	UrlDataDao dao = new UrlDataDao();
	
	public ArrayList<urlvo> urlcheck(){
		
		ResourceBundle getProperties = Properties.getProperties("app");
		int timeOut = Integer.parseInt(getProperties.getString("url.check.timeout"));
		int responseCode = 0; // responseCode init
		
		urllist=dao.getUrlList(con);
		resultlist=new ArrayList<urlvo>();
		errlist=new ArrayList<urlvo>();
		
		for(urlvo vo:urllist){
			if(vo.getStartdate()!=null&&vo.getEnddate()!=null){
				if(new Date().after(vo.getStartdate())) {
					if(new Date().after(vo.getEnddate())){
						dao.deleteActiveReserve(vo.getUrl(), con);
						dao.updateActive(vo.getUrl(), "N", con);
					}else if(vo.getActive().equals("Y")){
						dao.updateActive(vo.getUrl(), "Y", con);
					}
					
				}
			}
			if(!vo.getActive().equals("N") && !vo.getGroupname().equals("PROBE")){
				String url = vo.getUrl();
				UrlStatusCheck aUrlStatusCheck = new UrlStatusCheck(url, timeOut);  
				responseCode = aUrlStatusCheck.getResponseCode();

				int resCode = responseCode/100;
				
				if(resCode==4 || resCode==5 || responseCode==-1){ 
					errlist.add(vo);
					if(!vo.getStatus().equals("E"))resultlist.add(new urlvo(vo.getUrl(), "E"));
					dao.insertHistory(vo.getHostname(), "e", con); //check_his Table history insert | e-error | t-timeout | n-normal |
					System.out.println("Host Name : "+vo.getHostname()+" State : "+vo.getStatus());
					runtimeTest(vo.getHostname(),"error");
				}else if(responseCode==0){
					if(!vo.getStatus().equals("T"))resultlist.add(new urlvo(vo.getUrl(), "T"));
					dao.insertHistory(vo.getHostname(), "t", con);
					System.out.println("Host Name : "+vo.getHostname()+" State : "+vo.getStatus());
					runtimeTest(vo.getHostname(),"timeout");
				}else{
					if(!vo.getStatus().equals("A"))resultlist.add(new urlvo(vo.getUrl(), "A"));
					dao.insertHistory(vo.getHostname(), "a", con);
				}
			}else if(!vo.getActive().equals("N") && vo.getGroupname().equals("PROBE")){
				System.out.println("PROBE 따로 분리 : " + vo.getHostname());
				String probeUrl = vo.getUrl();
				UrlStatusCheck aUrlStatusCheck = new UrlStatusCheck(probeUrl, timeOut);
				String probeResponseCode = aUrlStatusCheck.getProbeStatus();			
			}else{
				dao.insertHistory(vo.getHostname(), "i", con);
			}
		}
		
		dao.updateStatus(resultlist, con);	
		
		// Connection pool release
		ds.releaseConnection(con);
		
		System.out.println();
		return errlist;
	}
	
	public void runtimeTest(String host,String status){
		try{
			String dummyhost=host;
			long time = System.currentTimeMillis();
			SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd hh:mm");
			String date = dateformat.format(new Date(time));
			
			if(!(host.equals("IM1-WAS-Part") || host.equals("IM1-WAS-Part1") || host.equals("IM1-WAS-Part2"))){
				
				 dummyhost="IM1-WAS-Part";
			}

			String[] cmdArray = {"sms_scevent.sh","-h",dummyhost,"-s","1","-d","[URLCheck]_"+date.split(" ")[0]+"_"+date.split(" ")[1]+"_"+host+"에서"+status+"발생했습니다.","TEST_EVENT"};
//			String[] cmdArray = {"sms_scevent.sh","-h",host,"-s","1","-d","[TEST]"+date.split(" ")[0]+" "+date.split(" ")[1]+" "+host+" "+status+" ","TEST_EVENT"};
			
			Process p = Runtime.getRuntime().exec(cmdArray);
			
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch (IllegalThreadStateException itse) {
			itse.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
