package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import db.DBConnector;

public class UserDataDao {
	public UserDataDao(){}
	
	public ArrayList<UserVO>getAllUserList(Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<UserVO> alluser = new ArrayList<UserVO>();
		
		String sql = "select * from user";
		
		try{
			stmt = con.createStatement();
			rs  = stmt.executeQuery(sql);
			while(rs.next()){
				UserVO uservo = new UserVO(rs.getString(1),rs.getString(2),rs.getString(3));
				alluser.add(uservo);
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
			return alluser;
	}
	
	public ArrayList<UserVO> getUserList(String uid,String pwd,Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		ArrayList<UserVO> userlist = new ArrayList<UserVO>();
	
		String getuser = "select * from user where uid='"+uid+"' and upass='"+pwd+"';";
		try{
			stmt=con.createStatement();
			rs=stmt.executeQuery(getuser);
			while(rs.next()){
				UserVO vo = new UserVO(rs.getString(1),rs.getString(2),rs.getString(3));
				userlist.add(vo);
			}	
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		return userlist;
	}
	
	public void userInsert(String uid,String upass,String ulevel,Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "insert into user values ('"+uid+"','"+upass+"','"+ulevel+"');";

		try{
			
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		
	}

	public void userupdate(String newuid,String olduid, String upass,String ulevel,Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		String sql = "update user set uid='"+newuid+"',upass='"+upass+"',ulevel='"+ulevel+"' where uid='"+olduid+"';";
		try{
			stmt = con.createStatement();
			stmt.execute(sql);
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		
	}
	public void userdelete(String uid,Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "delete from user where uid='"+uid+"';";
		try{
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	

}
