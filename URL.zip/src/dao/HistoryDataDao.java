package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import db.DBConnector;

public class HistoryDataDao {
	public ArrayList<HistoryVO> getHistoryList(String hostname, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		ArrayList<HistoryVO> list = new ArrayList<HistoryVO>();
		
		String sql = "select * from history where hostname='"+hostname+"' and checkdate > date_sub(now(), interval 6 hour)";
		
		System.out.println("Conn id : " + con);
		try{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()){
				HistoryVO vo = new HistoryVO(rs.getTimestamp("checkdate")
						,rs.getString("hostname")
						,rs.getString("checkstatus"));
				list.add(vo);
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		return list;
	}
	
	public HistoryVO getNewHistory(String hostname, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		HistoryVO vo = null;
		
		String sql = "	select * from history where hostname='"+hostname+"' order by historyno desc limit 1";
		
		System.out.println("Conn id : " + con);
		try{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()){
				vo = new HistoryVO(rs.getTimestamp("checkdate")
						,rs.getString("hostname")
						,rs.getString("checkstatus"));
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		return vo;
	}
}
