package dao;

import java.sql.Timestamp;
import java.util.Date;

public class HistoryVO {
	Date checkdate;
	String hostname;
	String checkstatus;
	
	public HistoryVO(Date checkdate, String hostname, String checkstatus) {
		this.checkdate = checkdate;
		this.hostname = hostname;
		this.checkstatus = checkstatus;
	}
	public HistoryVO() {
		super();
	}
	public Date getCheckdate() {
		return checkdate;
	}
	public void setCheckdate(Date checkdate) {
		this.checkdate = checkdate;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getCheckstatus() {
		return checkstatus;
	}
	public void setCheckstatus(String checkstatus) {
		this.checkstatus = checkstatus;
	}
	
	
	

}
