package dao;

import java.util.Date;

public class urlvo {
	String groupname;
	String sysname;
	String hostname;
	String url;
	String active;
	String status;
	Date startdate;
	Date enddate;
	
	public urlvo(String grupname, String sysname, String url) {
		super();
		this.groupname = grupname;
		this.sysname = sysname;
		this.url = url;
	}
	
	
	//2014.05.31 hwanho add
	public urlvo(String grupname, String sysname, String url, String active, String status) {
		super();
		this.groupname = grupname;
		this.sysname = sysname;
		this.url = url;
		this.active = active;
		this.status = status;
	}
	
	public urlvo(String url, String status) {
		this.status=status; 
		this.url=url;
	}

	

	


	public urlvo(String grupname, String sysname, String hostname, String url,
			String active, String status) {
		super();
		this.groupname = grupname;
		this.sysname = sysname;
		this.hostname = hostname;
		this.url = url;
		this.active = active;
		this.status = status;
	}
	
	

	


	public urlvo(String groupname, String sysname, String hostname, String url,
			String active, String status, Date startdate, Date enddate) {
		super();
		this.groupname = groupname;
		this.sysname = sysname;
		this.hostname = hostname;
		this.url = url;
		this.active = active;
		this.status = status;
		this.startdate = startdate;
		this.enddate = enddate;
	}


	public String getGroupname() {
		return groupname;
	}


	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}


	public String getSysname() {
		return sysname;
	}


	public void setSysname(String sysname) {
		this.sysname = sysname;
	}


	public String getHostname() {
		return hostname;
	}


	public void setHostname(String hostname) {
		this.hostname = hostname;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getActive() {
		return active;
	}


	public void setActive(String active) {
		this.active = active;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Date getStartdate() {
		return startdate;
	}


	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}


	public Date getEnddate() {
		return enddate;
	}


	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}


	


	
}
