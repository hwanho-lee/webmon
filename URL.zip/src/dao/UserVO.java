package dao;

public class UserVO {
	String uid;
	String upass;
	String ulevel;
	
	public UserVO() {}
	
	public UserVO(String uid, String upass, String ulevel) {
		this.uid = uid;
		this.upass = upass;
		this.ulevel = ulevel;
	}
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	public String getUlevel() {
		return ulevel;
	}
	public void setUlevel(String ulevel) {
		this.ulevel = ulevel;
	}
	
}
