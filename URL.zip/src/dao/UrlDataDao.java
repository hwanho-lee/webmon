package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import db.DBConnector;

public class UrlDataDao {
	
	public UrlDataDao(){
	}

	public ArrayList<urlvo> getUrlList(Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		ArrayList<urlvo> list = new ArrayList<urlvo>();
		
		String sql = "select groupname, sysname, hostname, url, active, status, startdate, enddate from url order by groupname, sysname";
		
//		System.out.println("Conn id : " + con);
		try{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()){
				urlvo vo = new urlvo(rs.getString("groupname")
						,rs.getString("sysname")
						,rs.getString("hostname")
						,rs.getString("url")
						,rs.getString("active")
						,rs.getString("status")
						,rs.getTimestamp("startdate")
						,rs.getTimestamp("enddate"));
				list.add(vo);
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		return list;
	}
	

	public void updateStatus(ArrayList<urlvo> resultlist, Connection con) {
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			stmt = con.createStatement();
			for (urlvo urlvo : resultlist) {
				stmt.execute("update url set status='"+urlvo.getStatus()+"' where url='"+urlvo.getUrl()+"'");
			}		
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public void updateActive(String url, String active, Connection con) {
		Statement stmt = null;
		ResultSet rs = null;
		
		System.out.println(url+" "+active);
		try{
			stmt = con.createStatement();
			if(active.equals("Y")){
				stmt.execute("update url set status='I', active='N' where url='"+url+"'");
			}else{
				stmt.execute("update url set status='I', active='Y' where url='"+url+"'");
//				stmt.execute("update url set status='I', active='Y',startdate=null, enddate=null where url='"+url+"'");
			}
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public void insertHistory(String hostname, String chstatus, Connection con) {
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			stmt = con.createStatement();
			stmt.executeUpdate("insert into history(hostname, checkstatus) values('"+hostname+"', '"+chstatus+"')");
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	

	public void insertSystem(String groupname,String sysname,String hostname,String url, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		String sql="insert into url (groupname,sysname,hostname,url) values('"+groupname+"','"+sysname+"','"+hostname+"','"+url+"');";
		try{
			stmt=con.createStatement();
			stmt.executeUpdate(sql);
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public void deletesystem(String url,Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		String sql="delete from url where url='"+url+"';";
		try{
			stmt=con.createStatement();
			stmt.executeUpdate(sql);
			
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	public void updatesystem(String sysname,String newhost,String oldhost,String url, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		String sql="update url set sysname='"+sysname+"',hostname='"+newhost+"',url='"+url+"' where hostname='"+oldhost+"';";
		try{
			stmt=con.createStatement();
			stmt.execute(sql);
			
		}catch(SQLException sqlEx){
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public void setActiveReserve(String[] urls, String startdate, String enddate, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			stmt = con.createStatement();
			for (String url : urls) {
				stmt.execute("update url set startdate='"+startdate+"', enddate='"+enddate+"' where url='"+url+"'");
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public void setActiveReserve(String[] urls, String[] startdate, String[] enddate, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			stmt = con.createStatement();
			for (int i=0; i<urls.length; i++) {
				stmt.execute("update url set startdate='"+startdate[i]+"', enddate='"+enddate[i]+"' where url='"+urls[i]+"'");
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}	

	public void deleteActiveReserve(String url, Connection con) {
		Statement stmt = null;
		ResultSet rs = null;
		
		System.out.println("expired reserve : " + url);
		try{
			stmt = con.createStatement();
			stmt.execute("update url set startdate=null, enddate=null where url='"+url+"'");
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public ArrayList<urlvo> getReserveList(Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		ArrayList<urlvo> list = new ArrayList<urlvo>();		
		SimpleDateFormat dateFomat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		String sql = "select * from url where startdate is not null and enddate is not null order by groupname, sysname";
		
//		System.out.println("Conn id : " + con);
		try{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()){
				urlvo vo = new urlvo(rs.getString("groupname")
						,rs.getString("sysname")
						,rs.getString("hostname")
						,rs.getString("url")
						,rs.getString("active")
						,rs.getString("status")
						,rs.getTimestamp("startdate")
						,rs.getTimestamp("enddate"));
				list.add(vo);
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		return list;
	}
	
	public void deleteReserve(String[] urls, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			stmt = con.createStatement();
			for (String url : urls) {
				stmt.execute("update url set startdate=null, enddate=null where url='"+url+"'");
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
	}
	
	public ArrayList<urlvo> getReserve(String url, Connection con){
		Statement stmt = null;
		ResultSet rs = null;
		
		ArrayList<urlvo> list = new ArrayList<urlvo>();		
		SimpleDateFormat dateFomat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		String sql = "select * from url where url='"+url+"' order by groupname, sysname";
		
//		System.out.println("Conn id : " + con);
		try{
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()){
				urlvo vo = new urlvo(rs.getString("groupname")
						,rs.getString("sysname")
						,rs.getString("hostname")
						,rs.getString("url")
						,rs.getString("active")
						,rs.getString("status")
						,rs.getTimestamp("startdate")
						,rs.getTimestamp("enddate"));
				list.add(vo);
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnector.releaseConnection(stmt, rs);
		}
		return list;
	}
	

 }
