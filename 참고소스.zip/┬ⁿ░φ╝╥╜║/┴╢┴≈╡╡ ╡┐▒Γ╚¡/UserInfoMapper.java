package com.imoxion.sensmail.server.dao.mapper;

import com.imoxion.sensmail.common.domain.GroupInfo;
import com.imoxion.sensmail.server.beans.AllowCountryBean;
import com.imoxion.sensmail.server.beans.ImCapacityGroupBean;
import com.imoxion.sensmail.server.beans.ImUserInfoBean;
import com.imoxion.sensmail.server.beans.ImUserInfoOptionBean;
import com.imoxion.sensmail.server.beans.KeyPairBean;

import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * Created by sungg on 2017-03-08.
 */
public interface UserInfoMapper {

    public ImUserInfoBean getAliasUser(@Param("mhost") String mhost, @Param("alias") String alias);

    public List<String> getUserAlias(@Param("mhost") String mhost, @Param("userid") String userid);

    public ImUserInfoBean getUserInfo(@Param("mhost") String mhost, @Param("userid") String userid);

    public ImUserInfoBean getUserInfoForMailid(@Param("mhost") String mhost, @Param("mailid") String mailid);

    public List<ImUserInfoBean> getUserList(@Param("mhost") String mhost);

    public List<ImUserInfoBean> getAllUserList();

    public int getPasswordFail(@Param("mhost") String mhost, @Param("userid") String userid);

    public int getIsRealGroup(@Param("groupid") String groupid);

    public ImCapacityGroupBean getGroupCapSize(@Param("mhost") String mhost, @Param("groupid") String groupid);

    public void updateUserMailSize(@Param("mhost") String mhost, @Param("userid") String userid, @Param("currsize") long currsize);

    public void updateUserMailSizeMinus(@Param("mhost") String mhost, @Param("userid") String userid, @Param("currsize") long currsize);

    public void updateDisablePop3(@Param("mhost") String mhost, @Param("userid") String userid);

    public int updateDisableSmtp(@Param("mhost") String mhost, @Param("userid") String userid);

    public void updatePasswordFail(@Param("mhost") String mhost, @Param("userid") String userid);

    public List<ImUserInfoBean> getSizeAlertUser(@Param("user_ratio") int user_ratio);

    public String getUserPOP3Before(@Param("mhost") String mhost, @Param("userid") String userid, @Param("ipconn") String ipconn);
    
    public List<GroupInfo> getGroupList();

    public GroupInfo getGroupInfo(@Param("mhost") String mhost, @Param("gid") int gid);

    public List<AllowCountryBean> getDomainAllowCountryCode(@Param("mhost") String mhost);

    public List<AllowCountryBean> getUserAllowCountryCode(@Param("mhost") String mhost, @Param("userid") String userid);
    
    public ImUserInfoBean getUserInfoOfRkeyCode(@Param("rkey_code") String rkey_code);

	public void updateDeleteUserInfo(@Param("mhost") String mhost, @Param("userid") String userid, @Param("receiver_enable") int receiver_enable, @Param("currDate") Date currDate, @Param("modid") String modid);

	public void updateUserInfo(ImUserInfoBean userinfo);

	public void updateUserInfoOption(ImUserInfoOptionBean userInfoOption);

	public void updateDefaultGid(@Param("domain") String domain, @Param("gid") int gid);

	public void updateGuGid(@Param("domain") String domain, @Param("gid") int gid);

	public void updateStopGid(@Param("arg1") int arg1, @Param("arg2") int arg2, @Param("gid") int gid);

	public void insertUserInfo(ImUserInfoBean userinfo);

	public void insertUserInfoOption(ImUserInfoOptionBean userInfoOption);

	public int existMailId(@Param("mhost") String mhost, @Param("mailid") String mailid);
	
	public int insertKeyPairInfo(KeyPairBean keysBean);
}
