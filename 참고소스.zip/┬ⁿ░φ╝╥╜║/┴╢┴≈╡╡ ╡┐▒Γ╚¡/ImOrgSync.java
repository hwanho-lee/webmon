package com.imoxion.sensmail.server.custom;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;

import com.imoxion.common.database.ImDatabaseConnectionEx;
import com.imoxion.common.util.ImConfLoaderEx;
import com.imoxion.common.util.ImLoadBalance;
import com.imoxion.common.util.ImStringUtil;
import com.imoxion.common.util.ImUtils;
import com.imoxion.security.ImRSAKey;
import com.imoxion.security.ImSecurityLib;
import com.imoxion.sensmail.common.domain.GroupInfo;
import com.imoxion.sensmail.common.domain.UserInfo;
import com.imoxion.sensmail.common.logger.ErrorTraceLogger;
import com.imoxion.sensmail.server.beans.ImDomainInfoBean;
import com.imoxion.sensmail.server.beans.ImOrgCodeBean;
import com.imoxion.sensmail.server.beans.ImOrgGroupBean;
import com.imoxion.sensmail.server.beans.ImOrgMemberBean;
import com.imoxion.sensmail.server.beans.ImOrgTempBean;
import com.imoxion.sensmail.server.beans.ImUserInfoBean;
import com.imoxion.sensmail.server.beans.ImUserInfoOptionBean;
import com.imoxion.sensmail.server.beans.ImUserTempBean;
import com.imoxion.sensmail.server.beans.KeyPairBean;
import com.imoxion.sensmail.server.dao.ImSeoulOrgSyncDAO;
import com.imoxion.sensmail.server.logger.ImLoggerEx;

/**
 * 서울시청 통합메일 조직도 동기화
 * 
 * @author Seo MinJeong <dongguli@imoxion.com>
 * 
 */
public class ImSeoulOrgSync {
	private static ImConfLoaderEx confSensmail;
	
	private static String defaultDomain;																// 기본 도메인 (sensmail.xml 의 default 도메인을 읽어 옴)
	private static Map<String, ImDomainInfoBean> domainMap = new HashMap<String, ImDomainInfoBean>();	// 메일의 도메인 정보 (ims_tbldomain 데이터)
	private static Map<String, GroupInfo> groupInfoMap = new HashMap<String, GroupInfo>();
	
	private static String modId = "orgsync";
	private static Date currDate;
	private static String createMailId;																								// 메일 아이디를 생성하기 위한 날짜
	private static int mailIdSerial = 0;																									// 메일 아이디를 생성하기 위한 serial
	private static Map<String, ImLoadBalance> mhostTblNoMap = new HashMap<String, ImLoadBalance>();											// 메일 아이디 생성 시 할당 될 tableno
	private static Map<String, Map<String, ImLoadBalance>> mhostPartNoMap = new ConcurrentHashMap<String, Map<String, ImLoadBalance>>();	// 메일 아이디 생성 시 할당 될 partno
	
	// 기본 메일 박스 생성
	private static List<String> defaultMailBox = new ArrayList<String>(); // 사용자 추가 시 생성된 메일함 목록 (sensmail.xml 의 설정에 따라 생성된 메일함이 달라짐)
	
	private static String defaultPassword = "dkdlahtus";	// 기본 비밀번호
	private static String encodePasswd;						// 암호화된 비밀번호
	private static String passSecuType;						// 비밀번호 암호화 타입
	
	private static String updateTime;													// 동기화를 하기 위한 기준 시간 (ims_tbldomain 의 update_date)	
	private static Map<String, String> codeMap = new HashMap<String, String>(); 		// 동기화를 위한 그룹 Map	
	private static Map<String, String> deptCodeMap = new HashMap<String, String>();		// 조직도 그룹 orgname 동기화를 위한 Map
	private static List<ImUserTempBean> userTempList = new ArrayList<ImUserTempBean>();	// updateTime 을 기준으로 검색된 조직도 동기화 대상 사용자
	private static List<ImOrgTempBean> orgTempList = new ArrayList<ImOrgTempBean>();	// updateTime 을 기준으로 검색된 조직도 동기화 대상 그룹	
	
	// GID - 1 : 서울시청, 2 : 부서계정, 3 : 테스트, 4 : 자치구, 5 : 정지사용자, 6 : 별도메일발송, 7 : 외부사용자 
	public static final int GID_DEFAULT = 1;
	public static final int GID_DIVISION = 2;
	public static final int GID_TEST = 3;
	public static final int GID_GU = 4;
	public static final int GID_STOP = 5;
	public static final int GID_EXTERNAL = 7;
	
	public static void main(String[] args) {
		ImSeoulOrgSync sync = new ImSeoulOrgSync();
		
		String argDate = null;
		if (args.length > 0) {
			// 조직도 동기화 대상 시간을 지정한다.
			// arg 포맷은 yyyyMMdd 이다. (ex. 20170912)
			argDate = args[0];
		}
		
		try {
			// 센스 메일 로그 설정
			ImLoggerEx.initLog("orgsynclog.xml");
			
			ImLoggerEx.info("ORGSYNC", "========================= ImSeoulOrgSync - START =========================== ");
			ImLoggerEx.info("ORGSYNC", "[MAIN] args : {}, argDate : {}", args, argDate);
			
			// DB Connection
			ImDatabaseConnectionEx.init("mybatis-config.xml");			
			
			// sensmail의 설정 정보를 가져온다.
			confSensmail = new ImConfLoaderEx("sensmail.home","sensmail.xml","utf-8");
			defaultDomain = confSensmail.getProfileString("domain","default");
			if (defaultDomain == null || "".equals(defaultDomain)) {
				defaultDomain = "seoul.go.kr";
			}
			
			passSecuType = confSensmail.getProfileString("password", "type");
			encodePasswd = ImSecurityLib.makePassword(passSecuType, defaultPassword, false);
			
			defaultMailBox = sync.defaultMailBoxList();
			
			currDate = new Date();
			createMailId = getDateFormat(currDate, "yyyyMMddHHmm");
			
			ImLoggerEx.info("ORGSYNC", "[MAIN] defaultDomain : {}, passSecuType : {}, encodePasswd : {}, currDate : {}", 
					defaultDomain, passSecuType, encodePasswd, getDateFormat(currDate, "yyyyMMddHHmmss"));			
			
			// 메일의 도메인 목록을 가져온다.
			ImLoggerEx.info("ORGSYNC", "========================= getDomainInfo() - START =========================== ");
			domainMap = sync.getDomainInfo();
			ImLoggerEx.info("ORGSYNC", "========================= getDomainInfo() - END =========================== ");
			
			// 메일의 그룹정보를 가져온다.
			ImLoggerEx.info("ORGSYNC", "========================= getGroupInfo() - START =========================== ");
			groupInfoMap = sync.getGroupInfo();
			ImLoggerEx.info("ORGSYNC", "========================= getGroupInfo() - END =========================== ");
			
			// 조직도 동기화 최종 업데이트 시간정보를 가져온다.
			ImLoggerEx.info("ORGSYNC", "========================= getUpdateDate() - START =========================== ");
			updateTime = sync.getUpdateDate(argDate);
			ImLoggerEx.info("ORGSYNC", "[MAIN] getUpdateDate ==> updateTime : {}", updateTime);
			ImLoggerEx.info("ORGSYNC", "========================= getUpdateDate() - END =========================== ");
			
			// 조직 코드 값을 가져온다.
			ImLoggerEx.info("ORGSYNC", "========================= getVGuList() - START =========================== ");
			codeMap = sync.getVGuList();
			ImLoggerEx.info("ORGSYNC", "========================= getVGuList() - END =========================== ");
			
			// 조직도 동기화 할 조직 목록을 가져온다.
			ImLoggerEx.info("ORGSYNC", "========================= getVMailGroupTemp() - START =========================== ");
			orgTempList = sync.getVMailGroupTemp();
			ImLoggerEx.info("ORGSYNC", "[MAIN] Count Of orgTempList : {}", orgTempList.size());
			ImLoggerEx.info("ORGSYNC", "========================= getVMailGroupTemp() - END =========================== ");
						
			// 조직도 동기화 할 사용자 정보를 가져온다.
			ImLoggerEx.info("ORGSYNC", "========================= getImsUserTemp() - START =========================== ");
			userTempList = sync.getImsUserTemp();
			ImLoggerEx.info("ORGSYNC", "[MAIN] Count Of userTempList : {}", userTempList.size());
			ImLoggerEx.info("ORGSYNC", "========================= getImsUserTemp() - END =========================== ");
			
			// 사용자 동기화 진행
			ImLoggerEx.info("ORGSYNC", "========================= userSync() - START =========================== ");
			sync.userSync();
			ImLoggerEx.info("ORGSYNC", "========================= userSync() - END =========================== ");
			
			// 그룹정보를 업데이트 한다.
			ImLoggerEx.info("ORGSYNC", "========================= updateUserGid() - START =========================== ");
			sync.updateUserGid();
			ImLoggerEx.info("ORGSYNC", "========================= updateUserGid() - END =========================== ");			
			
			// 조직도 그룹 동기화 진행
			ImLoggerEx.info("ORGSYNC", "========================= orgSync() - START =========================== ");
			sync.orgSync();
			ImLoggerEx.info("ORGSYNC", "========================= orgSync() - END =========================== ");
			
			ImLoggerEx.info("ORGSYNC", "========================= updateDateDomainInfo() - START =========================== ");
			sync.updateDateDomainInfo();
			ImLoggerEx.info("ORGSYNC", "========================= updateDateDomainInfo() - END =========================== ");
			
			ImLoggerEx.info("ORGSYNC", "========================= ImSeoulOrgSync - END =========================== ");
					
		} catch (Exception e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
		}
	}
	
	/**
	 * 조직도 동기화 완료 후 동기화 시간 정보를 남긴다.
	 * @param currDate 
	 * @throws SQLException
	 */
	private void updateDateDomainInfo() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		try {
			dao.updateDateDomainInfo(currDate);
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}		
	}

	/**
	 * 조직도 사용자 동기화 후 일괄적으로 gid를 업데이트 한다.
	 * @throws SQLException
	 */
	private void updateUserGid() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		try {
			dao.updateUserGid(defaultDomain);
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}		
	}
	
	/**
	 * 조직도 사용자 동기화 처리
	 * @throws SQLException
	 */
	private void userSync() throws SQLException {
		if (userTempList == null || userTempList.size() == 0) {
			ImLoggerEx.info("ORGSYNC", "[userSync] userTempList is Empty.");
			return;
		}
		
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		try {
			for (ImUserTempBean userTempInfo : userTempList) {
				if (userTempInfo == null) continue;
				
				ImLoggerEx.info("ORGSYNC", "\n");
				ImLoggerEx.info("ORGSYNC", "[userSync] userTempInfo ==> rkey_code : {} - change_flag : {}, username : {}, deptcode : {}", 
						userTempInfo.getRkey_code(), userTempInfo.getChange_flag(), userTempInfo.getUsername(), userTempInfo.getDeptcode());
				
				// 조직도 동기화 제외 대상
				if (userTempInfo.getRkey_code() == null || "".equals(userTempInfo.getRkey_code())) continue;
				if (userTempInfo.getUsername() == null || "".equals(userTempInfo.getUsername())) continue;
				if (userTempInfo.getDeptcode() == null || "".equals(userTempInfo.getDeptcode())) continue;
				if (userTempInfo.getChange_flag() == null || 
					(! "I".equals(userTempInfo.getChange_flag()) && ! "U".equals(userTempInfo.getChange_flag()) && ! "D".equals(userTempInfo.getChange_flag()))) continue;
				
//				// 조직도 그룹 동기화의 orgname 을 위한 map
//				if (userTempInfo.getOrgname() != null && !"".equals(userTempInfo.getOrgname())) {
//					if (deptCodeMap == null || deptCodeMap.get(userTempInfo.getDeptcode()) == null) {
//						deptCodeMap.put(userTempInfo.getDeptcode(), userTempInfo.getOrgname());
//					}
//				}
				
				boolean existMailUser = false;
				// Rkey_code에 해당하는 사용자가 메일에 존재하는지 체크한다.
				ImUserInfoBean mUserInfo = getImsUserInfo(dao, userTempInfo.getRkey_code());
				
				ImUserInfoOptionBean mUserInfoOption = new ImUserInfoOptionBean();
				if (mUserInfo == null || mUserInfo.getUserid() == null) {
					ImLoggerEx.info("ORGSYNC", "[userSync] Do Not Exist Mail User Of rkey_code : {}", userTempInfo.getRkey_code());
					existMailUser = false;
					mUserInfo = new ImUserInfoBean();
				} else {
					ImLoggerEx.info("ORGSYNC", "[userSync] Exist Mail User Of rkey_code : {}, mhost : {}, userid : {}, mailid : {}", 
							userTempInfo.getRkey_code(), mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfo.getMailid());
					existMailUser = true;
					mUserInfoOption = mUserInfo.getOption();
				}
				
				if (! existMailUser && "D".equals(userTempInfo.getChange_flag())) {
					// 메일에 존재하지 않는 삭제 사용자는 더 이상 진행할 필요가 없음.
					continue;
				}
				
				// RECEIVER_ENABLE - 0 : 휴면 (사용안함), 1 : 정상(사용), 2 : 휴면해제대기, 3 : 가입대기, 4 : 정지 상태, 5 : 삭제대기, 11 : 휴면전환제외
				// 서울시청에서는 기존에 5를 삭제 대기로 사용하고 있어 그대로 유지시킨다.
				// 메일에서 삭제된 사용자는 조직도 동기화 대상에서 제외 시킨다.
				if (mUserInfo.getReceiver_enable() != null && mUserInfo.getReceiver_enable() == UserInfo.RECEIVER_ENABLE__DEL_WAIT) {
					ImLoggerEx.info("ORGSYNC", "[userSync] SKIP USER - rkey_code : {} - receiver_enable : {}", userTempInfo.getRkey_code(), mUserInfo.getReceiver_enable());
					continue;
				}				
				
				// 부서계정과  외부사용자는 조직도 동기화 대상에서 제외 시킨다.
				if (mUserInfo.getGid() != null && (mUserInfo.getGid() == GID_DIVISION || mUserInfo.getGid() == GID_EXTERNAL)) {
					ImLoggerEx.info("ORGSYNC", "[userSync] SKIP USER - rkey_code : {}, gid : {}", userTempInfo.getRkey_code(), mUserInfo.getGid());
					continue;
				}
				
				setUserBean(userTempInfo, mUserInfo, mUserInfoOption);
				ImLoggerEx.info("ORGSYNC", "[userSync] setUserBean ==> rkey_code:{}, name : {}, Domain:{}, Ahost:{}, gid:{}, deptcode:{}, deptname: {}, Sex:{}, Birthday:{}, Role:{}",
						mUserInfoOption.getRkey_code(), mUserInfo.getName(), mUserInfo.getDomain(), mUserInfo.getAhost(), mUserInfo.getGid(), mUserInfoOption.getDeptcode(), 
						mUserInfoOption.getDeptname(), mUserInfoOption.getSex(), mUserInfoOption.getBirthday(), mUserInfoOption.getRole());
				
				// 메일 사용자 추가 / 수정 / 삭제 처리를 함.
				userSyncProcess(dao, existMailUser, userTempInfo, mUserInfo, mUserInfoOption);
				
			}
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
	}
	
	/**
	 * 조직도 사용자 추가 / 수정 / 삭제 처리
	 * @param dao 
	 * @param existMailUser
	 * @param userTempInfo
	 * @param mUserInfo
	 * @param mUserInfoOption
	 * @throws SQLException 
	 */
	private void userSyncProcess(ImSeoulOrgSyncDAO dao, boolean existMailUser, ImUserTempBean userTempInfo, 
				ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption) throws SQLException {
		if (! existMailUser && "D".equals(userTempInfo.getChange_flag())) {
			// 비정상적으로 넘어 온 상태임
			return;
		}
		
		try {
			if ("D".equals(userTempInfo.getChange_flag())) {
				if(chkRetire(mUserInfoOption.getDeptcode())) {
					// 퇴직 사용자 일 경우
					mUserInfo.setReceiver_enable(UserInfo.RECEIVER_ENABLE__DEL_WAIT);		// 상태를 삭제대기로 변경함.		
					
					dao.deleteUserInfo(mUserInfo);
					//dao.deleteImsOrgMember(mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfoOption.getDeptcode(), currDate);
					ImLoggerEx.info("ORGSYNC", "[userSyncProcess] DELETE USER - rkey_code : {} - receiver_enable : {}", userTempInfo.getRkey_code(), mUserInfo.getReceiver_enable());
				} else {
					// 퇴직 사용자가 아닐 경우
					mUserInfo.setReceiver_enable(UserInfo.RECEIVER_ENABLE__SLEEP);		// 상태를 휴면으로 변경함.
					mUserInfo.setGid(GID_STOP);
					
					dao.updateUserInfo(mUserInfo, mUserInfoOption); // DB에 GID를 업데이트를 안함.
					//dao.deleteImsOrgMember(mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfoOption.getDeptcode(), currDate);
					ImLoggerEx.info("ORGSYNC", "[userSyncProcess] DISABLE USER - rkey_code : {} - receiver_enable : {}, deptcode : {}", userTempInfo.getRkey_code(), mUserInfo.getReceiver_enable(), mUserInfoOption.getDeptcode());
				}
			} else {
				if (! existMailUser) {				
					// 사용자 생성
					createMailUserInfo(dao, mUserInfo, mUserInfoOption);	// 메일 사용자 생성
					//orgMemberSync(dao, existMailUser, mUserInfo, mUserInfoOption);		// 조직도 사용자 추가
					
				} else {
					// 메일에 사용자가 존재할 경우
					mUserInfo.setReceiver_enable(UserInfo.RECEIVER_ENABLE__NORMAL); 	// 정상사용자
					if(chkRetire(mUserInfoOption.getDeptcode())) {
						// 퇴직 사용자 일 경우
						mUserInfo.setReceiver_enable(UserInfo.RECEIVER_ENABLE__SLEEP);	// 상태를 휴면으로 변경함.
						mUserInfo.setGid(GID_STOP); 									// 정지사용자 그룹
					}
										
					updateUserInfo(dao, mUserInfo, mUserInfoOption); // 사용자 정보 갱신 - DB에 GID를 업데이트를 안함.
					
					/*
					if (mUserInfo.getReceiver_enable() != UserInfo.RECEIVER_ENABLE__NORMAL) {
						// 퇴직 사용자이므로, 조직도에 보이지 않도록 처리함.
						dao.deleteImsOrgMember(mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfoOption.getDeptcode(), currDate);
						ImLoggerEx.info("ORGSYNC", "[userSyncProcess] DISABLE USER - rkey_code : {} - receiver_enable : {}, deptcode : {}", userTempInfo.getRkey_code(), mUserInfo.getReceiver_enable(), mUserInfoOption.getDeptcode());
					} else {
						orgMemberSync(dao, existMailUser, mUserInfo, mUserInfoOption);
						ImLoggerEx.info("ORGSYNC", "[userSyncProcess] UPDATE USER - rkey_code : {} - receiver_enable : {}", userTempInfo.getRkey_code(), mUserInfo.getReceiver_enable());
					}
					*/
				}
			}
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}		
	}	

	/**
	 * 사용자 정보를 갱신한다.
	 * @param dao
	 * @param mUserInfo
	 * @param mUserInfoOption
	 * @throws SQLException
	 */
	private void updateUserInfo(ImSeoulOrgSyncDAO dao, ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption) throws SQLException {		
		try {
			mUserInfoOption.setMhost(mUserInfo.getMhost());
			mUserInfoOption.setUserid(mUserInfo.getUserid());
			dao.updateUserInfo(mUserInfo, mUserInfoOption);
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
	}

	/**
	 * 조직도 동기화 시 메일에 사용자가 존재하지 않을 경우 생성한다.
	 * 사용자 생성 시  ims_userinfo / ims_userinfo_option / im_dir (메일함 생성) / ims_tbldomain (사용자 count 갱신) 
	 * 포털 DB (ldap_user_tbl)에 메일주소 변경을 한다.	 * 
	 * @param dao
	 * @param mUserInfo
	 * @param mUserInfoOption
	 * @throws SQLException
	 */
	private void createMailUserInfo(ImSeoulOrgSyncDAO dao, ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption) throws SQLException {
		// 메일에 사용자가 존재하지 않을 경우
		String sADomain = mUserInfo.getAhost();
		if (sADomain == null || "".equals(sADomain)) {
			sADomain = defaultDomain;
		}
		
		if (mUserInfo.getDomain() == null || "".equals(mUserInfo.getDomain())) {
			mUserInfo.setDomain(defaultDomain);
		}
		
		if (domainMap == null || domainMap.get(mUserInfo.getDomain()) == null) {
			return;
		}
				
		ImDomainInfoBean domainInfo = domainMap.get(mUserInfo.getDomain());
		
		String mhost = "M00001";
		if (StringUtils.isNotEmpty(domainInfo.getMhost())) {
			mhost = domainInfo.getMhost();
		}
		
		String tblno = getTableNo(mhost);
		int partNo = getPartNo(mhost, tblno);		
		
		String userid = getNewUserId();
		String mailId = getNewMailId(dao, mhost);
		ImLoggerEx.info("ORGSYNC", "[createMailUserInfo] rkey_code : {} - mhost : {}, userid : {}, mailid : {}, domain : {}, username : {}, tblno : {}, partNo : {}", 
				mUserInfoOption.getRkey_code(), mhost, userid, mailId, mUserInfo.getDomain(), mUserInfo.getName(), tblno, partNo);
		
		mUserInfo.setMhost(mhost);
		mUserInfo.setUserid(userid);
		mUserInfo.setMailid(mailId);
		mUserInfo.setPasswd(encodePasswd);
		mUserInfo.setPwd_type(passSecuType);
		mUserInfo.setAhost(sADomain);
		mUserInfo.setUtype("U");
		mUserInfo.setPerms("U");
		mUserInfo.setCall("0");
		mUserInfo.setAccount(0);
		mUserInfo.setIsspam(0);
		mUserInfo.setIscapgroup(0);
		mUserInfo.setCapgroup_id("");
		mUserInfo.setCurrsize(Long.valueOf(0));
		mUserInfo.setInbox_key("Inbox_" + userid); // 사용자의 받은 메일함 설정
		mUserInfo.setDel_time(0);
		mUserInfo.setReceiver_enable(UserInfo.RECEIVER_ENABLE__NORMAL);		
		if(chkRetire(mUserInfoOption.getDeptcode())) {
			// 퇴직 사용자 일 경우
			mUserInfo.setReceiver_enable(UserInfo.RECEIVER_ENABLE__SLEEP);
			mUserInfo.setGid(GID_STOP); 	// 정지사용자 그룹
		}
		
		mUserInfo.setMboxsize(domainInfo.getMbsize());
		mUserInfo.setPdssize(domainInfo.getFilesize());
		mUserInfo.setAttachsize(domainInfo.getAttachsize());
		mUserInfo.setPopenable(domainInfo.getPopenable());
		mUserInfo.setImapenable(domainInfo.getImapenable());
				
		if (groupInfoMap != null) {
			String groupKey = mhost +"_"+ mUserInfo.getGid();
			if (groupInfoMap.get(groupKey) != null) {
				GroupInfo groupInfo = groupInfoMap.get(groupKey);
				mUserInfo.setMboxsize(groupInfo.getMbox_size());
				mUserInfo.setPdssize(groupInfo.getPds_size());
				mUserInfo.setAttachsize(groupInfo.getAttach_size());
				mUserInfo.setImapenable(groupInfo.getImap_perm().equals("1") ? 1 : 0 ); // IMAP 권한
				mUserInfo.setPopenable(groupInfo.getPop3_perm().equals("1") ? 1 : 0 ); // POP3 권한
			}
		}		
		
		mUserInfo.setTbl_no(tblno);
		mUserInfo.setPart_no(partNo);		
		mUserInfo.setRegdate(currDate);
		
		mUserInfoOption.setMhost(mhost);
		mUserInfoOption.setUserid(userid);
		mUserInfoOption.setSl_flag("0");
		mUserInfoOption.setZipcode("");
		mUserInfoOption.setAddress("");
		
		KeyPairBean keysBean = null;
//		try {
//			ImRSAKey keys = ImRSASecurity.createRSAKey64(2048);
//			String publicKey = keys.getPublickey();
//			String privateKey = keys.getPrivateKey();
//			
//			keysBean = new KeyPairBean();
//			keysBean.setMhost(mUserInfo.getMhost());
//			keysBean.setUserid(mUserInfo.getUserid());
//			keysBean.setPublic_key(publicKey);
//			keysBean.setPrivate_key(privateKey);
//			keysBean.setRegdate(new Date());
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		dao.insertUserInfo(mUserInfo, mUserInfoOption, defaultMailBox, keysBean);
		dao.updatePortal(mUserInfoOption.getRkey_code(), mailId +"@"+ mUserInfo.getDomain());
		ImLoggerEx.info("ORGSYNC", "[createMailUserInfo] updatePortal Of rkey_code : {} - innermail : {}", mUserInfoOption.getRkey_code(), mailId +"@"+ mUserInfo.getDomain());
		ImLoggerEx.info("ORGSYNC", "[createMailUserInfo] INSERT USER Of rkey_code : {} - receiver_enable : {}, gid: {}, mboxsize : {}, pdssize : {}, attachsize : {}", 
				mUserInfoOption.getRkey_code(), mUserInfo.getReceiver_enable(), mUserInfo.getGid(), mUserInfo.getMboxsize(), mUserInfo.getPdssize(), mUserInfo.getAttachsize());
	}
	
	/**
	 * 조직도 사용자 테이블 처리 (IMS_ORG_MEMBER)
	 * @param dao
	 * @param existMailUser
	 * @param mUserInfo
	 * @param mUserInfoOption
	 * @throws SQLException
	 */
	private void orgMemberSync(ImSeoulOrgSyncDAO dao, boolean existMailUser, ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption) throws SQLException {
		try {
			ImOrgMemberBean orgMemberInfo = null;
			boolean existOrgMember = false;			
			
			if (existMailUser) {
				// 메일 IMS_USERINFO 에 존재하지 않는 사용자는 조직도 사용자 테이블에도 없다고 판단함. 
				orgMemberInfo = dao.getImsOrgMember(mUserInfo.getMhost(), mUserInfo.getUserid());			
				
				if (orgMemberInfo == null || orgMemberInfo.getMember_key() == null) {				
					ImLoggerEx.info("ORGSYNC", "[orgMemberSync] Do Not Exist ORG MEMBER Of rkey_code : {} - mhost : {}, userid : {}, group_key : {}", mUserInfoOption.getRkey_code(), mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfoOption.getDeptcode());
					existOrgMember = false;
				} else {
					ImLoggerEx.info("ORGSYNC", "[orgMemberSync] Exist ORG MEMBER Of rkey_code : {} - mhost : {}, userid : {}, group_key : {}, member_key : {}", mUserInfoOption.getRkey_code(), mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfoOption.getDeptcode(), orgMemberInfo.getMember_key());
					existOrgMember = true;
				}
			}
			
			if (orgMemberInfo == null) {
				orgMemberInfo = new ImOrgMemberBean();
			}
			
			setOrgMemberBean(mUserInfo, mUserInfoOption, orgMemberInfo);
			if (! existOrgMember) {
				// 조직도 사용자에 등록이 안되어 있으므로 추가 해야 함.
				String member_key = ImUtils.makeKeyValue();
				orgMemberInfo.setMember_key(member_key);
				
				dao.insertImsOrgMember(orgMemberInfo);
				ImLoggerEx.info("ORGSYNC", "[orgMemberSync] INSERT ORG MEMBER Of rkey_code : {} - member_key : {}, email : {}", mUserInfoOption.getRkey_code(), member_key, orgMemberInfo.getEmail());
			} else {
				// 조직도 사용자 정보를 수정함.
				dao.updateImsOrgMember(orgMemberInfo);
				ImLoggerEx.info("ORGSYNC", "[orgMemberSync] UPDATE ORG MEMBER Of rkey_code : {} - member_key : {}, email : {}", mUserInfoOption.getRkey_code(), orgMemberInfo.getMember_key(), orgMemberInfo.getEmail());
			}
			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
	}

	/**
	 * 조직도 사용자 테이블에 데이터를 반영하기 위한 Bean 정보에 반영
	 * @param mUserInfo
	 * @param mUserInfoOption
	 * @param bean
	 */
	private void setOrgMemberBean(ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption,
			ImOrgMemberBean bean) {
		bean.setMhost(mUserInfo.getMhost());
		bean.setGroup_key(mUserInfoOption.getDeptcode());
		bean.setName(mUserInfo.getName());
		bean.setUserid(mUserInfo.getUserid());
		bean.setEmail(mUserInfo.getMailid() +"@"+ mUserInfo.getDomain());
		bean.setDept(mUserInfoOption.getDeptname());
		bean.setPosition(mUserInfoOption.getPosition());
		bean.setMobile(mUserInfoOption.getHandphone());
		bean.setOffice_phone(mUserInfoOption.getTel());
		bean.setOrd(mUserInfoOption.getDeptorder());
		bean.setUpdate_date(currDate);
	}
	
	/**
	 * 조직도 사용자 정보를 갱신하기 위해 Bean 정보에 반영
	 * @param userTempInfo
	 * @param mUserInfo
	 * @param mUserInfoOption
	 */
	private void setUserBean(ImUserTempBean userTempInfo, ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption) {
		mUserInfo.setDomain(defaultDomain);
		
		// 가상도메인 설정
		if (userTempInfo.getDeptcode().startsWith("3")) {
			String guDomain = null;
			if (codeMap != null) {
				guDomain = codeMap.get(userTempInfo.getDeptcode().substring(0, 3));
			}
			
			if (guDomain == null || "".equals(guDomain)) {
				// 자치구에서 별도의 도메인을 사용하지 않는 경우 서울시청과 동일한 도메인을 사용한다.
				if (mUserInfo.getAhost() != null && !"".equals(mUserInfo.getAhost()) && ! defaultDomain.equals(mUserInfo.getAhost())) {
					mUserInfo.setOld_ahost(mUserInfo.getAhost());
					ImLoggerEx.info("ORGSYNC", "[setUserBean] CHANGE DOMAIN ALIAS : {} --> {}", mUserInfo.getAhost(), defaultDomain);
				}
				
				mUserInfo.setAhost(defaultDomain);
				mUserInfo.setIsrelay(5);				
			} else {
				if (mUserInfo.getAhost() != null && !"".equals(mUserInfo.getAhost()) 
						&& ! defaultDomain.equals(mUserInfo.getAhost()) && ! guDomain.equalsIgnoreCase(mUserInfo.getAhost())) {
					mUserInfo.setOld_ahost(mUserInfo.getAhost());
					ImLoggerEx.info("ORGSYNC", "[setUserBean] CHANGE DOMAIN ALIAS : {} --> {}", mUserInfo.getAhost(), guDomain);
				}
				
				mUserInfo.setAhost(guDomain);
			}
			
			mUserInfo.setGid(GID_GU);	// 자치구 사용자
			
		} else {
			// 서울시청 사용자
			if (mUserInfo.getAhost() != null && !"".equals(mUserInfo.getAhost()) && ! defaultDomain.equals(mUserInfo.getAhost())) {
				mUserInfo.setOld_ahost(mUserInfo.getAhost());
				ImLoggerEx.info("ORGSYNC", "[setUserBean] CHANGE DOMAIN ALIAS : {} --> {}", mUserInfo.getAhost(), defaultDomain);
			}
			
			mUserInfo.setAhost(defaultDomain);
			mUserInfo.setGid(GID_DEFAULT);		// 서울시청 사용자
		}
		
		// 개인정보 저장
		mUserInfo.setIsext("0");	// 전출처리(기본 0)
		mUserInfo.setName(userTempInfo.getUsername());
		mUserInfo.setModdate(currDate);
		mUserInfo.setModid(modId);
		
		// Option 정보 저장 - 주민번호는 제거함
		mUserInfoOption.setBirthday(userTempInfo.getBirthday());
		mUserInfoOption.setTel(userTempInfo.getTel());
		mUserInfoOption.setHandphone(userTempInfo.getHandphone());
		
		mUserInfoOption.setPosition(userTempInfo.getPosition());
		mUserInfoOption.setDeptcode(userTempInfo.getDeptcode());
		mUserInfoOption.setDeptname(userTempInfo.getDeptname());
		mUserInfoOption.setDeptorder(userTempInfo.getDeptorder());
		mUserInfoOption.setOrgname(userTempInfo.getOrgname());
		
		mUserInfoOption.setRole(userTempInfo.getRole());
		mUserInfoOption.setUser_key(userTempInfo.getUser_key());
		mUserInfoOption.setGk_id(userTempInfo.getGk_id());
		mUserInfoOption.setGk_code(userTempInfo.getGk_code());
		mUserInfoOption.setUser_sid(userTempInfo.getUser_sid());
		mUserInfoOption.setRkey_code(userTempInfo.getRkey_code());
		
		if (userTempInfo.getSex() == null || "M".equals(userTempInfo.getSex())) {
			mUserInfoOption.setSex("M");
		} else {
			mUserInfoOption.setSex("F");
		}
	}
	
	/**
	 * 조직도 그룹 동기화
	 * @throws SQLException
	 */
	private void orgSync() throws SQLException {
		if (orgTempList == null || orgTempList.size() == 0) {
			ImLoggerEx.info("ORGSYNC", "[orgSync] orgTempList is Empty.");
			return;
		}
		
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		try {
			for (ImOrgTempBean orgTempInfo : orgTempList) {
				if (orgTempInfo == null) continue;
				
				ImLoggerEx.info("ORGSYNC", "\n");
				ImLoggerEx.info("ORGSYNC", "[orgSync] orgTempInfo ==> group_spec_id : {} - change_date : {}, state : {}, group_id : {}, group_name : {}, group_parent : {}, group_spec_parent : {}, group_order : {}", 
						orgTempInfo.getGroup_spec_id(), orgTempInfo.getChange_date(), orgTempInfo.getState(), orgTempInfo.getGroup_id(), orgTempInfo.getGroup_name(), 
						orgTempInfo.getGroup_parent(), orgTempInfo.getGroup_spec_parent(), orgTempInfo.getGroup_order());
				
				// 조직도 동기화 제외 대상
				if (orgTempInfo.getGroup_spec_id() == null || "".equals(orgTempInfo.getGroup_spec_id())) continue;
				if (orgTempInfo.getGroup_name() == null || "".equals(orgTempInfo.getGroup_name())) continue;				
				if (orgTempInfo.getState() == null || 
					(! "I".equals(orgTempInfo.getState()) && ! "U".equals(orgTempInfo.getState()) && ! "D".equals(orgTempInfo.getState()))) continue;
				
				boolean existGroup = false;	
				ImOrgGroupBean mOrgInfo = getImsOrgGroupInfo(dao, orgTempInfo.getGroup_spec_id());
				if (mOrgInfo == null || mOrgInfo.getGroup_key() == null) {
					ImLoggerEx.info("ORGSYNC", "[orgSync] Do Not Exist Mail Group Of group_spec_id : {}", orgTempInfo.getGroup_spec_id());
					existGroup = false;
					mOrgInfo = new ImOrgGroupBean();					
				} else {
					ImLoggerEx.info("ORGSYNC", "[orgSync] Exist Mail Group Of group_spec_id : {}", orgTempInfo.getGroup_spec_id());
					existGroup = true;					
				}
				
				if (! existGroup && "D".equals(orgTempInfo.getState())) {
					// 메일에 존재하지 않는 삭제그룹은  더 이상 진행할 필요가 없음.
					continue;
				}
				
				setGroupBean(orgTempInfo, mOrgInfo);
				groupSyncProcess(dao, existGroup, orgTempInfo, mOrgInfo); // 조직도 그룹 동기화 
			}
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 조직도 그룹 추가/수정/삭제 처리
	 * @param dao
	 * @param existGroup
	 * @param orgTempInfo
	 * @param mOrgInfo
	 * @throws SQLException
	 */
	private void groupSyncProcess(ImSeoulOrgSyncDAO dao, boolean existGroup, ImOrgTempBean orgTempInfo,
			ImOrgGroupBean mOrgInfo) throws SQLException {		
		try {
			if ("D".equals(orgTempInfo.getState())) {
				// 그룹 삭제
				dao.deleteGroup(mOrgInfo.getMhost(), mOrgInfo.getGroup_key(), currDate);
				ImLoggerEx.info("ORGSYNC", "[groupSyncProcess] DELETE GROUP Of group_spec_id : {} - mhost : {}, group_key : {}, group_id : {}", 
						mOrgInfo.getGroup_spec_id(), mOrgInfo.getMhost(), mOrgInfo.getGroup_key(), mOrgInfo.getGroup_id());
			} else {				
				if (! existGroup) {
					String mhost = "M00001";
					if (domainMap != null && domainMap.get(defaultDomain) != null) {
						mhost = domainMap.get(defaultDomain).getMhost();
					}					
					mOrgInfo.setMhost(mhost);
					
					// 그룹 추가
					dao.insertGroup(mOrgInfo);
					ImLoggerEx.info("ORGSYNC", "[groupSyncProcess] INSERT GROUP Of group_spec_id : {} - mhost : {}, group_key : {}, group_id : {}", 
							mOrgInfo.getGroup_spec_id(), mOrgInfo.getMhost(), mOrgInfo.getGroup_key(), mOrgInfo.getGroup_id());
				} else {
					// 그룹 수정
					dao.updateGroup(mOrgInfo);
					ImLoggerEx.info("ORGSYNC", "[groupSyncProcess] UPDATE GROUP Of group_spec_id : {} - mhost : {}, group_key : {}, group_id : {}", 
							mOrgInfo.getGroup_spec_id(), mOrgInfo.getMhost(), mOrgInfo.getGroup_key(), mOrgInfo.getGroup_id());
				}				
			}
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 조직도 그룹을 반영하기 위한 Bean 정보 반영
	 * @param orgTempInfo
	 * @param mOrgInfo
	 */
	private void setGroupBean(ImOrgTempBean orgTempInfo, ImOrgGroupBean mOrgInfo) {		
		mOrgInfo.setGroup_key(orgTempInfo.getGroup_id());
		//mOrgInfo.setParent_group_key(orgTempInfo.getGroup_spec_parent());
		mOrgInfo.setParent_group_key(orgTempInfo.getGroup_parent());
		mOrgInfo.setGroup_name(orgTempInfo.getGroup_name());
		mOrgInfo.setGroup_spec_id(orgTempInfo.getGroup_spec_id());
		mOrgInfo.setGroup_id(orgTempInfo.getGroup_id());
		mOrgInfo.setOrd(orgTempInfo.getGroup_order());
		
		String ahost = defaultDomain;
		if (orgTempInfo.getGroup_spec_id().startsWith("3")) {
			if (codeMap != null) {
				ahost = codeMap.get(orgTempInfo.getGroup_spec_id().substring(0, 3));
				
				if (StringUtils.isEmpty(ahost)) {
					ahost = defaultDomain;
				}
			}
		}
		mOrgInfo.setAhost(ahost);
		
		if (StringUtils.isNotEmpty(orgTempInfo.getGroup_orgname())) {
			mOrgInfo.setOrgname(orgTempInfo.getGroup_orgname());
		}
		
		if (StringUtils.isEmpty(mOrgInfo.getOrgname())) {
			mOrgInfo.setOrgname("");
		}
		
		mOrgInfo.setUpdate_date(currDate);
	}

	/**
	 * 특정 그룹에 메일에 존재하는지 확인 및 정보를 반영하기 위하여 해당 그룹의 정보를 가져옴
	 * @param dao
	 * @param group_spec_id
	 * @return
	 * @throws SQLException
	 */
	private ImOrgGroupBean getImsOrgGroupInfo(ImSeoulOrgSyncDAO dao, String group_spec_id) throws SQLException {
		ImOrgGroupBean bean = null;
		
		try {
			bean = dao.getImsOrgGroupInfo(group_spec_id);
			
			if (bean != null) {
				ImLoggerEx.debug("ORGSYNC", "[getImsOrgGroupInfo] IMS_ORG_GROUP - {} : {}, {}, {}, {}, {}, {}", 
					bean.getGroup_spec_id(), bean.getMhost(), bean.getGroup_key(), bean.getGroup_name(), bean.getParent_group_key(), bean.getOrgname(), bean.getOrd());
			}
			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
		return bean;
	}
	
	/**
	 * 특장 사용자가 메일에 존재하는지 확인 및 정보를 반영하기 위하여 해당 사용자의 정보를 가져옴
	 * @param dao
	 * @param rkey_code
	 * @return
	 * @throws SQLException
	 */
	private ImUserInfoBean getImsUserInfo(ImSeoulOrgSyncDAO dao, String rkey_code) throws SQLException {
		ImUserInfoBean bean = null;
		
		try {
			bean = dao.getImsUserInfo(rkey_code);
			
			
			if (bean != null) {
				ImUserInfoOptionBean opBean = bean.getOption();
				
				ImLoggerEx.debug("ORGSYNC", "[getImsUserInfo] IMS_USERINFO - {} : {}, {}, {}, {}, {}, {}, {}", 
						rkey_code, bean.getMhost(), bean.getUserid(), bean.getMailid(), bean.getName(), bean.getReceiver_enable(), bean.getAhost(), bean.getOld_ahost());
				
				if (opBean != null) {
					ImLoggerEx.debug("ORGSYNC", "[getImsUserInfo] IMS_USERINFO_OPTION - {} : {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}", 
						opBean.getRkey_code(), opBean.getBirthday(), opBean.getTel(), opBean.getHandphone(), opBean.getSex(), opBean.getDeptcode(), opBean.getDeptname(), opBean.getDeptorder(), 
						opBean.getOrgname(), opBean.getPosition(), opBean.getRole(), opBean.getUser_key(), opBean.getGk_id(), opBean.getGk_code(), opBean.getUser_sid());
				}
			}
			
			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
		return bean;
	}

	/**
	 * 조직도 동기화 대상인 그룹정보를 가져온다.
	 * @return
	 * @throws SQLException
	 */
	private List<ImOrgTempBean> getVMailGroupTemp() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		List<ImOrgTempBean> orgTempList = null;
		List<ImOrgTempBean> orgTempListTmp = new ArrayList<ImOrgTempBean>();
		
		try {
			orgTempList = dao.getVMailGroupTemp(updateTime);			
			
			for (ImOrgTempBean bean : orgTempList) {				
				if (bean != null) {
					ImLoggerEx.debug("ORGSYNC", "[getVMailGroupTemp] group_spec_id : {} - change_date : {}, state : {}, group_id : {}, group_name : {}, group_parent : {}, group_spec_parent : {}, group_orgname : {}", 
							bean.getGroup_spec_id(), bean.getChange_date(), bean.getState(), bean.getGroup_id(), bean.getGroup_name(), bean.getGroup_parent(), bean.getGroup_spec_parent(), bean.getGroup_orgname());
				}				
				
				if (bean.getGroup_id() == null || "".equals(bean.getGroup_id())) {
					bean.setGroup_id(bean.getGroup_spec_id());
				}
				
				if (bean.getGroup_parent() == null || "".equals(bean.getGroup_parent())) {
					bean.setGroup_parent(bean.getGroup_spec_parent());
				}
				
				orgTempListTmp.add(bean);
			}
			
			if (orgTempListTmp != null && orgTempListTmp.size() > 0) {
				orgTempList = orgTempListTmp;
			}			
			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
		return orgTempList;
	}

	/**
	 * 조직도 동기화 대상인 사용자 정보를 가져온다.
	 * @return
	 * @throws SQLException
	 */
	private List<ImUserTempBean> getImsUserTemp() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		List<ImUserTempBean> userTempList = null;
		
		try {
			userTempList = dao.getImsUserTemp(updateTime);
			
			if (ImLoggerEx.isDebugEnabled()) {
				for (ImUserTempBean bean : userTempList) {
					if (bean != null) {
						ImLoggerEx.debug("ORGSYNC", "[getImsUserTemp] rkey_code : {} - change_date : {}, change_flag : {}, username : {}, deptcode : {}", 
								bean.getRkey_code(), bean.getChange_date(), bean.getChange_flag(), bean.getUsername(), bean.getDeptcode());
					}
				}
			}
			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
				
		return userTempList;
	}

	/**
	 * 조직도 Code 정보를 구한다.
	 * @return
	 * @throws SQLException 
	 */
	private Map<String, String> getVGuList() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		Map<String, String> code = new HashMap<String, String>();
		try {
			List<ImOrgCodeBean> codeList = dao.getVGuListInfo();			

			if (codeList == null || codeList.size() == 0) {
				return null;
			}
			
			for (ImOrgCodeBean bean : codeList) {
				if (bean == null || bean.getCode() == null) continue;
				
				String key = bean.getCode().toUpperCase();
				String value = bean.getDomain();
				
				code.put(key, value);
				
				ImLoggerEx.debug("ORGSYNC", "[getVGuList] code : {}, domain : {}", key, value);
			}			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			
			throw e;
		}
		
		return code;
	}

	/**
	 * 최종 조직도 동기화 날짜를 구한다.
	 * 
	 * @param arg_date 
	 * @return
	 * @throws SQLException 
	 */
	private String getUpdateDate(String arg_date) throws SQLException {
		ImLoggerEx.debug("ORGSYNC", "arg_date:{}, defaultDomain:{}", arg_date, defaultDomain);
		
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		Date dbDate = dao.getUpdateDateOfDomainInfo(defaultDomain);		
		ImLoggerEx.info("ORGSYNC", "dbDate:{}", dbDate);
		
		String update_date = "";		
		if (dbDate == null) {
			update_date = "19810621000000";
		} else {
			update_date = getDateFormat(dbDate, "yyyyMMddHHmmss");
		}
		
		ImLoggerEx.info("ORGSYNC", "[getUpdateDate] dbDate : {}, update_date : {}", dbDate, update_date);
		
		if (arg_date != null && !"".equals(arg_date) && arg_date.length() >= 8) {			
			StringBuffer buff = new StringBuffer();
			buff.append(arg_date);
			
			for (int i = arg_date.length(); i < 14; i++ ) {
				buff.append("0");
			}			
			
			ImLoggerEx.info("ORGSYNC", "[getUpdateDate] arg_date is not null -> arg_date : {}, arg_date_buff : {}", arg_date, buff.toString());
			
			if (update_date.compareTo(buff.toString()) > 0) {
				// 인자값으로 주어진 시간이 조직도 동기화 최종 시간 보다 이전일 경우만 인자값의 시간으로 동기화 처리한다.
				// 이유: 조직도 동기화 최종 시간과 입력한 날짜 사이의 데이터가 동기화 되지 않아, 동기화 데이터에 이상이 생길 수 있기 때문이다.
				update_date = buff.toString();
			}
		}
						
		return update_date;
	}
	
	/**
	 * 도메인의 mhost 정보를 구하기 위하여 도메인 정보를 가져온다.
	 * @return
	 * @throws SQLException 
	 */
	private Map<String, ImDomainInfoBean> getDomainInfo() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		Map<String, ImDomainInfoBean> domainMap = new HashMap<String, ImDomainInfoBean>();
		
		try {
			List<ImDomainInfoBean> domainList = dao.getDomainList();
			
			for (ImDomainInfoBean bean : domainList) {
				if (bean == null) continue;
				
				domainMap.put(bean.getDomain(), bean);
				
				int max_tblno = bean.getMax_tblno();
				int max_partno = bean.getMax_partno();
				
				ImLoggerEx.info("ORGSYNC", "[getDomainInfo] domain : {} - mhost : {}, ahost : {}, max_tblno : {}, max_partno : {}", 
						bean.getDomain(), bean.getMhost(), bean.getAhost(), max_tblno, max_partno);	
				
				Map<String, ImLoadBalance> tblnoPartNoMap = new ConcurrentHashMap<String, ImLoadBalance>();
				
				String[] arrMaxTableNo = new String[max_tblno];
				
				for (int j = 1; j <= max_tblno; j++) {
					arrMaxTableNo[j - 1] = ImUtils.checkDigit(j);
					
					String[] arrMaxPartNo = new String[max_partno];
					for (int k = 1; k <= max_partno; k++) {
						arrMaxPartNo[k - 1] = String.valueOf(k);
					}
					
					ImLoadBalance lb = new ImLoadBalance();
					lb.init(arrMaxPartNo);
					
					String tbl_no = ImUtils.checkDigit(j);
					tblnoPartNoMap.put(tbl_no, lb);					
				}
				
				ImLoadBalance lb = new ImLoadBalance();
				lb.init(arrMaxTableNo);
				mhostTblNoMap.put(bean.getMhost(), lb);
				mhostPartNoMap.put(bean.getMhost(), tblnoPartNoMap);	
			}
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
		return domainMap;
	}
	
	private Map<String, GroupInfo> getGroupInfo() throws SQLException {
		ImSeoulOrgSyncDAO dao = new ImSeoulOrgSyncDAO();
		
		Map<String, GroupInfo> groupInfoMap = new HashMap<String, GroupInfo>();
		
		try {
			List<GroupInfo> getGroupList = dao.getGroupList();
			
			for (GroupInfo groupInfo : getGroupList) {
				if (groupInfo == null) continue;				
				if (StringUtils.isEmpty(groupInfo.getMhost())) continue;
				
				String key = groupInfo.getMhost() +"_"+ String.valueOf(groupInfo.getGid());
				
				ImLoggerEx.info("ORGSYNC", "[getGroupInfo] key : {} - mhost : {}, gid : {}, mbox_size : {}, pds_size : {}, attachsize : {}", 
						key, groupInfo.getMhost(), groupInfo.getGid(), groupInfo.getMbox_size(), groupInfo.getPds_size(), groupInfo.getAttach_size());
				
				groupInfoMap.put(key, groupInfo);
			}
			
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
		return groupInfoMap;
	}
	
	/**
	 * 테이블 정보를 가져온다.
	 * @param mhost
	 * @return
	 */
	private String getTableNo(String mhost) {
        if (mhostTblNoMap != null && mhostTblNoMap.containsKey(mhost)) {
            ImLoadBalance loadbalance = mhostTblNoMap.get(mhost);
            return loadbalance.getValue();
        }else{
            return "01";
        }
    }
	
	/**
	 * 파티션 정보를 가져온다.
	 * @param mhost
	 * @param tbl_no
	 * @return
	 */
	private int getPartNo(String mhost, String tbl_no) {
        if (mhostPartNoMap != null && mhostPartNoMap.containsKey(mhost)) {
            Map<String, ImLoadBalance> tblnoHPartNoMap = mhostPartNoMap.get(mhost);
            if (tblnoHPartNoMap.containsKey(tbl_no)) {
                ImLoadBalance loadbalance = tblnoHPartNoMap.get(tbl_no);
                return ImStringUtil.parseInt(loadbalance.getValue());
            } else {
                return 1;
            }
        }else{
            return 1;
        }
    }
	
	/**
	 * 메일 아이디 생성
	 * @param dao 
	 * @param mhost 
	 * @return
	 * @throws SQLException 
	 */
	private String getNewMailId(ImSeoulOrgSyncDAO dao, String mhost) throws SQLException {
		String mailId = "";
		
		try {
			while(true) {
				mailId = createMailId + mailIdSerial;				
				int cnt = dao.existMailId(mhost, mailId);
				
				mailIdSerial++;
				if (cnt > 0) {					
					continue;
				}
				
				break;
			}		
		} catch (SQLException e) {
			String errorId = ErrorTraceLogger.log(e);
			ImLoggerEx.error("ORGSYNC", "{} - {}:{}", errorId, ErrorTraceLogger.getMethodName(e), e.getMessage());
			throw e;
		}
		
		return mailId;
	}
	
	/**
	 * 새로운 사용자 키를 생성한다.
	 * @return
	 */
	public static String getNewUserId(){
		return UUID.randomUUID().toString().replaceAll("-","").substring(0,24);
	}
	
	/**
	 * 퇴직사용자 체크
	 * @param deptcode
	 * @return
	 */
	private boolean chkRetire(String deptcode) {				
		if (! deptcode.startsWith("D")) return false;
		if ("D611425".equals(deptcode) || "D611430".equals(deptcode) || "D611434".equals(deptcode) || "D611464".equals(deptcode)) return false;
		
		return true;
	}
	
	/**
	 * 기본 메일함
	 * @param confSensmail2
	 * @return
	 */
	private List<String> defaultMailBoxList() {
		List<String> defaultMailBox = new ArrayList<String>();
		
		String[] mailboxList = { "Inbox", "Drafts", "Sent", "Trash", "Spam", "Work", "Auth", "Tome", "Forever", "Wait", "Reserv", "Failed"};		
		for (String box : mailboxList) {
			if ("Forever".equals(box)) {
				if (confSensmail.getProfileInt("general", "isforever_folder", 1) != 1) {
					continue;
				}				
			} else if ("Reserv".equals(box)) {
				// 예약발송함
				if (confSensmail.getProfileInt("general", "use_reserv_folder", 1) != 1) {
					continue;
				}
			} else if ("Failed".equals(box)) {
				// 발송 실패함
				if (confSensmail.getProfileInt("general", "use_failed_folder", 1) != 1) {
					continue;
				}
			} else if ("Work".equals(box)) {
				// 업무메일함
				if (confSensmail.getProfileInt("general", "iswork_folder", 0) != 1) {
					continue;
				}				
			} else if ("Tome".equals(box) || "Auth".equals(box) || "Wait".equals(box)) {
				// 서울시청에서 사용하지 않은 메일함은 생성하지 않도록 한다.
				continue;
			}
			
			defaultMailBox.add(box);
		}		
		
		return defaultMailBox;
	}
	
	public Date getDate(String strDate) {
		String year 	= strDate.substring(0, 4);
		String month 	= strDate.substring(4, 6);
		String day 		= strDate.substring(6, 8);
		
		Calendar cal 	= Calendar.getInstance();
		cal.set(Integer.parseInt(year), Integer.parseInt(month)-1, Integer.parseInt(day), 0, 0, 0 );
		
		return cal.getTime();
	}
	
	public static String getDateFormat(Date date, String format) {
		SimpleDateFormat sdf1 = new SimpleDateFormat(format);
		
		return sdf1.format(date);
	}	
}
