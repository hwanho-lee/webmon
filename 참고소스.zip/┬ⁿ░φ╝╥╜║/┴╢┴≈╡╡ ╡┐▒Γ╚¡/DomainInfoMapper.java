package com.imoxion.sensmail.server.dao.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.imoxion.sensmail.server.beans.ImDomainInfoBean;

/**
 * Created by Administrator on 2016-07-22.
 */
public interface DomainInfoMapper {

    public void updateDomainUserCount(@Param("mhost") String mhost, @Param("curruser") int curruser);
    
    public void increaseDomainUserCount(@Param("mhost") String mhost);
    
    public void updateDateDomainInfo();
    
    public void updateDateDomainInfoBycurrDate(@Param("currDate") Date currDate);

    public String getAliasDomain(@Param("alias") String alias);

    public List<String> getDomainAlias(@Param("mhost") String mhost);

    public ImDomainInfoBean getDomainInfoForMhost(@Param("mhost") String mhost);

    public ImDomainInfoBean getDomainInfoForDomain(@Param("domain") String domain);

    public ImDomainInfoBean getDomainInfoForAliasDomain(@Param("alias") String alias);

    public List<ImDomainInfoBean> getDomainList();

    public List<ImDomainInfoBean> getDeletedDomainList();

    public List<String> getDomainAliasList();

    public int getAhostCount(@Param("mhost") String mhost);

}
