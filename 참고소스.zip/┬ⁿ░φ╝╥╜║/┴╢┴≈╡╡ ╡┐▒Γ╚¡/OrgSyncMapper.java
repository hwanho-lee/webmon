package com.imoxion.sensmail.server.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.imoxion.sensmail.server.beans.ImOrgCodeBean;
import com.imoxion.sensmail.server.beans.ImOrgTempBean;
import com.imoxion.sensmail.server.beans.ImUserTempBean;

public interface SeoulOrgSyncMapper {

	public List<ImOrgCodeBean> getVGuList();

	public List<ImUserTempBean> getuserTempList(@Param("date") String date);

	public List<ImOrgTempBean> getmailGroupTempList(@Param("date") String date);
	
	public void updatePortal(@Param("rkey_code") String rkey_code, @Param("email") String email);
}
