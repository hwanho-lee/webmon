package com.imoxion.sensmail.server.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.session.SqlSession;

import com.imoxion.common.database.ImDatabaseConnectionEx;
import com.imoxion.sensmail.common.domain.Directory;
import com.imoxion.sensmail.common.domain.GroupInfo;
import com.imoxion.sensmail.common.domain.UserInfo;
import com.imoxion.sensmail.server.beans.ImDomainInfoBean;
import com.imoxion.sensmail.server.beans.ImOrgCodeBean;
import com.imoxion.sensmail.server.beans.ImOrgGroupBean;
import com.imoxion.sensmail.server.beans.ImOrgMemberBean;
import com.imoxion.sensmail.server.beans.ImOrgTempBean;
import com.imoxion.sensmail.server.beans.ImUserInfoBean;
import com.imoxion.sensmail.server.beans.ImUserInfoOptionBean;
import com.imoxion.sensmail.server.beans.ImUserTempBean;
import com.imoxion.sensmail.server.beans.KeyPairBean;
import com.imoxion.sensmail.server.custom.ImSeoulOrgSync;
import com.imoxion.sensmail.server.dao.mapper.DomainInfoMapper;
import com.imoxion.sensmail.server.dao.mapper.MailboxMapper;
import com.imoxion.sensmail.server.dao.mapper.OrganizationMapper;
import com.imoxion.sensmail.server.dao.mapper.SeoulOrgSyncMapper;
import com.imoxion.sensmail.server.dao.mapper.UserInfoMapper;

/**
 * 서울시청 통합메일 조직도 동기화
 * 
 * @author Seo MinJeong <dongguli@imoxion.com>
 *
 */
public class ImSeoulOrgSyncDAO {
	private static final Log log = LogFactory.getLog(ImSeoulOrgSyncDAO.class);
	/**
	 * 조직도 동기화 최종 실행 시간 정보를 가져온다.
	 * @param defaultDomain
	 * @return
	 * @throws SQLException
	 */
	public Date getUpdateDateOfDomainInfo(String defaultDomain) throws SQLException {
		Date update_date = null;
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			DomainInfoMapper mapper = session.getMapper(DomainInfoMapper.class);
			
			ImDomainInfoBean bean = mapper.getDomainInfoForDomain(defaultDomain);			
			if (bean != null && bean.getUpdate_date() != null) {
				update_date = bean.getUpdate_date();
			}			
		} finally {
			if(session != null) session.close();
		}
		
		return update_date;
	}
	
	public void updateDateDomainInfo(Date currDate) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			DomainInfoMapper mapper = session.getMapper(DomainInfoMapper.class);
			
			mapper.updateDateDomainInfoBycurrDate(currDate);
		} finally {
			if(session != null) session.close();
		}
	}

	public List<ImDomainInfoBean> getDomainList() throws SQLException {
		List<ImDomainInfoBean> domainList = new ArrayList<ImDomainInfoBean>();
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();
			DomainInfoMapper mapper = session.getMapper(DomainInfoMapper.class);
			domainList = mapper.getDomainList();
					
		} finally {
			if(session != null) session.close();
		}
		
		return domainList;
	}
	
	public List<GroupInfo> getGroupList() throws SQLException {
		List<GroupInfo> groupList = new ArrayList<GroupInfo>();
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			groupList = mapper.getGroupList();
			
		} finally {
			if(session != null) session.close();
		}
		
		return groupList;
	}

	/**
	 * 조직도 동기화 코드 정보를 가져온다.
	 * @return
	 * @throws SQLException
	 */
	public List<ImOrgCodeBean> getVGuListInfo() throws SQLException {
		List<ImOrgCodeBean> codeList = new ArrayList<ImOrgCodeBean>();
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			SeoulOrgSyncMapper mapper = session.getMapper(SeoulOrgSyncMapper.class);
			
			codeList = mapper.getVGuList();
					
		} finally {
			if(session != null) session.close();
		}
		
		return codeList;
	}

	public List<ImUserTempBean> getImsUserTemp(String updateTime) throws SQLException {
		List<ImUserTempBean> userTempList = new ArrayList<ImUserTempBean>();
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			SeoulOrgSyncMapper mapper = session.getMapper(SeoulOrgSyncMapper.class);
			
			userTempList = mapper.getuserTempList(updateTime);
					
		} finally {
			if(session != null) session.close();
		}
		
		return userTempList;
	}

	public List<ImOrgTempBean> getVMailGroupTemp(String updateTime) throws SQLException {
		List<ImOrgTempBean> orgTempList = new ArrayList<ImOrgTempBean>();
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			SeoulOrgSyncMapper mapper = session.getMapper(SeoulOrgSyncMapper.class);
			
			orgTempList = mapper.getmailGroupTempList(updateTime);
					
		} finally {
			if(session != null) session.close();
		}
		
		return orgTempList;
	}

	public ImUserInfoBean getImsUserInfo(String rkey_code) throws SQLException {
		ImUserInfoBean userInfo = null;
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			
			userInfo = mapper.getUserInfoOfRkeyCode(rkey_code);
					
		} finally {
			if(session != null) session.close();
		}
		
		return userInfo;
	}	

	public int existMailId(String mhost, String mailId) throws SQLException {
		int count = 0;
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			
			count = mapper.existMailId(mhost, mailId);
			
		} finally {
			if(session != null) session.close();
		}
		
		return count;
	}

	public void insertUserInfo(ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption, List<String> defaultMailBox, KeyPairBean keysBean) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection(false);			
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			
			mapper.insertUserInfo(mUserInfo);
			mapper.insertUserInfoOption(mUserInfoOption);
			if (keysBean != null && keysBean.getPrivate_key() != null && keysBean.getPublic_key() != null) {
				mapper.insertKeyPairInfo(keysBean);
			}
			
			MailboxMapper mailMapper = session.getMapper(MailboxMapper.class);
			for(String box : defaultMailBox) {
				if (box == null || "".equals(box)) continue;
				
				String dirkey = box + "_" + mUserInfo.getUserid();
				
				Directory dir = new Directory();				
				dir.setUkey(dirkey);
				dir.setUserid(mUserInfo.getUserid());
				dir.setMhost(mUserInfo.getMhost());
				dir.setDirname(box);				
				dir.setDir_type(Directory.DEFAULT_MBOX);
				dir.setDepth(1);
				
				if ("Forever".equals(box)) {	// 영구보관함은 삭제일을 지정하지 않는다.
					dir.setDel_time(0);
				} else {
					dir.setDel_time(90);
				}
				
				mailMapper.createDefaultMailbox(dir);
			}
			
			DomainInfoMapper domainMapper = session.getMapper(DomainInfoMapper.class);
			domainMapper.increaseDomainUserCount(mUserInfo.getMhost());
			
			session.commit();
					
		} finally {
			if(session != null) session.close();
		}
	}

	public void updateUserInfo(ImUserInfoBean mUserInfo, ImUserInfoOptionBean mUserInfoOption) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection(false);			
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			
			mapper.updateUserInfo(mUserInfo);
			mapper.updateUserInfoOption(mUserInfoOption);
			
			session.commit();
					
		} finally {
			if(session != null) session.close();
		}
	}
	
	public void deleteUserInfo(ImUserInfoBean mUserInfo) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			
			mapper.updateDeleteUserInfo(mUserInfo.getMhost(), mUserInfo.getUserid(), mUserInfo.getReceiver_enable(), mUserInfo.getModdate(), mUserInfo.getModid());
					
		} finally {
			if(session != null) session.close();
		}
	}

	public void updateUserGid(String defaultDomain) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			UserInfoMapper mapper = session.getMapper(UserInfoMapper.class);
			
			mapper.updateDefaultGid(defaultDomain, ImSeoulOrgSync.GID_DEFAULT);		// 서울시청 그룹 목록
			mapper.updateGuGid(defaultDomain, ImSeoulOrgSync.GID_GU);				// 자치구 그룹 목록
			mapper.updateStopGid(UserInfo.RECEIVER_ENABLE__SLEEP, UserInfo.RECEIVER_ENABLE__LEAVE, ImSeoulOrgSync.GID_STOP);
			
		} finally {
			if(session != null) session.close();
		}		
	}

	public ImOrgGroupBean getImsOrgGroupInfo(String group_spec_id) throws SQLException {
		ImOrgGroupBean orgInfo = null;
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			orgInfo = mapper.getImsOrgGroupInfoForGroupSpecId(group_spec_id);			
			
		} finally {
			if(session != null) session.close();
		}
		
		return orgInfo;
	}

	public void insertGroup(ImOrgGroupBean mOrgInfo) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			mapper.insertImsOrgGroup(mOrgInfo);
			
		} finally {
			if(session != null) session.close();
		}
	}
	
	public void updateGroup(ImOrgGroupBean mOrgInfo) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			mapper.updateImsOrgGroup(mOrgInfo);
			
		} finally {
			if(session != null) session.close();
		}
	}
	
	public void deleteGroup(String mhost, String group_key, Date currDate) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			mapper.deleteImsOrgGroupByGroupKey(mhost, group_key, currDate);
			
		} finally {
			if(session != null) session.close();
		}
	}
	
	public void insertImsOrgMember(ImOrgMemberBean orgMemberInfo) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			mapper.insertImsOrgMember(orgMemberInfo);
			
		} finally {
			if(session != null) session.close();
		}		
	}
	
	public void updateImsOrgMember(ImOrgMemberBean orgMemberInfo) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			mapper.updateImsOrgMemberByMemberKey(orgMemberInfo);
			
		} finally {
			if(session != null) session.close();
		}	
	}
	
	public void deleteImsOrgMember(String mhost, String userid, String group_key, Date currDate) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			mapper.deleteImsOrgMemberByGroupKey(mhost, userid, group_key, currDate);
			
		} finally {
			if(session != null) session.close();
		}
	}

	public ImOrgMemberBean getImsOrgMember(String mhost, String userid) throws SQLException {
		ImOrgMemberBean orgMemberInfo = null;
		
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection();			
			OrganizationMapper mapper = session.getMapper(OrganizationMapper.class);
			
			orgMemberInfo = mapper.getImsOrgMember(mhost, userid);
			
		} finally {
			if(session != null) session.close();
		}
		
		return orgMemberInfo;
	}

	public void updatePortal(String rkey_code, String email) throws SQLException {
		SqlSession session  = null;
		try{
			session  = ImDatabaseConnectionEx.getConnection("portal");			
			SeoulOrgSyncMapper mapper = session.getMapper(SeoulOrgSyncMapper.class);
			
			mapper.updatePortal(rkey_code, email);
			
		} finally {
			if(session != null) session.close();
		}
	}
}
