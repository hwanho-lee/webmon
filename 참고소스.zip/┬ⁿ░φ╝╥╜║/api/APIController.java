package com.imoxion.sensmail.web.webmail.controller;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.servlet.ModelAndView;

import com.cs.rifis.comm.util.AES128Util;
import com.imoxion.common.util.ImConfLoaderEx;
import com.imoxion.common.util.ImUtils;
import com.imoxion.security.ImSecurityLib;
import com.imoxion.sensmail.common.beans.User;
import com.imoxion.sensmail.common.logger.ErrorTraceLogger;
import com.imoxion.sensmail.web.app.webmail.config.service.ConfigService;
import com.imoxion.sensmail.web.app.webmail.mail.form.MailWriteForm;
import com.imoxion.sensmail.web.app.webmail.mail.model.MailBoxKey;
import com.imoxion.sensmail.web.app.webmail.mail.service.MailService;
import com.imoxion.sensmail.web.common.ImsConstant;
import com.imoxion.sensmail.web.common.InfoMessage;
import com.imoxion.sensmail.web.common.JSONResult;
import com.imoxion.sensmail.web.common.model.UserSessionInfo;
import com.imoxion.sensmail.web.custom.domain.NypiOrgUserBean;
import com.imoxion.sensmail.web.database.domain.ApiApprovalBean;
import com.imoxion.sensmail.web.database.domain.DirectoryBean;
import com.imoxion.sensmail.web.database.domain.DomainInfoBean;
import com.imoxion.sensmail.web.database.domain.MailBean;
import com.imoxion.sensmail.web.database.domain.UserInfoBean;
import com.imoxion.sensmail.web.exception.CommonException;
import com.imoxion.sensmail.web.module.api.APIService;
import com.imoxion.sensmail.web.module.domain.DomainService;
import com.imoxion.sensmail.web.module.nypi.NypiCustomAPIActionLogger;
import com.imoxion.sensmail.web.module.sender.ApprovalSend;
import com.imoxion.sensmail.web.module.user.UserService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 복지시스템과 결재메일 관련 Controller크래스
 */
@Controller
@RequestMapping("/api")
public class APIController {

	private final Logger log = LoggerFactory.getLogger(APIController.class);
	
	@Autowired
	protected MessageSourceAccessor message;

	@Autowired
	private UserService userService;

	@Autowired
	private DomainService domainService;
	
	@Autowired
	private ConfigService configService;
	
	@Autowired
	private MailService mailService;

	@Autowired
	private APIService apiService;	

	@ResponseBody
	@RequestMapping("changePasswd.do")
	public String changePasswd(HttpServletRequest request,
				@RequestParam(value = "emp_code", required = false) String emp_code, @RequestParam(value = "mailid", required = false) String mailid) throws Exception {
			
		DomainInfoBean domainInfo = domainService.getDomainInfo(request.getServerName(), DomainService.WHOST);
		if (domainInfo == null) {
			throw new CommonException(CommonException.UNKNOW_DOMAIN);
		}
		
		String mhost = domainInfo.getMhost();
		String domain = domainInfo.getDomain();
		
		JSONResult result = new JSONResult();
		
		ImConfLoaderEx sensmailConfig = ImConfLoaderEx.getInstance();
		String serverIp = sensmailConfig.getProfileString("api", "access.client_ip");
		log.debug("serverIp => "+ serverIp);
		
		String remoteAddr = request.getRemoteAddr();
		
		NypiCustomAPIActionLogger logger = new NypiCustomAPIActionLogger();
		logger.setType(NypiCustomAPIActionLogger.TYPE_01);
		logger.setMhost(mhost);
		logger.setIp(remoteAddr);
		logger.setEmpno(emp_code);
		logger.setMailid(mailid);
		
		// 접근 IP 체크
		if (! StringUtils.isEmpty(serverIp) && ! "*".equals(serverIp)) {
			boolean chkIpResult = false;
			
			String[] remoteAddrList = StringUtils.split(".", remoteAddr);
			String[] serverIpList = StringUtils.split(serverIp, ",");
			if (serverIpList != null && serverIpList.length > 0) {
				for (String ip : serverIpList) {
					if (chkIpResult) break;
					
					ip = ip.trim();
					if (StringUtils.isEmpty(ip)) continue;
					
					if ("*".equals(ip)) {	// 모든 IP를 허용함
						chkIpResult = true;
						break;
					}
					
					String[] unitIps = StringUtils.split(ip, ".");
					if (unitIps.length != 4) continue;
					for (int i = 0; i < 4; i++) {
						if ("*".equals(unitIps[i]) || remoteAddrList[i].equals(unitIps[i])) {
							chkIpResult = true; // * 이거나 같으면 true 이며 다음 숫자와 비교한다.
							continue;
						} else {
							chkIpResult = false;
							break;
						}
					}
				}
			}
			
			if (! chkIpResult) {
				String message = "ACCESS_DENIED_OF_IP";
				logger.setSuccess(false);
				logger.setDescription(message);
				logger.info();
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				
				return result.toString();
			}
		}
				
		// 파라메터 체크
		if (StringUtils.isEmpty(emp_code) || StringUtils.isEmpty(mailid)) {
			String message = "NO PARAMETER VALUE";
			logger.setSuccess(false);
			logger.setDescription(message);
			logger.info();
			
			result.setResultCode(JSONResult.FAIL);
			result.setMessage(message);
			return result.toString();
		}
		
		if (StringUtils.isNotEmpty(ImsConstant.AINTOP_SSO_KEY)) {
			String key = ImsConstant.AINTOP_SSO_KEY;
			String method = request.getMethod();
			
			log.debug("[CHANGEPASSWD API INFO - 1] key : {}, method : {}", key, method);
			log.debug("[CHANGEPASSWD API ENC PARAM - 1] emp_code : {}, mailid : {}", emp_code, mailid);
			
			try {
				// 암호화 모듈 인스턴스 선언
				AES128Util aes128 = new AES128Util(key);
				
				String en_emp_code = emp_code;
				String en_mailid = mailid;
				if (! method.equalsIgnoreCase("GET")) {
					// BASE64로 변환된 문자열중 특수문자(+,=,/)를  웹 파라미터 전송 가능한 문자열로 변환하기 위한 모듈
					URLCodec codec = new URLCodec();
					
					en_emp_code = codec.decode(emp_code);
					en_mailid = codec.decode(mailid);
				}
				
				emp_code = aes128.aesDecode(en_emp_code);
				mailid = aes128.aesDecode(en_mailid);
				
				log.debug("[CHANGEPASSWD API DESC PARAM - 1] emp_code : {}, mailid : {}", emp_code, mailid);
			} catch (Exception e) {
				
				log.debug("[CHANGEPASSWD API DESC ERROR - 1] emp_code : {}, mailid : {}", emp_code, mailid);
				
				String errorId = ErrorTraceLogger.log(e);
				log.error("{} - APICONTROLLER LOGINPROC ERROR",errorId);
				
				String message = "AES DECODE FAIL";
				logger.setSuccess(false);
				logger.setDescription(message);
				logger.info();
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				
				return result.toString();
			}
		}
		
		UserInfoBean userInfoBean = userService.getUserInfoForMailId(mhost, mailid);
		if (userInfoBean == null) {
			String message = "NO MAIL USER";
			logger.setSuccess(false);
			logger.setDescription(message);
			logger.info();
			
			result.setResultCode(JSONResult.FAIL);
			result.setMessage(message);
			return result.toString();
		}
		
		if (! emp_code.equals(userInfoBean.getOffice_no())) {
			String message = "INVALID EMP_CODE";
			logger.setSuccess(false);
			logger.setDescription(message);
			logger.info();
			
			result.setResultCode(JSONResult.FAIL);
			result.setMessage(message);
			return result.toString();
		}
		
		try {
			NypiOrgUserBean nypiOrgUserBean = userService.getOrgUserInfo(emp_code);
			if (nypiOrgUserBean == null) {
				String message = "NO SEARCH INSADB USER";
				logger.setSuccess(false);
				logger.setDescription(message);
				logger.info();
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				return result.toString();
			}
			
			String insaPasswd = nypiOrgUserBean.getPswd_sha256();
			if (StringUtils.isEmpty(insaPasswd)) {
				insaPasswd = ImSecurityLib.makePassword2(userInfoBean.getPwd_type(), emp_code, false);
			}
			
			userService.updateEncPassword(userInfoBean.getMhost(), userInfoBean.getUserid(), insaPasswd);
			
		} catch (Exception e) {
			String message = "DB ERROR";
			logger.setSuccess(false);
			logger.setDescription(message);
			logger.info();
			
			result.setResultCode(JSONResult.FAIL);
			result.setMessage(message);
			
			String errorId = ErrorTraceLogger.log(e);
			log.error("{} - CHANGEPASSWD ERROR",errorId);
			
			return result.toString();
		}
		
		String message = "SUCCESS";
		logger.setSuccess(true);
		logger.setDescription(message);
		logger.info();
		
		result.setResultCode(JSONResult.SUCCESS);
		result.setMessage(message);
		
		return result.toString();
	}
	
	/**
	 * 받은메일함의 전체 메일 개수와 안읽은 메일 개수를 반환한다.
	 * 
	 * @param request
	 * @param emp_code
	 * @param mailid
	 * @return
	 * @throws Exception
	 */
	
	@ResponseBody
	@RequestMapping("mail/count.do")
	public String getMailCount(HttpServletRequest request,
				@RequestParam(value = "emp_code", required = false) String emp_code, @RequestParam(value = "mailid", defaultValue = "") String mailid,
				@RequestParam(value = "callback", defaultValue = "") String callback) throws Exception {
				
		JSONResult result = new JSONResult();
		
		// 파라메터 체크
		if (StringUtils.isEmpty(emp_code)) {
			String message = "NO PARAMETER VALUE";
						
			result.setResultCode(JSONResult.FAIL);
			result.setMessage(message);			
			return result.toString();
		}
		
		if (StringUtils.isNotEmpty(ImsConstant.AINTOP_SSO_KEY)) {
			String key = ImsConstant.AINTOP_SSO_KEY;
			String method = request.getMethod();
			
			log.debug("[MAILCOUNT API INFO] key : {}, method : {}", key, method);
			log.debug("[MAILCOUNT API ENC PARAM] emp_code : {}, mailid : {}", emp_code, mailid);
			
			try {
				// 암호화 모듈 인스턴스 선언
				AES128Util aes128 = new AES128Util(key);
				
				String en_emp_code = emp_code;
				String en_mailid = mailid;
				if (! method.equalsIgnoreCase("GET")) {
					// BASE64로 변환된 문자열중 특수문자(+,=,/)를  웹 파라미터 전송 가능한 문자열로 변환하기 위한 모듈
					URLCodec codec = new URLCodec();
					
					en_emp_code = codec.decode(emp_code);
					if (StringUtils.isNotEmpty(mailid)) en_mailid = codec.decode(mailid);
				}
				
				emp_code = aes128.aesDecode(en_emp_code);
				if (StringUtils.isNotEmpty(en_mailid)) mailid = aes128.aesDecode(en_mailid);
				
				log.debug("[MAILCOUNT API DESC PARAM] emp_code : {}, mailid : {}", emp_code, mailid);
			} catch (Exception e) {
				
				log.debug("[MAILCOUNT API DESC ERROR] emp_code : {}, mailid : {}", emp_code, mailid);
				
				String errorId = ErrorTraceLogger.log(e);
				log.error("{} - APICONTROLLER GETMAILCOUNT ERROR",errorId);
				
				String message = "AES DECODE FAIL";				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				
				return result.toString();
			}
		}
		
		DomainInfoBean domainInfo = domainService.getDomainInfo(request.getServerName(), DomainService.WHOST);
		if (domainInfo == null) {
			throw new CommonException(CommonException.UNKNOW_DOMAIN);
		}
		
		String mhost = domainInfo.getMhost();
			
		UserInfoBean userInfoBean = new UserInfoBean();
		if (StringUtils.isNotEmpty(mailid)) {
			userInfoBean = userService.getUserInfoForMailId(mhost, mailid);
			if (userInfoBean == null) {
				String message = "NO MAIL USER";
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);			
				return result.toString();
			}
			
			if (! emp_code.equals(userInfoBean.getOffice_no())) {
				String message = "INVALID EMP_CODE";
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				return result.toString();
			}
		} else {
			userInfoBean = userService.getUserInfoForOfficeNo(mhost, emp_code);
			if (userInfoBean == null) {
				String message = "NO MAIL USER";
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				return result.toString();
			}
		}
		
		// 받은메일함의 전체 메일 갯수와 안읽은 메일 개수를 반환한다.
		String dirKey = "Inbox_" + userInfoBean.getUserid();
		DirectoryBean inboxInfo = configService.getDirectorybyUkey(mhost, userInfoBean.getUserid(), dirKey);
		
		int totalmailcount = inboxInfo.getMailcount();
        int newmailcount = inboxInfo.getNewmailcount();
        
        JSONObject json = new JSONObject();
        json.put("totalCount", totalmailcount);
        json.put("newCount", newmailcount);
        
        result.setResultCode(JSONResult.SUCCESS);
		result.setMessage("SUCCESS");
		result.setData(json);
		
		String returnVal = result.toString();
		if (StringUtils.isNotEmpty(callback)) {
			returnVal = callback +"("+ result.toString() +")";
		}
		
		return returnVal;
	}
	
	/**
	 * 받은메일함 목록을 반환한다.
	 * 
	 * @param request
	 * @param emp_code
	 * @param mailid
	 * @param type
	 * @param line_count
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("mail/list.do")
	public String mailPortlet(HttpServletRequest request,
								@RequestParam(value = "emp_code", required = false) String emp_code, @RequestParam(value = "mailid", defaultValue = "") String mailid,
								@RequestParam(value = "type", defaultValue = "") String type, @RequestParam(value = "line_count", required = false, defaultValue = "") String line_count,
								@RequestParam(value = "callback", defaultValue = "") String callback
						) throws Exception {
		
		JSONResult result = new JSONResult();
		
		// 파라메터 체크
		if (StringUtils.isEmpty(emp_code)) {
			String message = "NO PARAMETER VALUE";
			
			result.setResultCode(JSONResult.FAIL);
			result.setMessage(message);			
			return result.toString();
		}
		
		if (StringUtils.isNotEmpty(ImsConstant.AINTOP_SSO_KEY)) {
			String key = ImsConstant.AINTOP_SSO_KEY;
			String method = request.getMethod();
			
			log.debug("[MAILPORTLET API INFO] key : {}, method : {}", key, method);
			log.debug("[MAILPORTLET API ENC PARAM] emp_code : {}, mailid : {}, type : {}, line_count : {}", emp_code, mailid, type, line_count);
			
			try {
				// 암호화 모듈 인스턴스 선언
				AES128Util aes128 = new AES128Util(key);
				
				String en_emp_code = emp_code;
				String en_mailid = mailid;
				String en_type = type;
				String en_line_count = line_count;
				if (! method.equalsIgnoreCase("GET")) {
					// BASE64로 변환된 문자열중 특수문자(+,=,/)를  웹 파라미터 전송 가능한 문자열로 변환하기 위한 모듈
					URLCodec codec = new URLCodec();
					
					en_emp_code = codec.decode(emp_code);
					if (StringUtils.isNotEmpty(mailid)) en_mailid = codec.decode(mailid);
					if (StringUtils.isNotEmpty(type)) en_type = codec.decode(type);
					if (StringUtils.isNotEmpty(line_count)) en_line_count = codec.decode(line_count);
				}
				
				emp_code = aes128.aesDecode(en_emp_code);
				if (StringUtils.isNotEmpty(en_mailid)) mailid = aes128.aesDecode(en_mailid);
				if (StringUtils.isNotEmpty(en_type)) type = aes128.aesDecode(en_type);
				if (StringUtils.isNotEmpty(en_line_count)) line_count = aes128.aesDecode(en_line_count);
				
				log.debug("[MAILPORTLET API DESC PARAM] emp_code : {}, mailid : {}, type : {}, line_count : {}", emp_code, mailid, type, line_count);
			} catch (Exception e) {
				
				log.debug("[MAILPORTLET API DESC ERROR] emp_code : {}, mailid : {}, type : {}, line_count : {}", emp_code, mailid, type, line_count);
				
				String errorId = ErrorTraceLogger.log(e);
				log.error("{} - APICONTROLLER MAILPORTLET ERROR",errorId);
				
				String message = "AES DECODE FAIL";				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				
				return result.toString();
			}
		}
		
		if (StringUtils.isEmpty(type)) type = "TOTAL";
		if (StringUtils.isEmpty(line_count)) line_count = "10";
				
		DomainInfoBean domainInfo = domainService.getDomainInfo(request.getServerName(), DomainService.WHOST);
		if (domainInfo == null) {
			throw new CommonException(CommonException.UNKNOW_DOMAIN);
		}
		
		String mhost = domainInfo.getMhost();			
		
		UserInfoBean userInfoBean = new UserInfoBean();
		if (StringUtils.isNotEmpty(mailid)) {
			userInfoBean = userService.getUserInfoForMailId(mhost, mailid);
			if (userInfoBean == null) {
				String message = "NO MAIL USER";
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				return result.toString();
			}
			
			if (! emp_code.equals(userInfoBean.getOffice_no())) {
				String message = "INVALID EMP_CODE";
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				return result.toString();
			}
		} else {
			userInfoBean = userService.getUserInfoForOfficeNo(mhost, emp_code);
			if (userInfoBean == null) {
				String message = "NO MAIL USER";
				
				result.setResultCode(JSONResult.FAIL);
				result.setMessage(message);
				return result.toString();
			}
		}
		
		// 메일함 정보를 구하기 위하여 필요한 정보를 생성한다.	
		UserSessionInfo userSessionInfo = new UserSessionInfo();
		userSessionInfo.setAhost(domainInfo.getAhost());
		userSessionInfo.setMhost(mhost);
        userSessionInfo.setDomain(domainInfo.getDomain());
		userSessionInfo.setTbl_no(userInfoBean.getTbl_no());
		userSessionInfo.setPart_no(userInfoBean.getPart_no());
		userSessionInfo.setUserid(userInfoBean.getUserid());
        userSessionInfo.setMailid(userInfoBean.getMailid());
		userSessionInfo.setName(userInfoBean.getName());
		userSessionInfo.setOffice_no(userInfoBean.getOffice_no());
		// 기본 메일함 키 설정
		MailBoxKey mailBoxKey;
		try {
			mailBoxKey = userService.getMailBoxKey(userInfoBean.getMhost(), userInfoBean.getUserid());
		} catch (Exception e) {
			throw e;
		}
        userSessionInfo.setMailBoxKey(mailBoxKey);
        
        String dirKey = "Inbox_" + userInfoBean.getUserid();        
        int isNewmail = 0;
        if ("NEW".equals(type)) {
        	isNewmail = 1;
        }
        
        JSONArray jsonMailList = new JSONArray();
        
        SimpleDateFormat sdf= new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
        List<MailBean> mailList = mailService.getMailList(userSessionInfo, dirKey, isNewmail, Integer.parseInt(line_count));
		for (MailBean mail : mailList) {
			String from = StringUtils.isEmpty(mail.getFromname())?mail.getFromaddr():mail.getFromname()+"<"+mail.getFromaddr()+">";
			String recDate = sdf.format(mail.getRecvdate());
			
			StringBuffer mailViewUrlBuff = new StringBuffer();
			mailViewUrlBuff.append("/sso/login.do");
			
			if (StringUtils.isNotEmpty(ImsConstant.AINTOP_SSO_KEY)) {
				URLCodec codec = new URLCodec();				
				AES128Util aes128 = new AES128Util(ImsConstant.AINTOP_SSO_KEY);
				
				mailViewUrlBuff.append("?").append("emp_code=").append(codec.encode(aes128.aesEncode(emp_code)));
				mailViewUrlBuff.append("&").append("mailid=").append(codec.encode(aes128.aesEncode(userInfoBean.getMailid())));
				mailViewUrlBuff.append("&").append("type=").append(codec.encode(aes128.aesEncode("VIEW")));
				mailViewUrlBuff.append("&").append("dirkey=").append(codec.encode(aes128.aesEncode(mail.getDirkey())));
				mailViewUrlBuff.append("&").append("mailkey=").append(codec.encode(aes128.aesEncode(mail.getUkey())));
				mailViewUrlBuff.append("&").append("p_type=").append(codec.encode(aes128.aesEncode("E")));
			} else {
				mailViewUrlBuff.append("?").append("emp_code=").append(URLEncoder.encode(emp_code, "UTF-8"));
				mailViewUrlBuff.append("&").append("mailid=").append(URLEncoder.encode(userInfoBean.getMailid(), "UTF-8"));
				mailViewUrlBuff.append("&").append("type=").append(URLEncoder.encode("VIEW", "UTF-8"));
				mailViewUrlBuff.append("&").append("dirkey=").append(URLEncoder.encode(mail.getDirkey(), "UTF-8"));
				mailViewUrlBuff.append("&").append("mailkey=").append(URLEncoder.encode(mail.getUkey(), "UTF-8"));
			}
			
			JSONObject jsonMail = new JSONObject();
			jsonMail.put("emp_code", emp_code);
			jsonMail.put("mailid", userInfoBean.getMailid());
			jsonMail.put("ukey", mail.getUkey());									// 메일 Key
			jsonMail.put("dirkey", mail.getDirkey());								// 메일함 Key						
			jsonMail.put("subject", mail.getSubject());								// 메일 제목			
			jsonMail.put("from", from);												// 메일 발송자			
			jsonMail.put("recvdate", recDate);										// 메일 수신날짜			
			jsonMail.put("mailsize", ImUtils.byteFormat(mail.getMailsize(), 2));	// 메일 크기			
			jsonMail.put("important", mail.getImportant());							// 메일 중요도 1: 중요, 그 외는 보통
			jsonMail.put("issend", mail.getIsseen());								// 메일 읽음 여부 1: 읽음, 0: 안읽음
			jsonMail.put("view_url", mailViewUrlBuff.toString());
			
			jsonMailList.add(jsonMail);
		}
		
		JSONObject json = new JSONObject();
		json.put("maillist", jsonMailList);
		
		result.setResultCode(JSONResult.SUCCESS);
		result.setMessage("SUCCESS");
		result.setData(json);
		
		String returnVal = result.toString();
		if (StringUtils.isNotEmpty(callback)) {
			returnVal = callback +"("+ result.toString() +")";
		}
		
		return returnVal;
	}
	
	
	@RequestMapping("json/appsend.do")
	public void send(HttpServletRequest request, HttpServletResponse response, HttpSession session, @RequestParam(value = "userid") String userid,
		@RequestParam(value = "code", required = false) String code, @RequestParam(value = "uid", required = false) String uid,
		@RequestParam(value = "subject", required = false) String subject, @RequestParam(value = "contents", required = false) String contents,
		@RequestParam(value = "appPath", required = false) String appPath) throws Exception {

		log.info("#######API MAIL SEND START#########");

		ModelAndView mav = new ModelAndView();
		mav.setViewName("jsonView");

		DomainInfoBean domainInfo = domainService.getDomainInfo(request.getServerName(), DomainService.WHOST);
		String mhost = domainInfo.getMhost();
		String domain = domainInfo.getDomain();
		String ahost = domainInfo.getAhost();

		// 사번으로 이메일 사용자 정보를 취득
		UserInfoBean userInfoBean = userService.getUserInfoForMailId(mhost, userid);
		// 이메일 사용자 정보에 사용자 정보가 존재하지 않는경우는 0을 리턴
		if (userInfoBean == null || StringUtils.isEmpty(userInfoBean.getUserid())) {
			throw new Exception();
		}
		// 휴면해제인 상태인 경우, 해제처리
		if (userInfoBean.getReceiver_enable() == UserInfoBean.RECEIVER_ENABLE__SLEEP) {
			userService.updateReceiverEnabled(mhost,userInfoBean.getUserid() , UserInfoBean.RECEIVER_ENABLE__NORMAL);
		}
		User user = new User(ahost,userInfoBean);

		MailWriteForm writeForm = new MailWriteForm();

		String userId = userInfoBean.getUserid();
		String mailid = userInfoBean.getMailid();
		String name = userInfoBean.getName();
		String fromEmail = mailid + "@" + domain;

		writeForm.setFirst("0");

		writeForm.setSendmode("0");
		writeForm.setApproval_flag("2");
		writeForm.setSubject(subject);
		writeForm.setBody(contents);
		if (StringUtils.isNotEmpty(appPath)) {
			appPath = appPath.replace("-->", ",");
		}
		writeForm.setApUser(appPath);
		writeForm.setFromaddr(fromEmail);
		writeForm.setDirKey("TOTAL");
		writeForm.setIs_receipt("1");
		writeForm.setIs_save("1");
		writeForm.setTo(name + "<" + mailid + "@" + domain + ">");
		writeForm.setFromname(name);
		writeForm.setCharacterset("UTF-8");
		ApprovalSend approvalSend = (ApprovalSend) ContextLoader.getCurrentWebApplicationContext().getBean("approvalSend");
		try {
			approvalSend.request(request, user, writeForm);
		} catch (Exception e) {
			String errorId = ErrorTraceLogger.log(e);
			log.error("{} - appsend ERROR", errorId);
		}
		// 발송결과에 대해 안내 문구 설정 : start 			
		String send_result_txt = message.getMessage("M0247", "결재문서를 발신하였습니다.");
		String send_result_txt_desc = message.getMessage("M0248", "결재상태를 확인하시려면 결재발신함을 참고하세요");

		mav.addObject("send_result_txt", send_result_txt);
		mav.addObject("send_result_txt_desc", send_result_txt_desc);

		// 발송결과에 대해 안내 문구 설정 : end
		log.debug("MailSend Complete");
		mav.addObject("resultCode", code);
		mav.addObject("resultMessage", send_result_txt);
		if (StringUtils.isNotEmpty(send_result_txt_desc)) {
			mav.addObject("resultMessage_desc", send_result_txt_desc);
		}

		String apKey = approvalSend.getApiReturnKey();
		log.debug("apKey :{}", apKey);
		if (StringUtils.isNotEmpty(apKey)) {
			ApiApprovalBean apiBean = new ApiApprovalBean();
			apiBean.setApKey(apKey);
			apiBean.setCode(code);
			apiBean.setMhost(mhost);
			apiBean.setUid(uid);
			apiBean.setUserid(userId);

			apiService.insertApiApprovalInfo(apiBean);
		}
		log.info("#######API MAIL SEND END#########");
	}
}
