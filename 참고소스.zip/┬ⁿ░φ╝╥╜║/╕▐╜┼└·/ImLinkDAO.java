package com.imoxion.sensmail.server.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.ibatis.session.SqlSession;

import com.imoxion.common.database.ImDatabaseConnectionEx;
import com.imoxion.sensmail.server.beans.ImEzQMessengerBean;

public class ImLinkDAO {
	// 이지닉스 메신저
	public int insertEzQMessenger(ImEzQMessengerBean amBean) throws Exception{
		SqlSession session  = null;
		Connection conn = null;
		PreparedStatement ps = null;
		int ret = 0;
		try{
			String sql = "INSERT INTO intraware.msg_alarm (MSG_KEY, MSG_GUBUN, ACTION_CODE, SYSTEM_NAME, SEND_ID, SEND_NAME, RECV_IDS, SUBJECT, CONTENTS, URL, SEND_YN) " +
				" VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
			
			session  = ImDatabaseConnectionEx.getConnection("nypi");
			conn = session.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, amBean.getMsg_key());
			ps.setString(2, amBean.getMsg_gubun());
			ps.setString(3, amBean.getAction_code());
			ps.setString(4, amBean.getSystem_name());
			ps.setString(5, amBean.getSend_id());
			ps.setString(6, amBean.getSend_name());
			ps.setString(7, amBean.getRecv_ids());
			ps.setString(8, amBean.getSubject());
			ps.setString(9, amBean.getContents());
			ps.setString(10, amBean.getUrl());
			ps.setString(11, "N");
			
			ret = ps.executeUpdate();

		}catch(Exception ex){
			throw ex;
		}finally{
			try{ if(ps != null) ps.close(); }catch(Exception e){}
			try{ if(conn != null) conn.close(); }catch(Exception e){}
			try{ if(session != null) session.close(); }catch(Exception e){}
		}
		
		return ret;
	}
}
