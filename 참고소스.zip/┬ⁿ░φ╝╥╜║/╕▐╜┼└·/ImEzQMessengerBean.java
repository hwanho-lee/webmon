package com.imoxion.sensmail.server.beans;

import org.apache.ibatis.type.Alias;

@Alias("ezQMessengerBean")
public class ImEzQMessengerBean {

	private String msg_key;			// 메세지 Key 값
	
	private String msg_gubun;		// 전송구분
	
	private String action_code;		// 알림 구분
	
	private String system_name;		// 시스템명
	
	private String send_id;			// 전송자 ID (사번)
	
	private String send_name;		// 사용자 이름
	
	private String recv_ids;		// 사용자 사번
	
	private String subject;			// 알림 제목
	
	private String contents;		// 알림 메세지
	
	private String url;				// 메일 보기 URL
	

	public String getMsg_key() {
		return msg_key;
	}

	public void setMsg_key(String msg_key) {
		this.msg_key = msg_key;
	}

	public String getMsg_gubun() {
		return msg_gubun;
	}

	public void setMsg_gubun(String msg_gubun) {
		this.msg_gubun = msg_gubun;
	}

	public String getAction_code() {
		return action_code;
	}

	public void setAction_code(String action_code) {
		this.action_code = action_code;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public String getSend_id() {
		return send_id;
	}

	public void setSend_id(String send_id) {
		this.send_id = send_id;
	}

	public String getSend_name() {
		return send_name;
	}

	public void setSend_name(String send_name) {
		this.send_name = send_name;
	}

	public String getRecv_ids() {
		return recv_ids;
	}

	public void setRecv_ids(String recv_ids) {
		this.recv_ids = recv_ids;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
	
}
