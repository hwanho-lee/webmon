package com.imoxion.sensmail.server.smail;

import java.net.URLEncoder;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.UUID;

import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.lang.StringUtils;

import com.cs.rifis.comm.util.AES128Util;
import com.imoxion.common.mail.ImMessage;
import com.imoxion.common.util.ImStringUtil;
import com.imoxion.sensmail.server.ImSmtpServer;
import com.imoxion.sensmail.server.beans.ImEzQMessengerBean;
import com.imoxion.sensmail.server.dao.ImLinkDAO;
import com.imoxion.sensmail.server.logger.ImLoggerEx;
import com.imoxion.sensmail.server.user.ImDomainInfo;
import com.imoxion.sensmail.server.user.ImUserInfo;
import com.imoxion.sensmail.server.util.ImSmtpSendData;

/**
 * 메신저 알람 모듈
 * 
 * @author imoxion
 *
 */
public class ImSmailEzQMessAlert implements ISmailProcessFilter {
	private String m_sUrl = "";
	private String m_sError = "";
		
	public ImSmailEzQMessAlert() {
	}

	public boolean doProcess(ImDomainInfo di, ImUserInfo ui, ImSmtpSendData sd) {
		return false;
	}

	public boolean doProcess(ImDomainInfo di, ImUserInfo ui, ImSmtpSendData sd,
			String queuePath) {
		return false;
	}

	public boolean doProcess(ImDomainInfo di, ImUserInfo ui, ImSmtpSendData sd, ImMessage im) {
		
		try{
			ImLoggerEx.info("SMAIL", "ImSmailEzQMessAlert start");
			
			if (ui == null || StringUtils.isEmpty(ui.getOffice_no())) {
				return true;
			}
			
			String weburl = ImSmtpServer.confSensmail.getProfileString("general","weburl");
			String ssoKey = ImSmtpServer.confSensmail.getProfileString("sso","aintop_sso_key");
						
			String msg_key = makeMsgKey();
			String sSubject = ImStringUtil.getSafeString(im.getSubjectFromHeader());

			if(sSubject.trim().equals("")){
				sSubject = "[Empty Subject]";
			}
			
			String sFrom = im.getFromToString();
			String sFromName = "";
			String sFromEmail = "";
			if(sFrom != null && !sFrom.equals("")){
				//sFrom = im.getDaewooEmail(sFrom,null);
				int nChIndex = sFrom.lastIndexOf("<");
				if(nChIndex != -1){
					sFromName = sFrom.substring(0, nChIndex);
					sFromEmail = ImStringUtil.getStringBetween(sFrom.trim(),"<",">");
				}else{
					sFromName = sFrom.substring(0, sFrom.indexOf("@"));
					sFromEmail = sFrom;
				}
			}
			
			String send_id = sFromEmail;
			if (sFromEmail != null && !"".equals(sFromEmail) && sFromEmail.indexOf("@nypi.re.kr") > 0) {
				send_id = sFromEmail.substring(0, sFromEmail.indexOf("@nypi.re.kr"));
			}
			
			StringBuffer contentBuff = new StringBuffer();
			contentBuff.append("새 메일이 도착하였습니다.\n");
			contentBuff.append("- 메일발신자 : ").append(sFrom).append("\n");
			contentBuff.append("- 메일제목 : ").append(sSubject);
						
			StringBuffer mailViewUrlBuff = new StringBuffer();
			mailViewUrlBuff.append(weburl).append("/sso/login.do");
			
			if (StringUtils.isNotEmpty(ssoKey)) {
				URLCodec codec = new URLCodec();				
				AES128Util aes128 = new AES128Util(ssoKey);
				
				mailViewUrlBuff.append("?").append("emp_code=").append(codec.encode(aes128.aesEncode(ui.getOffice_no())));
				mailViewUrlBuff.append("&").append("mailid=").append(codec.encode(aes128.aesEncode(ui.getMailID())));
				mailViewUrlBuff.append("&").append("type=").append(codec.encode(aes128.aesEncode("VIEW")));
				mailViewUrlBuff.append("&").append("dirkey=").append(codec.encode(aes128.aesEncode(sd.getDirKey())));
				mailViewUrlBuff.append("&").append("mailkey=").append(codec.encode(aes128.aesEncode(sd.getMailUkey())));
				mailViewUrlBuff.append("&").append("p_type=").append(codec.encode(aes128.aesEncode("E")));
			} else {
				mailViewUrlBuff.append("?").append("emp_code=").append(URLEncoder.encode(ui.getOffice_no(), "UTF-8"));
				mailViewUrlBuff.append("&").append("mailid=").append(URLEncoder.encode(ui.getMailID(), "UTF-8"));
				mailViewUrlBuff.append("&").append("type=").append(URLEncoder.encode("VIEW", "UTF-8"));
				mailViewUrlBuff.append("&").append("dirkey=").append(URLEncoder.encode(sd.getDirKey(), "UTF-8"));
				mailViewUrlBuff.append("&").append("mailkey=").append(URLEncoder.encode(sd.getMailUkey(), "UTF-8"));
			}
						
			// 메신저 DB에 저장할 데이터
			ImEzQMessengerBean bean = new ImEzQMessengerBean();
			bean.setMsg_key(msg_key);					// 메세지 Key 값
			bean.setMsg_gubun("ALERT");					// 전송 구분 (알림 : ALERT)
			bean.setAction_code("ALERT");				// 알림 구분 (알림 : ALERT, 읽음처리(READ), 삭제(DELETE))
			bean.setSystem_name("MAIL");				// 시스템명
			bean.setSend_id(send_id);					// 전송자 ID (내부 발송자 : 메일 아이디, 외부 사용자 : 메일주소)
			bean.setSend_name(sFromName);				// 전송자 이름
			bean.setRecv_ids(ui.getMailID());			// 수신자 ID (메일 아이디)
			//bean.setSubject("[알림] 새 메일이 도착했습니다.");	// 알림 제목
			bean.setSubject(sSubject); 					// 알림 제목
			bean.setContents(contentBuff.toString());	// 알림 내용
			bean.setUrl(mailViewUrlBuff.toString());	// 메일 보기 URL
			
			ImLinkDAO linkDAO = new ImLinkDAO();
			linkDAO.insertEzQMessenger(bean);
			
			ImLoggerEx.info("SMAIL", "ImSmailEzQMessAlert insert - msg_key : {}", msg_key);
				
			
		}catch(Exception ex){
			ImLoggerEx.error("SMAIL", "ImSmailEzQMessAlert : " + ex);
		}

		return true;
	}

	private static String makeMsgKey() {
				
		TimeZone wTimeZone = TimeZone.getTimeZone("GMT+9");
		Calendar wNow = Calendar.getInstance(wTimeZone);
		
		int wYear    = wNow.get(Calendar.YEAR);
	    int wMonth   = wNow.get(Calendar.MONTH) + 1;
	    int wDay     = wNow.get(Calendar.DATE);
	    int wHour    = wNow.get(Calendar.HOUR_OF_DAY);
	    int wMinute  = wNow.get(Calendar.MINUTE);
	    int wSecond  = wNow.get(Calendar.SECOND);
	    int wMiliSec = wNow.get(Calendar.MILLISECOND);
	    
	    StringBuffer fullDateBuff = new StringBuffer();
	    fullDateBuff.append(wYear);
	    fullDateBuff.append(wMonth < 10 ? "0"+ wMonth : wMonth);
	    fullDateBuff.append(wDay < 10 ? "0"+ wDay : wDay);
	    fullDateBuff.append(wHour < 10 ? "0"+ wHour : wHour);
	    fullDateBuff.append(wMinute < 10 ? "0"+ wMinute : wMinute);
	    fullDateBuff.append(wSecond < 10 ? "0"+ wSecond : wSecond);
	    fullDateBuff.append(wMiliSec < 100 ? (wMiliSec < 10 ? "00"+ wMiliSec : "0"+ wMiliSec) :  wMiliSec);
	    
	    String key = UUID.randomUUID().toString().replaceAll("-","").substring(0, 10);
	    
	    String wFullDate  = fullDateBuff.toString() +"_"+ key;
	    
    	return wFullDate;

	}

	public String getMessage(){
		return null;
	}
	
	public String getError() {
		// TODO Auto-generated method stub
		return m_sError;
	}

	public int getErrorCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setConfigFile(String confPath) {
		// TODO Auto-generated method stub

	}

	public void setParam(String name, String value) {
		// TODO Auto-generated method stub
		if(name.equalsIgnoreCase("URL")){
			m_sUrl = value;
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		String msg_key = makeMsgKey();
//		
//		System.out.println("msg_key ==> "+ msg_key +", length ==> "+ msg_key.length());
		
		String sFrom = "서민정 <dongguli@imoxion.com>";
		//String sFrom = "imoxion@nypi.re.kr";
		String sFromName = "";
		String sFromEmail = "";
		if(sFrom != null && !sFrom.equals("")){
			//sFrom = im.getDaewooEmail(sFrom,null);
			int nChIndex = sFrom.lastIndexOf("<");
			if(nChIndex != -1){
				sFromName = sFrom.substring(0, nChIndex);
				sFromEmail = ImStringUtil.getStringBetween(sFrom.trim(),"<",">");
			}else{
				sFromName = sFrom.substring(0, sFrom.indexOf("@"));
				sFromEmail = sFrom;
			}
		}
		
		String send_id = sFromEmail;
		if (sFromEmail != null && !"".equals(sFromEmail) && sFromEmail.indexOf("@nypi.re.kr") > 0) {
			send_id = sFromEmail.substring(0, sFromEmail.indexOf("@nypi.re.kr"));
		}
		
		System.out.println("sFromName ==> "+ sFromName);
		System.out.println("sFromEmail ==> "+ sFromEmail);
		System.out.println("send_id ==> "+ send_id);
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

}
