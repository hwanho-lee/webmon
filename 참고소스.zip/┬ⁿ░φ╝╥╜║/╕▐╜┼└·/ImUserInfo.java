package com.imoxion.sensmail.server.user;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.imoxion.common.util.ImStringUtil;
import com.imoxion.common.util.ImTimeUtil;
import com.imoxion.sensmail.common.domain.GroupInfo;
import com.imoxion.sensmail.server.ImSmtpServer;
import com.imoxion.sensmail.server.beans.AllowCountryBean;
import com.imoxion.sensmail.server.beans.ImCapacityGroupBean;
import com.imoxion.sensmail.server.beans.ImDomainInfoBean;
import com.imoxion.sensmail.server.beans.ImUserInfoBean;
import com.imoxion.sensmail.server.dao.ImMailDataDAO;
import com.imoxion.sensmail.server.dao.ImUserInfoDAO;
import com.imoxion.sensmail.server.logger.ErrorTraceLogger;
import com.imoxion.sensmail.server.logger.ImLoggerEx;
import com.imoxion.sensmail.server.service.DomainService;
import org.apache.commons.lang.StringUtils;

public class ImUserInfo{

    private String m_sMhost;
    private String m_sDomain;
    private String m_sAliasDomain;
    private String m_sUserDomainAlias;
    private String m_sUserOldDomainAlias;
    private String m_sUserID;
    private String m_sMailID;
    private String m_sName;
    private String m_sPassword;
    private String m_sOffice_no;
    private String m_sType;
    private String m_sRedirect;
    private String m_sLRedirect;
    private String m_sIpConn;
    private String m_sGroupID;
    private String m_sCharset = "EUC-KR";
    private String m_sInboxKey = "";
    private String m_sWorkKey = "";    // 업무 편지함 추가
    private String m_sSpamKey = "";
    private String m_sTrashKey = "";
    private String m_sAuthDelay = "";    // 인증 대기 편지함 추가
    private String m_sTomeKey = "";     // 내게쓴 메일함 추가
    private String m_sWaitKey = ""; 	// 수신대기함
    private String m_sRedirect_mailbox = "";

    private int m_nRecvEnable;
    private int m_nPopEnable;
    private int m_nImapEnable;
    private int m_nIsRelay;
    private int m_nClosedML;
    private int m_nDeliverMBox;
    private int m_nIsGroup;
    private int m_nIsAbsent;
    private int m_nSpamLevel;
    private int m_nIsBlockNullTo;
    private int m_nIsBlockEng;

    private long m_lMBoxSize;
    private long m_lCurrSize;
    private long m_lLastConnTime;

    private boolean m_bAuthMail = false;

    private String m_sTel = "";
    private String m_sHandphone = "";

    private int use_workmbox = 1;

    private String m_sExt = "0";

    private String m_sTbl_no = "01";

    private int m_nPart_no = 0;

    private int passwd_failcnt = 0;

    private String smtp_logindate = "";
    private String pop3_logindate = "";
    private String imap_logindate = "";

    private String m_sPop3Date = "0000-00-00";
    private String size_notice = "";
    private String size_notice_date = "";

    private String pwd_type = "";    // 비밀번호 알고리즘
    private String savecopy_pop3 = "0"; // 사본저장여부 : 사본저장이면 삭제명령시 휴지통으로 보냄

    private String jid = "";
    private String m_sCountryCode = "";

    private int gid = 0;

    // 부재중 응답 대리인 설정
    private boolean isDeputy = false;
    private String deputyEmail = "";

    // 아카이빙 여부
    private String use_archive = "0";

    // smtp 인증 사용 여부
    private String smtpperms = "1";

    // whitelist 사용여부
    private String use_waitbox = "0";

    public String getUse_waitbox() {
        return use_waitbox;
    }

    public void setUse_waitbox(String use_waitbox) {
        this.use_waitbox = use_waitbox;
    }

    /**
     * 화이트리스트 사용여부
     */


	public String getSmtpPerms() {
        return smtpperms;
    }

    public String getUse_archive() {
        return use_archive;
    }

    public void setUse_archive(
            String use_archive) {
        this.use_archive = use_archive;
    }

    public String getCountryCode() {
        return m_sCountryCode;
    }

    public void setCountryCode(String sCountryCode) {
        this.m_sCountryCode = sCountryCode;
    }

    public String getJid() {
        return jid;
    }

    public void setJid(
            String jid) {
        this.jid = jid;
    }

    public String getSavecopy_pop3() {
        return savecopy_pop3;
    }

    public void setSavecopy_pop3(String savecopyPop3) {
        savecopy_pop3 = savecopyPop3;
    }

    public String getSize_notice() {
        return size_notice;
    }

    public void setSize_notice(String size_notice) {
        this.size_notice = size_notice;
    }

    public String getPop3Date() {
        return m_sPop3Date;
    }

    public void setPop3Date(String mSPop3Date) {
        m_sPop3Date = mSPop3Date;
    }

    public int getPasswd_failcnt() {
        return passwd_failcnt;
    }

    public void setPasswd_failcnt(int passwd_failcnt) {
        this.passwd_failcnt = passwd_failcnt;
    }

    public int getPart_no() {
        return m_nPart_no;
    }

    public void setPart_no(int m_nPart_no) {
        this.m_nPart_no = m_nPart_no;
    }

    public String getTbl_no() {
        return m_sTbl_no;
    }

    public void setTbl_no(String mSTblno) {
        m_sTbl_no = mSTblno;
    }

    public static String LANG_KOR = "ko";
    public static String LANG_ENG = "en";
    public static String LANG_JPN = "ja";
    public static String LANG_CHN = "zh";

    private String m_sLang = LANG_KOR;

    public String getLang() {
        return m_sLang;
    }

    public void setLang(String mSLang) {
        m_sLang = mSLang;
    }

    public String getExt() {
        // TODO Auto-generated method stub
        return m_sExt;
    }

    public void setExt(String ext) {
        // TODO Auto-generated method stub
        m_sExt = ext;
    }

    /**
     * @return m_sInboxKey; �����մϴ�.
     */
    public String getInboxKey() {
        return m_sInboxKey;
    }

    public String getWaitKey() {
        return m_sWaitKey;
    }

    /**
     * @return m_sSpamKey; �����մϴ�.
     */
    public String getSpamKey() {
        return m_sSpamKey;
    }

    /**
     * @return m_sTrashKey; �����մϴ�.
     */
    public String getTrashKey() {
        return m_sTrashKey;
    }

    /**
     * @return m_nSpamLevel �����մϴ�.
     */
    public int getSpamLevel() {
        return m_nSpamLevel;
    }

    /**
     * @return m_nIsBlockNullTo �����մϴ�.
     */
    public int getIsBlockNullTo() {
        return m_nIsBlockNullTo;
    }

    /**
     * @return m_nIsBlockEng �����մϴ�.
     */
    public int getIsBlockEng() {
        return m_nIsBlockEng;
    }

    /**
     * @return m_sAliasDomain; �����մϴ�.
     */
    public String getAliasDomain() {
        return m_sAliasDomain;
    }

    /**
     * @param aliasDomain ��d�Ϸt� m_sAliasDomain.
     */
    public void setAliasDomain(String aliasDomain) {
        m_sAliasDomain = aliasDomain;
    }

    /**
     * @return m_lLastConnTime; �����մϴ�.
     */
    public long getLastConnTime() {
        return m_lLastConnTime;
    }

    /**
     * @param lastConnTime ��d�Ϸt� m_lLastConnTime.
     */
    public void setLastConnTime(long lastConnTime) {
        m_lLastConnTime = lastConnTime;
    }

    /**
     * @return m_lMBoxSize; �����մϴ�.
     */
    public long getMBoxSize() {
        return m_lMBoxSize;
    }

    /**
     * @param boxSize ��d�Ϸt� m_lMBoxSize.
     */
    public void setMBoxSize(long boxSize) {
        m_lMBoxSize = boxSize;
    }


    /**
     * �뷮f���� Ȯ��
     *
     * @return m_nIsGroup; �����մϴ�.
     */
    public int getIsGroup() {
        return m_nIsGroup;
    }

    /**
     * @param isGroup ��d�Ϸt� m_nIsGroup.
     */
    public void setIsGroup(int isGroup) {
        m_nIsGroup = isGroup;
    }

    /**
     * @return m_sDomain; �����մϴ�.
     */
    public String getDomain() {
        return m_sDomain;
    }

    public String getMhost() { return m_sMhost; }

    public String getTomeKey() {
        return m_sTomeKey;
    }

    public void setTomeKey(String mSTomeKey) {
        m_sTomeKey = mSTomeKey;
    }

    /**
     * @param domain ��d�Ϸt� m_sDomain.
     */
    
    public void setDomain(String domain) {
        m_sDomain = domain;
    }

    /**
     * @return m_sGroupID; �����մϴ�.
     */
    public String getGroupID() {
        return m_sGroupID;
    }

    /**
     * @param groupID ��d�Ϸt� m_sGroupID.
     */
    public void setGroupID(String groupID) {
        m_sGroupID = groupID;
    }

    /**
     * @return m_sIpConn; �����մϴ�.
     */
    public String getIpConn() {
        return m_sIpConn;
    }

    /**
     * @param ipConn ��d�Ϸt� m_sIpConn.
     */
    public void setIpConn(String ipConn) {
        m_sIpConn = ipConn;
    }

    /**
     * @return m_sLRedirect; �����մϴ�.
     */
    public String getLRedirect() {
        return m_sLRedirect;
    }

    /**
     * @param redirect ��d�Ϸt� m_sLRedirect.
     */
    public void setLRedirect(String redirect) {
        m_sLRedirect = redirect;
    }

    /**
     * @return m_sName; �����մϴ�.
     */
    public String getName() {
        return m_sName;
    }

    /**
     * @param name ��d�Ϸt� m_sName.
     */
    public void setName(String name) {
        m_sName = name;
    }

    /**
     * @return m_sPassword; �����մϴ�.
     */
    public String getPassword() {
        return m_sPassword;
    }

    /**
     * @param password ��d�Ϸt� m_sPassword.
     */
    public void setPassword(String password) {
        m_sPassword = password;
    }

    public String getOffice_no() {
		return m_sOffice_no;
	}

	public void setOffice_no(String office_no) {
		m_sOffice_no = office_no;
	}

	/**
     * @return m_sRedirect; �����մϴ�.
     */
    public String getRedirect() {
        return m_sRedirect;
    }

    /**
     * @param redirect ��d�Ϸt� m_sRedirect.
     */
    public void setRedirect(String redirect) {
        m_sRedirect = redirect;
    }

    /**
     * @return m_sType; �����մϴ�.
     */
    public String getType() {
        return m_sType;
    }

    /**
     * @param type ��d�Ϸt� m_sType.
     */
    public void setType(String type) {
        m_sType = type;
    }

    /**
     * @return m_sUserID; �����մϴ�.
     */
    public String getUserID() {
        return m_sUserID;
    }

    /**
     * @param userID ��d�Ϸt� m_sUserID.
     */
    public void setUserID(String userID) {
        m_sUserID = userID;
    }

    /**
     * @return nClosedML; �����մϴ�.
     */
    public int getClosedML() {
        return m_nClosedML;
    }

    /**
     * @param closedML ��d�Ϸt� nClosedML.
     */
    public void setClosedML(int closedML) {
        m_nClosedML = closedML;
    }

    /**
     * @return nDeliverMBox; �����մϴ�.
     */
    public int getDeliverMBox() {
        return m_nDeliverMBox;
    }

    /**
     * @param deliverMBox ��d�Ϸt� nDeliverMBox.
     */
    public void setDeliverMBox(int deliverMBox) {
        m_nDeliverMBox = deliverMBox;
    }

    /**
     * @return nIsRelay; �����մϴ�.
     */
    public int getIsRelay() {
        return m_nIsRelay;
    }

    /**
     * @param isRelay ��d�Ϸt� nIsRelay.
     */
    public void setIsRelay(int isRelay) {
        m_nIsRelay = isRelay;
    }

    /**
     * @return nPopEnable; �����մϴ�.
     */
    public int getPopEnable() {
        return m_nPopEnable;
    }

    /**
     * @param popEnable ��d�Ϸt� nPopEnable.
     */
    public void setPopEnable(int popEnable) {
        m_nPopEnable = popEnable;
    }

    public int getImapEnable() {
        return m_nImapEnable;
    }

    public void setImapEnable(int imapEnable) {
        m_nImapEnable = imapEnable;
    }

    /**
     * @return nRecvEnable; �����մϴ�.
     */
    public int getRecvEnable() {
        return m_nRecvEnable;
    }

    /**
     * @param recvEnable ��d�Ϸt� nRecvEnable.
     */
    public void setRecvEnable(int recvEnable) {
        m_nRecvEnable = recvEnable;
    }

    /**
     * @return m_lCurrSize ; �����մϴ�..
     */
    public long getCurrSize() {
        return m_lCurrSize;
    }

    /**
     * @return m_nIsAbsent ; �����մϴ�..
     */
    public long getIsAbsent() {
        return m_nIsAbsent;
    }

    /**
     * @return m_sCharset ; �����մϴ�..
     */
    public String getCharset() {
        return m_sCharset;
    }

    /**
     * @return ��:�뷮
     */
    public long getAvailMBoxSize() {
        long lAvailSize = -1;

        if (getIsRealGroup() != 1) {
            // ��df �϶�
            try {
                m_lMBoxSize = m_lMBoxSize * 1024;

                if (m_lMBoxSize == 0) {    // unlimitted
                    lAvailSize = Long.MAX_VALUE;
                } else {
                    if (m_lMBoxSize <= m_lCurrSize) {
                        lAvailSize = -1;
                    } else {
                        lAvailSize = m_lMBoxSize - m_lCurrSize;
                    }
                }
            } catch (Exception ex) {
                String errorId = ErrorTraceLogger.log(ex);
                ImLoggerEx.error("{} - [Userinfo]   ", errorId);

            }
        } else {
            // �뷮f �϶�
            lAvailSize = getGroupCapSize();
        }
        return lAvailSize;
    }

    /**
     * ����� �뷮f���� Ȯ��
     *
     * @return �뷮f�� ����ں� �뷮; �Ҵ��ϸ� 0, �ƴϸ� 1
     */
    private int getIsRealGroup() {
        int nUseQuota = 1;

        if (m_sGroupID.equals("")) {
            return 0;
        }
        try {
            ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
            nUseQuota = userDao.getIsRealGroup(m_sGroupID);
        } catch (Exception ex) {
            String errorId = ErrorTraceLogger.log(ex);
            ImLoggerEx.error("{} - [Userinfo]   ", errorId);
            return 0;
        }

        if (nUseQuota == 1) return 0;
        else return 1;
    }

    /**
     * @return �뷮f�ϰ�� ��:�뷮
     */
    private long getGroupCapSize() {
        long lMaxSize;
        long lCurrSize;
        long lAvailSize = -1;

        if (m_sGroupID == null || m_sGroupID.equals("")) {
            //lAvailSize = getAvailMBoxSize();
            lAvailSize = -1;
        } else {
            try {
                ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
                ImCapacityGroupBean groupSize = userDao.getGroupCapSize(m_sGroupID, m_sMhost);


                if (groupSize != null) {
                    lMaxSize = groupSize.getTot_size();
                    lCurrSize = groupSize.getCurrsize();

                    if (lMaxSize == 0) {
                        lAvailSize = Long.MAX_VALUE;
                    } else {
                        if (lMaxSize <= lCurrSize) {
                            lAvailSize = -1;
                        } else {
                            lAvailSize = lMaxSize - lCurrSize;
                        }
                    }
                }
            } catch (Exception ex) {
                String errorId = ErrorTraceLogger.log(ex);
                ImLoggerEx.error("{} - [Userinfo]   ", errorId);
            }
        }

        return lAvailSize;
    }

    private void setPop3ImapEnableInfo(String mhost, int gid, int userPopEnable, int userImapEnable) {
        ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
        m_nPopEnable = 1;
        m_nImapEnable = 1;
        DomainService domainService = DomainService.getInstance();
        try {
            // 도메인 설정
            ImDomainInfoBean domainInfo = domainService.getDomainInfoForMhost(mhost);
            if (domainInfo.getPopenable() == 0) {
                m_nPopEnable = 0;
            }
            if (domainInfo.getImapenable() == 0) {
                m_nImapEnable = 0;
            }
            //ImLoggerEx.info("domain info {} / {}", m_nPopEnable, m_nImapEnable);
            // 도메인에서 pop3/imap 모두 사용안함이면 종료
            if (m_nPopEnable == 0 && m_nImapEnable == 0) return;

            // 그룹설정
            GroupInfo groupInfo = userDao.getGroupInfo(mhost, gid);
            if (m_nPopEnable == 1) {
                m_nPopEnable = "1".equals(groupInfo.getPop3_perm()) ? 1 : 0;
            }

            if (m_nImapEnable == 1) {
                m_nImapEnable = "1".equals(groupInfo.getImap_perm()) ? 1 : 0;
            }
            //ImLoggerEx.info("group info {} / {}", m_nPopEnable, m_nImapEnable);
            // 개인설정
            if (m_nPopEnable == 1) {
                m_nPopEnable = userPopEnable;
            }

            if (m_nImapEnable == 1) {
                m_nImapEnable = userImapEnable;
            }
            //ImLoggerEx.info("user info {} / {}", m_nPopEnable, m_nImapEnable);
        } catch (Exception ex) {
            String errorId = ErrorTraceLogger.log(ex);
            ImLoggerEx.error("{} - [setPop3ImapEnableInfo]   ", errorId);
        }
    }

    /**
     * 사용자정보를 현재 객체에 적용한다.
     * @param userBean
     * @throws Exception
     */
    private void setUserInfo(ImUserInfoBean userBean ) throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        m_sMhost = userBean.getMhost();
        m_sDomain = userBean.getDomain();
        m_sTbl_no = userBean.getTbl_no();
        m_nPart_no = userBean.getPart_no();
        m_sUserID = userBean.getUserid();
        m_sName = userBean.getName();
        m_sMailID = userBean.getMailid();
        m_sOffice_no = userBean.getOffice_no();
        this.gid = userBean.getGid();

        // pop3, imap 사용권한 설정
        setPop3ImapEnableInfo(m_sMhost, this.gid, userBean.getPopenable(), userBean.getImapenable());

//            	m_sPassword = ImUtils.strDecrypt(ImStringUtil.getSafeString(userBean.getPasswd()));
        m_sPassword = ImStringUtil.getSafeString(userBean.getPasswd());
        m_sType = userBean.getUtype();
        m_sRedirect = ImStringUtil.getSafeString(userBean.getRedirect());
        m_sIpConn = ImStringUtil.getSafeString(userBean.getIpconn());
        m_sGroupID = ImStringUtil.getSafeString(userBean.getCapgroup_id());

        m_nIsAbsent = ImStringUtil.parseInt(userBean.getCall());

            /* 자동 전달 수정후 추가 스키마 2006-11-8 */
        m_sRedirect_mailbox = ImStringUtil.getSafeString(userBean.getRedirect_mailbox());

        m_nRecvEnable = userBean.getReceiver_enable() != null ? userBean.getReceiver_enable() : 0;
        //m_nPopEnable = userBean.getPopenable();
        //m_nImapEnable = userBean.getImapenable();
        m_nIsRelay = userBean.getIsrelay() != null ? userBean.getIsrelay() : 0;
        m_nClosedML = userBean.getClosedml() != null ? userBean.getClosedml() : 0;
        m_nDeliverMBox = userBean.getDeliver_mbox() != null ? userBean.getDeliver_mbox() : 0;
        m_nIsGroup = userBean.getIscapgroup() != null ? userBean.getIscapgroup() : 0;
        m_nSpamLevel = userBean.getIsspam() != null ? userBean.getIsspam() : 0;
        m_nIsBlockNullTo = userBean.getBlock_nullto() != null ? userBean.getBlock_nullto() : 0;
        m_nIsBlockEng = userBean.getBlock_eng() != null ? userBean.getBlock_eng() : 0;

        m_lLastConnTime = userBean.getIpconntime() != null ? userBean.getIpconntime() : 0;
        m_lCurrSize = userBean.getCurrsize() != null ? userBean.getCurrsize() : 0;
        m_lMBoxSize = userBean.getMboxsize() != null ? userBean.getMboxsize() : 0;

        pwd_type = userBean.getPwd_type();
        savecopy_pop3 = userBean.getSavecopy_pop3();

        // 접속허용국가
        ImUserInfoDAO userDAO = ImUserInfoDAO.getDAO();
        List<AllowCountryBean> allowCountryList = new ArrayList<>();
        List<AllowCountryBean> domainCountryList = userDAO.getDomainAllowCountryCode(userBean.getMhost());
        List<AllowCountryBean> userCountryList = userDAO.getUserAllowCountryCode(userBean.getMhost(), userBean.getUserid());

        if (domainCountryList.size() > 0) allowCountryList.addAll(domainCountryList);
        if (userCountryList.size() > 0) allowCountryList.addAll(userCountryList);

        String allowCountryCode = countryProcess(allowCountryList);
        m_sCountryCode = allowCountryCode;

        String sAuthMail = userBean.getIsauthmail();
        if (sAuthMail != null && sAuthMail.equalsIgnoreCase("Y")) {
            m_bAuthMail = true;
        } else {
            m_bAuthMail = false;
        }

        use_workmbox = userBean.getUse_workmbox();

            /* 카이스트 수정 내역*/
        if (userBean.getSmtp_logindate() != null)
            smtp_logindate = sdf.format(userBean.getSmtp_logindate());
        if (userBean.getPop3_logindate() != null)
            pop3_logindate = sdf.format(userBean.getPop3_logindate());
        if (userBean.getImap_logindate() != null)
            imap_logindate = sdf.format(userBean.getImap_logindate());


//            	passwd_failcnt = rs.getInt("passwd_failcnt");

        m_sPop3Date = userBean.getPop3date();//rs.getString("pop3date");
        if (m_sPop3Date == null || m_sPop3Date.equals("")) m_sPop3Date = "0000-00-00";


        if (ImSmtpServer.useMobileApps == 1) {
            this.setJid(userBean.getJid());
        }

        this.use_archive = userBean.getUse_archive();
        this.smtpperms = userBean.getSmtpperms();
        this.use_waitbox = userBean.getUse_waitbox();

        m_sInboxKey = "Inbox_" + m_sUserID;
        m_sWorkKey = "Work_" + m_sUserID;
        m_sSpamKey = "Spam_" + m_sUserID;
        m_sTrashKey = "Trash_" + m_sUserID;
        m_sAuthDelay = "Auth_" + m_sUserID;
        m_sTomeKey = "Tome_" + m_sUserID;
        m_sWaitKey = "Wait_" + m_sUserID;
    }
    /**
     * 도메인과 메일아이디를 이용하여 사용자 정보를 구한다
     * @param p_sDomain
     * @param p_sMailid
     * @return
     */
    public boolean getUserInfo(String p_sDomain, String p_sMailid ) {
        boolean bRet = false;
        try {
            DomainService domainService = DomainService.getInstance();
            ImDomainInfoBean domainInfo = domainService.getDomainInfoForDomain(p_sDomain);
            if( domainInfo == null ){
                return false;
            }

            m_sAliasDomain = domainInfo.getAhost();
            if(domainInfo.getLanguage() != null && !domainInfo.getLanguage().equals("")){
                m_sLang = domainInfo.getLanguage();
            }

            String p_sMhost = domainInfo.getMhost();
            ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
            ImUserInfoBean userBean = userDao.getUserInfoForMailid(p_sMhost, p_sMailid);
            if( userBean == null ){
                // 사용자 정보에서 찾을 수 없을 경우 가상아이디에서 찾는다.
                userBean = userDao.getAliasUser( p_sMhost , p_sMailid );
                if( userBean == null ){
                    return false;
                }
            }
            userBean.setDomain(domainInfo.getDomain());
            setUserInfo(userBean);
            bRet = true;
        } catch (Exception ex) {
            String errorId = ErrorTraceLogger.log(ex);
            ImLoggerEx.error("{} - [Userinfo]   ", errorId);
            return bRet;
        }
        // 사용자정보를 가져오고 사용자 용량이 음수일때 사용자 용량을 초기화한다.
        if (bRet && m_lCurrSize < 0) {
            initUserSize();
        }

        return bRet;
    }

    /**
     * 도메인 키와 사용자 키를 이용하여 사용자 정보를 구한다.
     * @param p_sMhost
     * @param p_sUserid
     * @return
     */
    public boolean getUserInfoForMhostAndUserid(String p_sMhost, String p_sUserid){
        boolean bRet = false;
        try {
            DomainService domainService = DomainService.getInstance();
            ImDomainInfoBean domainInfo = domainService.getDomainInfoForMhost(p_sMhost);
            if( domainInfo == null ){
                return false;
            }

            m_sAliasDomain = domainInfo.getAhost();
            if(domainInfo.getLanguage() != null && !domainInfo.getLanguage().equals("")){
                m_sLang = domainInfo.getLanguage();
            }

            ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
            ImUserInfoBean userBean = userDao.getUserInfo(p_sMhost, p_sUserid );
            if( userBean == null ){
                return false;
            }
            userBean.setDomain(domainInfo.getDomain());
            setUserInfo(userBean);
            bRet = true;
        } catch (Exception ex) {
            String errorId = ErrorTraceLogger.log(ex);
            ImLoggerEx.error("{} - [Userinfo]   ", errorId);
            return bRet;
        }
        // 사용자정보를 가져오고 사용자 용량이 음수일때 사용자 용량을 초기화한다.
        if (bRet && m_lCurrSize < 0) {
            initUserSize();
        }
        return bRet;
    }

    public boolean getUserInfoForMhostAndMailId(String p_sMhost, String p_sMailid) {
        boolean bRet = false;
        try {
            DomainService domainService = DomainService.getInstance();
            ImDomainInfoBean domainInfo = domainService.getDomainInfoForMhost(p_sMhost);
            if( domainInfo == null ){
                return false;
            }
            m_sAliasDomain = domainInfo.getAhost();
            if(domainInfo.getLanguage() != null && !domainInfo.getLanguage().equals("")){
                m_sLang = domainInfo.getLanguage();
            }
            ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
            ImUserInfoBean userBean = userDao.getUserInfoForMailid(p_sMhost, p_sMailid);
            if( userBean == null ){
                // 사용자 정보에서 찾을 수 없을 경우 가상아이디에서 찾는다.
                userBean = userDao.getAliasUser( p_sMhost , p_sMailid );
                if( userBean == null ){
                    return false;
                }
            }
            userBean.setDomain(domainInfo.getDomain());
            setUserInfo(userBean);
            bRet = true;
        } catch (Exception ex) {
            String errorId = ErrorTraceLogger.log(ex);
            ImLoggerEx.error("{} - [Userinfo]   ", errorId);
            return bRet;
        }
        // 사용자정보를 가져오고 사용자 용량이 음수일때 사용자 용량을 초기화한다.
        if (bRet && m_lCurrSize < 0) {
            initUserSize();
        }
        return bRet;
    }

    public String getRedirect_mailbox() {
        return m_sRedirect_mailbox;
    }

    public void setRedirect_mailbox(String redirect_mailbox) {
        m_sRedirect_mailbox = redirect_mailbox;
    }

    public String getWorkKey() {
        return m_sWorkKey;
    }

    public void setWorkKey(String workKey) {
        if (workKey != null)
            m_sWorkKey = workKey;
    }

    public boolean isAuthMail() {
        return m_bAuthMail;
    }

    public void setAuthMail(boolean bAuthMail) {
        m_bAuthMail = bAuthMail;

    }

    public String getAuthDelay() {
        return m_sAuthDelay;
    }

    public void setAuthDalay(String authDelay) {
        m_sAuthDelay = authDelay;

    }

    public String getHandphone() {
        return m_sHandphone;
    }

    public String getTel() {
        return m_sTel;
    }

    public void setHandphone(String handphone) {
        m_sHandphone = handphone;
    }

    public void setTel(String tel) {
        m_sTel = tel;
    }

    public int getUse_workmbox() {
        return use_workmbox;
    }

    public void setUse_workmbox(int nUse_workmbox) {
        use_workmbox = nUse_workmbox;
    }

    public String getUserDomainAlias() {
        return m_sUserDomainAlias;
    }

    public void setUserDomainAlias(String userDomainAlias) {
        m_sUserDomainAlias = userDomainAlias;
    }

    public String getUserOldDomainAlias() {
        return m_sUserOldDomainAlias;
    }

    public void setUserOldDomainAlias(String userOldDomainAlias) {
        m_sUserOldDomainAlias = userOldDomainAlias;
    }

    public void setCurrSize(long size) {
        this.m_lCurrSize = size;
    }

    /**
     * @return the smtp_logindate
     */
    public String getSmtp_logindate() {
        return smtp_logindate;
    }

    /**
     * @param smtp_logindate the smtp_logindate to set
     */
    public void setSmtp_logindate(String smtp_logindate) {
        this.smtp_logindate = smtp_logindate;
    }

    /**
     * @return the pop3_logindate
     */
    public String getPop3_logindate() {
        return pop3_logindate;
    }

    /**
     * @param pop3_logindate the pop3_logindate to set
     */
    public void setPop3_logindate(String pop3_logindate) {
        this.pop3_logindate = pop3_logindate;
    }

    /**
     * @return the imap_logindate
     */
    public String getImap_logindate() {
        return imap_logindate;
    }

    private void initUserSize() {

        try {
            ImMailDataDAO mdataDao = ImMailDataDAO.getDAO();
            long userSize = mdataDao.getUserMailSize(m_sMhost, m_sUserID, m_sAliasDomain, m_sTbl_no, m_nPart_no);

            if (userSize >= 0) {
                ImUserInfoDAO userDao = ImUserInfoDAO.getDAO();
                userDao.updateUserMailSize(m_sMhost, m_sUserID, userSize);
            }

        } catch (Exception ex) {
            String errorId = ErrorTraceLogger.log(ex);
            ImLoggerEx.error("{} - [Userinfo]   ", errorId);
        }

    }

    /**
     * @return the pwd_type
     */
    public String getPwd_type() {
        return pwd_type;
    }

    /**
     * @param pwd_type the pwd_type to set
     */
    public void setPwd_type(String pwd_type) {
        this.pwd_type = pwd_type;
    }

    public int getGid() {
        return gid;
    }

    public void setGid(int gid) {
        this.gid = gid;
    }

    public String getMailID() {
        return m_sMailID;
    }

    public void setMailID(String m_sMailID) {
        this.m_sMailID = m_sMailID;
    }

	public void setMhost(String mhost) {
		m_sMhost = mhost;
	}

    public boolean isDeputy() {
        return isDeputy;
    }

    public void setDeputy(boolean deputy) {
        isDeputy = deputy;
    }

    public String getDeputyEmail() {
        return deputyEmail;
    }

    public void setDeputyEmail(String deputyEmail) {
        this.deputyEmail = deputyEmail;
    }

    /**
     * 현시점에서 접속허용국가 목록
     *
     * @param listCountry
     * @return
     */
    private String countryProcess(List<AllowCountryBean> listCountry) {
        String resultCountry = "";

        Calendar now = Calendar.getInstance();
        for( AllowCountryBean countryCode : listCountry ){
            try{
                // 사용안함인 경우 허용목록에서 제외된다.
                if ( countryCode.getUse() == 0 ) {
                    continue;
                }
                // 시작일자가 있는 경우에만 처리한다
                if (StringUtils.isNotEmpty(countryCode.getStart_date())) {
                    Date startDate = ImTimeUtil.getDateFromString(countryCode.getStart_date()+"000000","yyyyMMddHHmmss");
                    Calendar compareCal = Calendar.getInstance();
                    compareCal.setTime(startDate);
                    // 현재시간이 종료일자보다 이후인가?
                    if ( now.before(compareCal) ){
                        continue;
                    }
                }

                // 종료일자가 있는 경우에만 처리한다.
                if (StringUtils.isNotEmpty(countryCode.getEnd_date())) {
                    Date endDateFormat = ImTimeUtil.getDateFromString(countryCode.getEnd_date()+"235959", "yyyyMMddHHmmss" );

                    Calendar endDateCal = Calendar.getInstance();
                    endDateCal.setTime(endDateFormat);

                    if (now.after(endDateCal)) {
                        continue;
                    }
                }
            }catch(Exception e){
                String errorId = ErrorTraceLogger.log(e);
                ImLoggerEx.error("{} - Allow Contry Code Date Check Error",errorId);
                continue;
            }
            resultCountry += countryCode.getCountry_code() + ";";
        }
        return resultCountry;
    }

}
