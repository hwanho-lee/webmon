package user.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import user.common.*;

public class DBConnector {
	static Logger logger = Logger.getLogger(DBConnector.class.getName());
	static String jndi_name;

	public DBConnector(){
	}

	public static Connection getConnection(){
		if(jndi_name == null){
			jndi_name = CommonLib.getProperties("datasource.name");
		}
		try{
			DataSource ds = null;
			try {
				ds = (DataSource )new InitialContext().lookup( jndi_name );
			} catch (NamingException e2) {
				try {
					try {
						ds = (DataSource) new InitialContext().lookup("java:comp/env/" + jndi_name);
					} catch (Exception e) {
						e.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			Connection con = null;
			try {
				con = ds.getConnection();
			} catch (Exception e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ssl_manager","admin","admin1234");
				} catch (SQLException e3) {
					e3.printStackTrace();
				}
			}

			return con;

		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	public static void releaseConnection(PreparedStatement pstmt){
		releaseConnection(pstmt, null);
	}

	public static void releaseConnection(PreparedStatement pstmt, ResultSet resultSet){
		releaseConnection(null, pstmt, resultSet);
	}
	public static void releaseConnection(Connection con, PreparedStatement pstmt){
		releaseConnection(con, pstmt, null);
	}


	public static void releaseConnection(Connection con, PreparedStatement pstmt, ResultSet resultSet){
		try{	
			if(resultSet != null){ 
				try { 
					resultSet.close(); 
					resultSet = null; 
				} catch (SQLException e) {
					e.printStackTrace();
				} 
			}

			if(pstmt != null){ 
				try { 
					pstmt.close(); 
					pstmt = null; 
				} catch (SQLException e) {
					e.printStackTrace();
				} 
			}

			if(con != null){ 
				try { 
					con.close(); 
					con = null;
				} catch (SQLException e) { 
					e.printStackTrace();
				} 
			}
						logger.info(" Release Complete");

		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
