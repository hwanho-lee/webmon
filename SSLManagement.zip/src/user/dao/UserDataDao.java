package user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.NamingException;

import org.json.JSONException;
import org.json.JSONObject;
import user.db.*;


public class UserDataDao {
	
	
	public static JSONObject request(Connection conn, JSONObject request_value)throws SQLException, NamingException, JSONException {

		
		JSONObject response_value = new JSONObject(); 
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			String user_id = request_value.getString("user_id");
			String password = request_value.getString("password");
			String user_name = "";
			String group_name = "";			
			String adminYN = "";			
			String acceptYN = "N";

			StringBuffer sql_str = new StringBuffer();
			sql_str.append("SELECT USER_ID, USER_NAME, GROUP_NAME, LOGIN_PASSWORD, ADMIN_YN, ACCEPT_YN 		\n");
			sql_str.append("	FROM USER_INFO A, GROUP_INFO B									\n");								
			sql_str.append(" WHERE A.USER_ID=?													\n");
			sql_str.append(" AND LOGIN_PASSWORD=?												\n");				
			sql_str.append(" AND A.GROUP_ID=B.GROUP_ID											\n");	
			
			pstmt = conn.prepareStatement(sql_str.toString());
			pstmt.setString(1,user_id);
			pstmt.setString(2,password);
			System.out.println("SQL : " + pstmt.toString());
			rs = pstmt.executeQuery();
            
			int count = 0;
            while (rs.next()) {
            	// 로그인 데이터가 있으므료 COUNT 증가
            	count++;
            	user_id = rs.getString("USER_ID");
            	user_name = rs.getString("USER_NAME");
            	group_name = rs.getString("GROUP_NAME");
            	adminYN = rs.getString("ADMIN_YN");
            	acceptYN = rs.getString("ACCEPT_YN");
     	    }
            if(count != 0){            	
            	response_value.put("LOGIN_SUCCESS", "Y");            	
            	response_value.put("USER_ID", user_id);
            	response_value.put("USER_NAME", user_name);
            	response_value.put("GROUP_NAME", group_name);
            	response_value.put("ADMIN_YN", adminYN);
            	response_value.put("ACCEPT_YN", acceptYN);
            }else{
            	response_value.put("LOGIN_SUCCESS", "N");
            }           
		}catch (SQLException e1) {
			e1.printStackTrace();
		}catch(Exception e2){			
			e2.printStackTrace();		
		}finally{
			if(rs != null){
				rs.close();
			}
			if(pstmt != null){
				pstmt.close();
			}

		}
		return response_value;
	}

	public static JSONObject newJoinForm(Connection conn, JSONObject request_value)throws SQLException, NamingException, JSONException {
		
		JSONObject response_value = new JSONObject(); 

		try{			

			StringBuffer sql_str = new StringBuffer();
			sql_str.append("SELECT GROUP_ID, GROUP_NAME, DESCRIPTION		\n");
			sql_str.append("	FROM GROP_INFO								\n");								
			
			Hashtable param = new Hashtable();
			response_value = DBQueryExcutor.selectSingleRow(conn, sql_str.toString(), param);            
		}catch(Exception e){			
			e.printStackTrace();		
		}
		return response_value;
	}
	
	public static JSONObject newJoin(Connection conn, JSONObject request_value)throws SQLException, NamingException, JSONException {

		
		JSONObject response_value = new JSONObject();

		try{					

			StringBuffer sql_str = new StringBuffer();
			sql_str.append("INSERT INTO user_info										 				\n");
			sql_str.append("	VALUES(:USER_ID,			\n");
			sql_str.append("		   :USER_NAME,			\n");
			sql_str.append("		   :USER_PASSWORD,		\n");
			sql_str.append("		   :GROUP_ID,			\n");
			sql_str.append("		   :MOBILE_NUMBER,		\n");
			sql_str.append("		   :EMAIL_ADDRESS,		\n");
			sql_str.append("		   :REG_ID,				\n");
			sql_str.append("		   CURRENT_DATE(),		\n");
			sql_str.append("		   :MOD_ID,				\n");
			sql_str.append("		   CURRENT_DATE(),		\n");
			//sql_str.append("		   ':ADMIN_YN',			\n");
			sql_str.append("		   'N',					\n");
			//sql_str.append("		   ':ACCEPT_YN',		\n");
			sql_str.append("		   'N',					\n");
			sql_str.append("		   :DESCRIPTION)		\n");	
			
			Hashtable param = new Hashtable();
			param.put("USER_ID", request_value.getString("USER_ID"));
			param.put("USER_NAME", request_value.getString("USER_NAME"));
			param.put("USER_PASSWORD", request_value.getString("USER_PASSWORD1"));
			param.put("GROUP_ID", request_value.getString("GROUP_ID"));
			param.put("MOBILE_NUMBER", request_value.getString("MOBILE_NUMBER"));
			param.put("EMAIL_ADDRESS", request_value.getString("EMAIL_ADDRESS"));
			param.put("REG_ID", request_value.getString("USER_ID"));
			param.put("MOD_ID", request_value.getString("USER_ID"));
			// 관리자  여부 기본값 "N"
			//param.put("ADMIN_YN", request_value.getString("ADMIN_YN"));
			
			// 로그인 승인 여부 기본값 "N"
			//param.put("ACCEPT_YN", "N");
			param.put("DESCRIPTION", request_value.getString("DESCRIPTION"));
			
			response_value = DBQueryExcutor.updateQueryExcutor(conn, sql_str.toString(), param, false);
			
			System.out.println("USER Insert SQL : " + response_value.toString());
           
		}catch (Exception e) {
			e.printStackTrace();		
		}
		return response_value;
	}

}
