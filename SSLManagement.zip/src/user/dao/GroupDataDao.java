package user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.NamingException;

import org.json.JSONException;
import org.json.JSONObject;
import user.db.*;


public class GroupDataDao {	

	public static JSONObject getGroupList(Connection conn, JSONObject request_value)throws SQLException, NamingException, JSONException {
		
		JSONObject response_value = new JSONObject(); 

		try{			

			StringBuffer sql_str = new StringBuffer();
			sql_str.append("SELECT GROUP_ID, GROUP_NAME, DESCRIPTION		\n");
			sql_str.append("	FROM GROUP_INFO								\n");								
			
			Hashtable param = new Hashtable();
			response_value = DBQueryExcutor.selectMultiRow(conn, sql_str.toString(), param);            
		}catch(Exception e){			
			e.printStackTrace();		
		}
		return response_value;
	}
	

}
