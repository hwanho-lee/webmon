// ////////////////////////////////////////////////////////////////////////////////
function activeGNB(id) {
	for(num=1; num<=3; num++) document.getElementById('gm'+num).style.display='none'; //D2MG1~D2MG4 까지 숨긴 다음
	document.getElementById(id).style.display='block'; //해당 ID만 보임
}

// 01-INTRO
function go_01_01() {	document.location.href="01_introduceSSLManager.jsp";}
function go_01_02() {	document.location.href="01_introduceAdmin.jsp";}

// 02-SSL
function go_02_01() {	document.location.href="02_managerSSLCert.jsp";}
function go_02_02() {	document.location.href="02_GuideSSL.jsp";}
function go_02_03() {	document.location.href="02_Statistics.jsp";}

// 03-ADMIN
function go_03_01() {	document.location.href="03_managerUser.jsp";}
function go_03_02() {	document.location.href="03_managerGroup.jsp";}