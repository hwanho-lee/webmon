USE ssl_manager;

insert into `user_info`(`USER_ID`,`LOGIN_PASSWORD`,`USER_NAME`,`GROUP_ID`,`MOBILE_NUMBER`,`EMAIL_ADDRESS`,`REG_ID`,`REG_DATE`,`MOD_ID`,`MOD_DATE`,`ADMIN_YN`,`ACCEPT_YN`,`DESCRIPTION`) values ('201190218','admin1234','이환호','wireless','01030050654','hwanho-lee@kt.com','201190218','2013-04-15','201190218','2013-04-15','Y','Y','전체 관리자');
insert into `user_info`(`USER_ID`,`LOGIN_PASSWORD`,`USER_NAME`,`GROUP_ID`,`MOBILE_NUMBER`,`EMAIL_ADDRESS`,`REG_ID`,`REG_DATE`,`MOD_ID`,`MOD_DATE`,`ADMIN_YN`,`ACCEPT_YN`,`DESCRIPTION`) values ('201190219','admin1234','김준의','legacy','070','suhyun-kang@kt.com','201190219','2013-04-18','201190219','2013-04-18','N','Y','테스트 가입자 강수현');
