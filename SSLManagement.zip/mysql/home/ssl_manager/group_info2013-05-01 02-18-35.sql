USE ssl_manager;

insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('admin','관리자','전체 관리자 그룹');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('wireless','무선','무선 파트');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('cloud','클라우드','클라우드 파트');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('legacy','유선','유선 파트');
