USE ssl_manager;

insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('wireless','무선','무선 파트');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('cloud','클라우드','클라우드 파트');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('legacy','유선','유선 파트');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('etc','기타','기타 일반 유저');
insert into `group_info`(`GROUP_ID`,`GROUP_NAME`,`DESCRIPTION`) values ('test','test','test');
